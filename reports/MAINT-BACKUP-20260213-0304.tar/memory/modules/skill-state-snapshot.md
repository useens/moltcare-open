# 🛠️ 技能状态快照 v1.0

> 记录所有技能的安装状态，确保复活后能完整恢复能力
> 
> **生成时间**: 2026-02-12 07:30 CST  
> **对应系统版本**: 林林 v5.3  
> **备份系统**: 凤凰复活系统 v1.0

---

## 快照结构说明

| 字段 | 说明 |
|------|------|
| `name` | 技能名称 |
| `location` | 安装位置（local=工作区, global=系统目录, tool=工具目录） |
| `install_type` | 安装类型（npm, npm_link, system, pip, binary） |
| `dependencies` | 依赖列表 |
| `system_deps` | 系统级依赖（如Chrome） |
| `env_vars` | 必需环境变量 |
| `restore_cmd` | 复活恢复命令 |
| `critical` | 是否关键技能（复活后必须可用） |

---

## 关键技能清单（Critical Skills）

### 1. 🌐 Browser CLI - 浏览器自动化

```yaml
name: browser-cli
location: ~/.openclaw/workspace/tools/browser-cli/
install_type: npm_local
package_manager: npm
linked_global: true
link_target: /usr/local/bin/browser

dependencies:
  - playwright-core@^1.58.2
  
system_deps:
  - name: chromium
    path: /usr/bin/chromium
    alt_path: ~/.cache/ms-playwright/chromium-*/chrome
    install_cmd: "npx playwright install chromium"
    
env_vars: []

restore_steps:
  1. "cd ~/.openclaw/workspace/tools/browser-cli/"
  2. "npm install"
  3. "sudo npm link"  # 创建全局命令
  4. "npx playwright install chromium"  # 下载浏览器二进制
  
verify_cmd: "browser navigate https://example.com"
critical: true
note: "复活后发现不能使用的问题根源"
```

### 2. 🎙️ Local Whisper - 本地语音识别

```yaml
name: local-whisper
location: ~/.openclaw/workspace/skills/local-whisper/
install_type: pip_venv
package_manager: pip

venv_path: ~/.openclaw/workspace/skills/local-whisper/.venv
dependencies:
  - openai-whisper
  - ffmpeg-python
  
system_deps:
  - name: ffmpeg
    path: /usr/bin/ffmpeg
    install_cmd: "apt-get update && apt-get install -y ffmpeg"
    
model_files:
  - ~/.cache/whisper/base.pt
  - ~/.cache/whisper/small.pt
  
restore_steps:
  1. "cd ~/.openclaw/workspace/skills/local-whisper/"
  2. "python3 -m venv .venv"
  3. "source .venv/bin/activate"
  4. "pip install openai-whisper"
  5. "whisper --model base --help"  # 自动下载模型
  
verify_cmd: "whisper --version"
critical: true
```

### 3. 📹 VHS Recorder - 终端录屏

```yaml
name: vhs-recorder
location: ~/.openclaw/workspace/skills/vhs-recorder/
install_type: system_binary

system_deps:
  - name: vhs
    path: /usr/local/bin/vhs
    install_cmd: |
      sudo mkdir -p /etc/apt/keyrings
      curl -fsSL https://repo.charm.sh/apt/gpg.key | sudo gpg --dearmor -o /etc/apt/keyrings/charm.gpg
      echo "deb [signed-by=/etc/apt/keyrings/charm.gpg] https://repo.charm.sh/apt/ * *" | sudo tee /etc/apt/sources.list.d/charm.list
      sudo apt update && sudo apt install vhs
      
  - name: ttyd
    path: /usr/bin/ttyd
    install_cmd: "sudo apt install ttyd"
    
restore_steps:
  1. "执行上述vhs安装命令"
  2. "执行ttyd安装命令"
  
verify_cmd: "vhs --version"
critical: false
```

### 4. 🧪 Python Skill - Python开发环境

```yaml
name: python
location: ~/.openclaw/workspace/skills/python/
install_type: npm_local

dependencies:
  - py_compile（内置）
  - uv（可选，用于依赖管理）
  
restore_steps:
  - "无特殊步骤，纯技能定义"
  
critical: true
```

### 5. 📋 TDD Guide - 测试驱动开发

```yaml
name: tdd-guide
location: ~/.openclaw/workspace/skills/tdd-guide/
install_type: npm_local

dependencies:
  - jest
  - pytest
  - coverage.py
  
restore_steps:
  1. "cd ~/.openclaw/workspace/skills/tdd-guide/"
  2. "npm install"
  
critical: false
```

### 6. 🐙 GitHub Skill - GitHub CLI集成

```yaml
name: github
location: ~/.openclaw/workspace/skills/github/
install_type: system_binary

system_deps:
  - name: gh
    path: /usr/bin/gh
    install_cmd: |
      curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg
      echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null
      sudo apt update
      sudo apt install gh
      
restore_steps:
  1. "执行上述gh安装命令"
  2. "gh auth login"  # 需要交互式认证
  
verify_cmd: "gh --version"
critical: true
```

### 7. 🎭 Moltbook Interact - Moltbook社区

```yaml
name: moltbook-interact
location: ~/.openclaw/workspace/skills/moltbook-interact/
install_type: python_script

dependencies:
  - requests
  
restore_steps:
  - "纯Python脚本，无特殊依赖"
  
critical: true
```

---

## ClawHub系统技能（Global Skills）

这些技能通过 `openclaw skills install` 安装到系统目录，**不需要在复活时单独恢复**，因为它们会随着 OpenClaw 重新安装而恢复。

```yaml
global_skills_location: ~/.nvm/versions/node/v22.22.0/lib/node_modules/openclaw/skills/
install_method: clawhub
restore_method: "openclaw skills install <skill-name>"

installed_global_skills:
  - weather
  - summarize
  - video-frames
  - browser  # OpenClaw内置浏览器控制
  - canvas
  # ... 其他系统技能

critical: false
note: "OpenClaw重装后会自动恢复"
```

---

## 快速复活检查清单

执行 `scripts/auto-resurrect.sh` 后，按此清单验证：

```bash
#!/bin/bash
# 保存为: scripts/verify-resurrection.sh

echo "🧪 复活验证检查清单"
echo ""

# 1. Browser CLI
echo -n "✓ Browser CLI... "
if command -v browser &> /dev/null; then
    echo "✅"
else
    echo "❌ 需要: cd tools/browser-cli && npm install && sudo npm link && npx playwright install chromium"
fi

# 2. Chromium
echo -n "✓ Chromium... "
if [ -d ~/.cache/ms-playwright/chromium-* ] || command -v chromium &> /dev/null; then
    echo "✅"
else
    echo "❌ 需要: npx playwright install chromium"
fi

# 3. FFmpeg (Whisper依赖)
echo -n "✓ FFmpeg... "
if command -v ffmpeg &> /dev/null; then
    echo "✅"
else
    echo "❌ 需要: sudo apt update && sudo apt install -y ffmpeg"
fi

# 4. VHS
echo -n "✓ VHS... "
if command -v vhs &> /dev/null; then
    echo "✅"
else
    echo "❌ 可选: 按SKILL.md安装vhs"
fi

# 5. GitHub CLI
echo -n "✓ GitHub CLI... "
if command -v gh &> /dev/null; then
    echo "✅"
else
    echo "⚠️  可选: 需要时按SKILL.md安装"
fi

echo ""
echo "如果有❌，请执行对应的恢复命令"
```

---

## 自动恢复脚本扩展

在 `scripts/auto-resurrect.sh` 的第5步后添加：

```bash
# ============ 恢复技能依赖 ============
restore_skills() {
    log_info "========== 恢复技能依赖 =========="
    
    # 1. Browser CLI
    if [ -d "${WORKSPACE_DIR}/tools/browser-cli" ]; then
        log_info "[1/4] 恢复 Browser CLI..."
        cd "${WORKSPACE_DIR}/tools/browser-cli"
        npm install
        sudo npm link
        npx playwright install chromium
        log_info "Browser CLI 恢复完成"
    fi
    
    # 2. Local Whisper 虚拟环境
    if [ -d "${WORKSPACE_DIR}/skills/local-whisper" ]; then
        log_info "[2/4] 恢复 Local Whisper..."
        cd "${WORKSPACE_DIR}/skills/local-whisper"
        python3 -m venv .venv
        source .venv/bin/activate
        pip install openai-whisper
        deactivate
        log_info "Local Whisper 恢复完成"
    fi
    
    # 3. 系统依赖检查
    log_info "[3/4] 检查系统依赖..."
    
    # FFmpeg
    if ! command -v ffmpeg &> /dev/null; then
        log_warn "FFmpeg 未安装，正在安装..."
        sudo apt-get update
        sudo apt-get install -y ffmpeg
    fi
    
    # 4. 本地技能 npm install
    log_info "[4/4] 安装本地技能依赖..."
    for skill_dir in "${WORKSPACE_DIR}/skills"/*/; do
        if [ -f "${skill_dir}package.json" ]; then
            log_info "安装技能: $(basename "$skill_dir")"
            (cd "$skill_dir" && npm install) 2>/dev/null || true
        fi
    done
    
    log_info "技能依赖恢复完成"
}
```

---

## 更新日志

| 时间 | 版本 | 变更 |
|------|------|------|
| 2026-02-12 | v1.0 | 初始创建，记录browser-cli等关键技能状态 |

---

**注意**: 每次安装新技能或更新技能依赖后，需要更新此文件。
