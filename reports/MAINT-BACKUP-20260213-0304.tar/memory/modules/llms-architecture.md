# 本地轻量记忆系统架构设计
## Local Lightweight Memory System (LLMS)

> 基于 elite-longterm-memory 的简化版本，纯本地运行，零 API 依赖

---

## 1. 设计目标

| 目标 | 说明 |
|------|------|
| **纯本地** | 无需任何 API Key，完全离线运行 |
| **轻量级** | 核心代码 <1000 行，依赖最少 |
| **兼容现有结构** | 无缝接入 `memory/` 目录体系 |
| **核心功能** | 向量存储、语义搜索、自动关联 |
| **易于维护** | 模块化设计，文档完善 |

---

## 2. 系统架构

```
┌─────────────────────────────────────────────────────────────────┐
│                    LOCAL LIGHTWEIGHT MEMORY                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │   输入层    │  │   核心层    │  │   存储层    │             │
│  │             │  │             │  │             │             │
│  │  Markdown   │  │  Embedding  │  │  SQLite     │             │
│  │  Files      │  │  Engine     │  │  + Vectors  │             │
│  │             │  │             │  │             │             │
│  │  CLI/API    │  │  Indexer    │  │  Index      │             │
│  │  Interface  │  │  Searcher   │  │  Cache      │             │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘             │
│         │                │                │                     │
│         └────────────────┴────────────────┘                     │
│                          │                                      │
│                          ▼                                      │
│                 ┌─────────────┐                                │
│                 │  memory/    │  ← 兼容现有结构                │
│                 │  目录       │                                │
│                 └─────────────┘                                │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 3. 核心模块划分

### 3.1 模块总览

```
llms/
├── core/                    # 核心模块
│   ├── __init__.py
│   ├── config.py           # 配置管理
│   ├── embedder.py         # 本地嵌入引擎
│   ├── indexer.py          # 索引管理
│   ├── searcher.py         # 语义搜索
│   └── associator.py       # 自动关联
├── storage/                 # 存储层
│   ├── __init__.py
│   ├── vector_store.py     # 向量存储 (SQLite + sqlite-vec)
│   └── metadata_store.py   # 元数据存储
├── parser/                  # 解析器
│   ├── __init__.py
│   ├── markdown_parser.py  # Markdown 解析
│   └── chunker.py          # 文本分块
├── api/                     # 接口层
│   ├── __init__.py
│   ├── cli.py              # 命令行接口
│   └── python_api.py       # Python API
└── utils/
    ├── __init__.py
    └── helpers.py
```

### 3.2 各模块职责

#### 3.2.1 嵌入引擎 (Embedder)
```python
class LocalEmbedder:
    """本地嵌入引擎，使用轻量级模型"""
    
    # 支持模型选项
    MODELS = {
        "tiny": "sentence-transformers/all-MiniLM-L6-v2",  # 22MB, 384维
        "small": "sentence-transformers/paraphrase-MiniLM-L3-v2",  # 13MB, 384维
        "micro": "local-tf-idf",  # 纯本地TF-IDF, 无依赖
    }
    
    def encode(self, text: str) -> np.ndarray:
        """将文本编码为向量"""
        pass
    
    def encode_batch(self, texts: List[str]) -> np.ndarray:
        """批量编码"""
        pass
```

**特点：**
- 默认使用 `all-MiniLM-L6-v2` (仅 22MB)
- 首次运行时自动下载模型
- 支持离线运行
- 提供 TF-IDF 备选方案（零依赖）

#### 3.2.2 向量存储 (VectorStore)
```python
class VectorStore:
    """基于 SQLite + sqlite-vec 的向量存储"""
    
    def __init__(self, db_path: str):
        self.db = sqlite3.connect(db_path)
        self.vec = sqlite_vec.load(self.db)
    
    def add(self, id: str, vector: np.ndarray, metadata: dict):
        """添加向量"""
        pass
    
    def search(self, query_vector: np.ndarray, top_k: int = 5) -> List[Result]:
        """向量相似度搜索"""
        pass
    
    def delete(self, id: str):
        """删除向量"""
        pass
```

**特点：**
- 使用 `sqlite-vec` 扩展
- 支持余弦相似度搜索
- 元数据与向量一起存储
- 零外部依赖（除 sqlite3）

#### 3.2.3 索引管理 (Indexer)
```python
class Indexer:
    """文档索引管理器"""
    
    def index_file(self, filepath: str):
        """索引单个文件"""
        # 1. 解析 Markdown
        # 2. 文本分块
        # 3. 生成嵌入
        # 4. 存入向量库
        pass
    
    def index_directory(self, dirpath: str, pattern: str = "*.md"):
        """批量索引目录"""
        pass
    
    def watch(self, dirpath: str):
        """监听目录变化，自动更新索引"""
        pass
```

#### 3.2.4 语义搜索 (Searcher)
```python
class Searcher:
    """语义搜索引擎"""
    
    def search(
        self, 
        query: str, 
        top_k: int = 5,
        filters: Optional[dict] = None
    ) -> List[SearchResult]:
        """
        语义搜索
        
        Args:
            query: 查询文本
            top_k: 返回结果数量
            filters: 元数据过滤条件
        """
        pass
    
    def hybrid_search(
        self,
        query: str,
        keywords: List[str],
        top_k: int = 5
    ) -> List[SearchResult]:
        """混合搜索：语义 + 关键词"""
        pass
```

#### 3.2.5 自动关联 (Associator)
```python
class Associator:
    """记忆自动关联引擎"""
    
    def find_related(self, memory_id: str, top_k: int = 3) -> List[RelatedMemory]:
        """查找相关记忆"""
        pass
    
    def build_graph(self) -> MemoryGraph:
        """构建记忆关联图"""
        pass
    
    def suggest_links(self, new_memory: str) -> List[SuggestedLink]:
        """为新记忆建议关联"""
        pass
```

---

## 4. 数据流设计

### 4.1 索引流程

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Markdown   │────▶│   Parser    │────▶│   Chunker   │
│   Files     │     │  (解析元数据)  │     │  (文本分块)  │
└─────────────┘     └─────────────┘     └──────┬──────┘
                                                │
                       ┌────────────────────────┘
                       ▼
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   SQLite    │◀────│   Vector    │◀────│  Embedder   │
│   Store     │     │   Store     │     │ (生成向量)   │
└─────────────┘     └─────────────┘     └─────────────┘
```

### 4.2 搜索流程

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Query     │────▶│  Embedder   │────▶│   Vector    │
│   Text      │     │ (查询向量)   │     │   Search    │
└─────────────┘     └─────────────┘     └──────┬──────┘
                                                │
                       ┌────────────────────────┘
                       ▼
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Results   │◀────│  Re-ranker  │◀────│  Metadata   │
│  (返回用户)  │     │  (排序优化)  │     │   Filter    │
└─────────────┘     └─────────────┘     └─────────────┘
```

### 4.3 自动关联流程

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   New       │────▶│  Generate   │────▶│  Find       │
│   Memory    │     │   Vector    │     │  Similar    │
└─────────────┘     └─────────────┘     └──────┬──────┘
                                                │
                       ┌────────────────────────┘
                       ▼
┌─────────────┐     ┌─────────────┐
│   Store     │◀────│  Create     │
│   Links     │     │  Relations  │
└─────────────┘     └─────────────┘
```

---

## 5. 数据模型

### 5.1 向量表结构

```sql
-- 主向量表
CREATE TABLE memories (
    id TEXT PRIMARY KEY,           -- 唯一标识: "2026-02-09#chunk-0"
    content TEXT NOT NULL,         -- 原始文本内容
    embedding F32_BLOB(384),       -- 向量 (384维)
    source_file TEXT,              -- 源文件路径
    source_line INTEGER,           -- 源文件行号
    created_at TIMESTAMP,          -- 创建时间
    updated_at TIMESTAMP,          -- 更新时间
    memory_type TEXT,              -- 类型: daily/intel/decision/lesson
    importance REAL,               -- 重要性: 0.0-1.0
    tags TEXT                      -- 标签: JSON 数组
);

-- 关联表
CREATE TABLE memory_links (
    id INTEGER PRIMARY KEY,
    source_id TEXT,                -- 源记忆ID
    target_id TEXT,                -- 目标记忆ID
    similarity REAL,               -- 相似度分数
    link_type TEXT,                -- 关联类型: semantic/temporal/tag
    created_at TIMESTAMP
);

-- 全文搜索表 (可选)
CREATE VIRTUAL TABLE memory_fts USING fts5(
    content, 
    source_file,
    tags
);
```

### 5.2 内存数据结构

```python
@dataclass
class MemoryChunk:
    """记忆片段"""
    id: str
    content: str
    embedding: np.ndarray
    metadata: MemoryMetadata
    relations: List[MemoryRelation]

@dataclass
class MemoryMetadata:
    """记忆元数据"""
    source_file: str
    source_line: int
    created_at: datetime
    memory_type: str      # daily/intel/decision/lesson
    importance: float     # 0.0 - 1.0
    tags: List[str]

@dataclass
class SearchResult:
    """搜索结果"""
    memory: MemoryChunk
    score: float
    match_type: str       # semantic/keyword/hybrid
```

---

## 6. 接口定义

### 6.1 命令行接口 (CLI)

```bash
# 初始化系统
llms init [--model tiny|small|micro]

# 索引命令
llms index <path>              # 索引文件或目录
llms index --watch <path>      # 监听模式
llms reindex                   # 重建索引

# 搜索命令
llms search "query"            # 语义搜索
llms search "query" -k 10      # 返回10条
llms search "query" --type intel   # 按类型过滤
llms search "query" --tag security # 按标签过滤

# 关联命令
llms related <memory-id>       # 查找相关记忆
llms link <id1> <id2>          # 手动建立关联
llms graph                     # 生成关联图

# 维护命令
llms status                    # 查看系统状态
llms stats                     # 统计信息
llms cleanup                   # 清理过期数据
llms vacuum                    # 压缩数据库

# 导入导出
llms export > backup.json      # 导出
llms import < backup.json      # 导入
```

### 6.2 Python API

```python
from llms import MemorySystem

# 初始化
mem = MemorySystem(
    db_path="~/.local/share/llms/memory.db",
    model="tiny"  # tiny/small/micro
)

# 索引
mem.index_file("memory/daily/2026-02-09.md")
mem.index_directory("memory/", pattern="*.md")

# 搜索
results = mem.search(
    "security audit",
    top_k=5,
    filters={"type": "intel", "importance": ">0.8"}
)

for result in results:
    print(f"[{result.score:.2f}] {result.memory.content[:100]}...")

# 获取相关记忆
related = mem.find_related("2026-02-09#chunk-3")

# 添加新记忆 (带自动关联)
mem.add(
    content="New security finding: ...",
    memory_type="intel",
    tags=["security", "audit"],
    auto_link=True
)

# 关闭
mem.close()
```

### 6.3 配置格式

```yaml
# ~/.config/llms/config.yaml
system:
  db_path: "~/.local/share/llms/memory.db"
  log_level: "INFO"

embedding:
  model: "tiny"                    # tiny/small/micro
  device: "cpu"                    # cpu/cuda
  batch_size: 32

indexing:
  chunk_size: 512                  # 分块大小
  chunk_overlap: 128               # 重叠大小
  watch_interval: 60               # 监听间隔(秒)
  auto_index: true                 # 自动索引

search:
  default_top_k: 5
  min_score: 0.3                   # 最小相似度
  use_hybrid: true                 # 启用混合搜索
  rerank: false                    # 结果重排序

storage:
  max_memories: 100000             # 最大记忆数
  retention_days: 365              # 保留天数
  vacuum_threshold: 0.3            # 压缩阈值(碎片比例)

# 目录映射 (兼容现有结构)
directories:
  daily: "memory/daily/*.md"
  intel: "memory/intel/*.md"
  modules: "memory/modules/*.md"
  archive: "memory/archive/*.md"
  tags: "tags/*.md"
```

---

## 7. 与现有系统兼容

### 7.1 目录映射

```
现有结构                    LLMS 识别
─────────────────────────────────────────
memory/
├── daily/                  → type=daily
│   └── 2026-02-09.md
├── intel/                  → type=intel
├── modules/                → type=module
├── archive/                → type=archive
└── tags/                   → type=tag
daily/                      → type=daily
tags/                       → type=tag
MEMORY.md                   → type=core
```

### 7.2 元数据提取

```python
# 从 Markdown 提取元数据
def extract_metadata(content: str, filepath: str) -> dict:
    metadata = {
        "type": infer_type(filepath),      # 从路径推断类型
        "date": extract_date(content),     # 从内容提取日期
        "tags": extract_tags(content),     # 提取标签
        "importance": infer_importance(content),  # 推断重要性
    }
    return metadata

# 示例: 从文件名提取日期
# "2026-02-09.md" → "2026-02-09"
# "security-audit-2026-02-09.md" → "2026-02-09"
```

### 7.3 迁移策略

```bash
# 1. 安装 LLMS
pip install llms

# 2. 初始化 (自动检测现有 memory/ 目录)
llms init --import-existing

# 3. 批量索引
llms index memory/ --recursive
llms index daily/
llms index MEMORY.md

# 4. 验证
llms status
llms search "test query"
```

---

## 8. 依赖与安装

### 8.1 核心依赖

```
# 必需
python >= 3.8
sqlite3 (内置)
sqlite-vec >= 0.1.0    # 向量扩展
numpy >= 1.20.0

# 嵌入模型 (可选)
sentence-transformers >= 2.0.0   # 推荐

# CLI 工具 (可选)
click >= 8.0.0
rich >= 10.0.0          # 美化输出
watchdog >= 2.0.0       # 文件监听

# 开发
test: pytest
lint: ruff, mypy
```

### 8.2 安装方式

```bash
# 方式1: pip 安装
pip install llms

# 方式2: 极简安装 (仅核心功能)
pip install llms[minimal]

# 方式3: 完整安装
pip install llms[full]

# 方式4: 本地开发
git clone https://github.com/user/llms
cd llms
pip install -e ".[dev]"
```

---

## 9. 性能指标

### 9.1 资源占用

| 指标 | 数值 | 说明 |
|------|------|------|
| 安装包大小 | ~25MB | 含 tiny 模型 |
| 内存占用 | ~100MB | 运行时 |
| 数据库 | ~1KB/记忆 | 含向量和元数据 |
| 索引速度 | ~100 docs/s | 普通笔记本 |
| 搜索延迟 | <50ms | 10万条记录 |

### 9.2 模型对比

| 模型 | 大小 | 维度 | 质量 | 适用场景 |
|------|------|------|------|----------|
| micro (TF-IDF) | 0MB | 1000+ | ⭐⭐ | 极简/离线 |
| tiny (MiniLM) | 22MB | 384 | ⭐⭐⭐⭐ | 推荐默认 |
| small (MiniLM-L3) | 13MB | 384 | ⭐⭐⭐ | 资源受限 |

---

## 10. 演进路线

### Phase 1: MVP (2周)
- [x] SQLite + sqlite-vec 存储
- [x] Tiny 嵌入模型支持
- [x] 基础 CLI (index/search)
- [x] 兼容现有 memory/ 结构

### Phase 2: 功能完善 (2周)
- [ ] 自动关联算法
- [ ] 混合搜索 (语义+关键词)
- [ ] 文件监听自动索引
- [ ] Python API 完整实现

### Phase 3: 优化增强 (2周)
- [ ] 增量更新
- [ ] 结果重排序
- [ ] 关联图可视化
- [ ] 性能优化

### Phase 4: 高级特性 (后续)
- [ ] 多模态支持 (图片)
- [ ] 分布式索引
- [ ] Web 界面
- [ ] 插件系统

---

## 11. 与 Elite 对比

| 特性 | Elite Memory | LLMS (本设计) |
|------|--------------|---------------|
| API Key | 需要 (OpenAI) | 不需要 |
| 向量数据库 | LanceDB | SQLite + sqlite-vec |
| 嵌入模型 | OpenAI/text-embedding | 本地 MiniLM |
| 云端同步 | SuperMemory | 不支持 (设计如此) |
| 安装复杂度 | 中等 | 简单 |
| 资源占用 | 较高 | 低 |
| 离线运行 | 否 | 是 |
| 搜索质量 | 很高 | 高 |
| 维护成本 | 中等 | 低 |

---

## 附录: 关键决策记录

### ADR-001: 使用 sqlite-vec 而非 LanceDB
**决策:** 使用 sqlite-vec 作为向量存储
**原因:**
1. 零外部依赖 (除 sqlite3)
2. 单文件数据库，易于备份
3. 与现有工具链兼容
4. 性能足够 (10万级记录 <50ms)

### ADR-002: 使用本地 MiniLM 而非 API
**决策:** 使用 sentence-transformers/all-MiniLM-L6-v2
**原因:**
1. 模型仅 22MB，下载一次永久使用
2. 质量足够，384维向量
3. 纯本地运行，保护隐私
4. 无 API 成本

### ADR-003: 文本分块策略
**决策:** 固定大小 + 重叠分块
**参数:** 512 tokens, 128 overlap
**原因:**
1. 简单可预测
2. 保持上下文连续性
3. 便于调试和测试

---

*设计完成日期: 2026-02-09*  
*版本: v1.0*  
*状态: 设计阶段*
