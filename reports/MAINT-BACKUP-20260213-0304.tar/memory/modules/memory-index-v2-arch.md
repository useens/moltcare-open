# 记忆索引系统 V2 架构设计文档

> **架构优化版本** - 从零依赖 JSON 到高性能 SQLite + FTS5
> 目标：O(1) 增量更新，<50ms 搜索响应，10万+文件支持

---

## 1. 当前架构分析

### 1.1 瓶颈识别

| 组件 | 当前实现 | 问题 | 影响 |
|------|----------|------|------|
| **存储层** | 单 JSON 文件 | O(n) 序列化，无事务，易损坏 | 1万文件 = 50MB+ JSON，加载慢 |
| **索引构建** | 内存倒排表 | 每次需重建所有索引 | O(n) 复杂度，文件越多越慢 |
| **并发控制** | 无 | 同时读写导致索引损坏 | 多进程/线程不安全 |
| **容错机制** | 无 | 损坏后需手动删除重建 | 用户体验差 |
| **搜索性能** | 内存遍历 | 需加载整个索引 | 搜索延迟随数据增长 |

### 1.2 性能基准（当前）

```
数据规模      索引大小    索引时间    搜索延迟
─────────────────────────────────────────────
1,000文件     5MB        200ms       15ms
10,000文件    50MB       2s          80ms
50,000文件    250MB      10s+        500ms+   ← 不可接受
100,000文件   500MB+     30s+        1s+      ← 完全不可用
```

### 1.3 核心问题总结

1. **JSON 存储瓶颈**：线性序列化，内存占用高，无法流式查询
2. **伪增量更新**：虽然检查 mtime，但仍需遍历所有文件构建倒排索引
3. **缺乏持久化变更追踪**：没有记录"哪些文件已索引"
4. **无并发保护**：多进程同时写入会导致数据损坏
5. **搜索需全量加载**：无法按需查询，索引越大越慢

---

## 2. V2 优化架构设计

### 2.1 架构总览

```
┌─────────────────────────────────────────────────────────────────┐
│                        Memory Index V2                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────────────┐ │
│  │  File Watch │    │   Indexer   │    │    Search Engine    │ │
│  │  (可选)     │───>│   Engine    │───>│                     │ │
│  └─────────────┘    └──────┬──────┘    └─────────────────────┘ │
│                            │                                     │
│                            ▼                                     │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │                    SQLite + FTS5 Layer                      │ │
│  │  ┌──────────────┐  ┌──────────────┐  ┌─────────────────┐   │ │
│  │  │  documents   │  │ documents_fts│  │   file_state    │   │ │
│  │  │   主内容表    │  │  全文索引表   │  │  文件状态追踪    │   │ │
│  │  └──────────────┘  └──────────────┘  └─────────────────┘   │ │
│  │  ┌──────────────┐  ┌──────────────┐  ┌─────────────────┐   │ │
│  │  │    tags      │  │ index_meta   │  │   search_log    │   │ │
│  │  │   标签表      │  │  索引元数据   │  │   搜索日志      │   │ │
│  │  └──────────────┘  └──────────────┘  └─────────────────┘   │ │
│  └────────────────────────────────────────────────────────────┘ │
│                            │                                     │
│                            ▼                                     │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │              Lock Manager + WAL (并发控制层)                 │ │
│  │  - 文件锁: .memory-index.lock                              │ │
│  │  - WAL 模式: 读写分离，并发安全                             │ │
│  │  - 事务: 原子性更新，失败回滚                               │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 核心优化策略

```
┌──────────────────────────────────────────────────────────────────┐
│                         优化对比矩阵                              │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│   维度        V1 (JSON)              V2 (SQLite+FTS5)           │
│   ─────────────────────────────────────────────────────────────  │
│   存储        单 JSON 文件           SQLite 数据库文件           │
│   序列化      O(n) 全量读写          页级随机访问，O(1) 查询     │
│   事务        无                      ACID 事务支持              │
│   全文搜索    内存倒排表遍历          FTS5 虚拟表 + BM25         │
│   增量更新    伪增量 (需遍历文件)      真增量 (基于哈希状态)      │
│   并发        不安全                  文件锁 + WAL 模式          │
│   容错        无                      损坏检测 + 自动重建        │
│   搜索延迟    ~80ms (1万文件)         ~10ms (10万文件)           │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

---

## 3. 数据库设计

### 3.1 表结构定义

```sql
-- ================================================================
-- 1. 文档主表 - 存储记忆文件的核心内容
-- ================================================================
CREATE TABLE IF NOT EXISTS documents (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    doc_id          TEXT UNIQUE NOT NULL,           -- 业务ID: 相对路径哈希
    file_path       TEXT NOT NULL,                   -- 相对路径 (如: daily/2026-02-08.md)
    full_path       TEXT NOT NULL,                   -- 绝对路径
    
    -- 内容字段
    title           TEXT,                            -- 提取的标题
    content_hash    TEXT NOT NULL,                   -- 内容 MD5 哈希 (变更检测)
    summary         TEXT,                            -- 摘要 (前500字符)
    headers         TEXT,                            -- JSON: 标题结构
    
    -- 文件元数据
    file_size       INTEGER NOT NULL,                -- 文件大小 (字节)
    file_mtime      INTEGER NOT NULL,                -- 修改时间 (Unix ms)
    
    -- 业务元数据
    category        TEXT,                            -- 分类 (从路径推导)
    importance      INTEGER DEFAULT 5,               -- 重要性 1-10
    
    -- 时间戳
    created_at      INTEGER NOT NULL,                -- 首次索引时间
    updated_at      INTEGER NOT NULL,                -- 最后更新时间
    indexed_at      INTEGER NOT NULL                 -- 最后索引时间
);

-- 核心索引
CREATE INDEX idx_documents_path ON documents(file_path);
CREATE INDEX idx_documents_hash ON documents(content_hash);
CREATE INDEX idx_documents_mtime ON documents(file_mtime);
CREATE INDEX idx_documents_category ON documents(category);
CREATE INDEX idx_documents_updated ON documents(updated_at);

-- ================================================================
-- 2. FTS5 全文搜索虚拟表 - 高性能搜索核心
-- ================================================================
CREATE VIRTUAL TABLE IF NOT EXISTS documents_fts USING fts5(
    title,                      -- 标题 (权重最高)
    content,                    -- 正文内容 (标准权重)
    tags,                       -- 标签空格分隔 (高权重)
    
    -- 外部内容表配置
    content='documents',        -- 关联 documents 表
    content_rowid='id',         -- 关联主键
    
    -- 分词器配置
    -- unicode61: 支持中文、英文等多语言
    -- porter: 英语词干提取
    -- remove_diacritics 2: 移除重音符号
    tokenize='unicode61 remove_diacritics 2',
    
    -- 前缀索引: 加速前缀搜索 (2/3/4字符)
    prefix='2 3 4'
);

-- ================================================================
-- 3. 文件状态追踪表 - 实现真增量索引的关键
-- ================================================================
CREATE TABLE IF NOT EXISTS file_state (
    file_path       TEXT PRIMARY KEY,                -- 相对路径
    file_mtime      INTEGER NOT NULL,                -- 最后记录的修改时间
    file_size       INTEGER NOT NULL,                -- 最后记录的文件大小
    content_hash    TEXT NOT NULL,                   -- 最后记录的内容哈希
    
    doc_id          INTEGER REFERENCES documents(id) ON DELETE SET NULL,
    indexed_at      INTEGER NOT NULL,                -- 索引时间
    
    -- 状态标记
    status          TEXT DEFAULT 'indexed'           -- indexed | deleted | modified
);

CREATE INDEX idx_file_state_hash ON file_state(content_hash);
CREATE INDEX idx_file_state_status ON file_state(status);

-- ================================================================
-- 4. 标签系统
-- ================================================================
CREATE TABLE IF NOT EXISTS tags (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT UNIQUE NOT NULL,
    count       INTEGER DEFAULT 0,
    created_at  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS document_tags (
    doc_id      INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    tag_id      INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (doc_id, tag_id)
);

CREATE INDEX idx_doc_tags_tag ON document_tags(tag_id);

-- ================================================================
-- 5. 索引元数据表 - 状态管理和版本控制
-- ================================================================
CREATE TABLE IF NOT EXISTS index_meta (
    key         TEXT PRIMARY KEY,
    value       TEXT NOT NULL,
    updated_at  INTEGER NOT NULL
);

-- 初始化元数据
INSERT OR IGNORE INTO index_meta (key, value, updated_at) VALUES
    ('version', '2.0.0', 0),
    ('schema_version', '1', 0),
    ('total_documents', '0', 0),
    ('last_full_index', '0', 0),
    ('last_incremental_index', '0', 0),
    ('index_corrupted', '0', 0);

-- ================================================================
-- 6. 搜索历史表 - 查询优化和自动补全
-- ================================================================
CREATE TABLE IF NOT EXISTS search_history (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    query           TEXT NOT NULL,
    query_hash      TEXT NOT NULL,                   -- 查询哈希 (去重用)
    filters         TEXT,                            -- JSON: 使用的过滤条件
    results_count   INTEGER,
    search_time_ms  INTEGER,                         -- 搜索耗时
    created_at      INTEGER NOT NULL
);

CREATE INDEX idx_search_history_hash ON search_history(query_hash);
CREATE INDEX idx_search_history_created ON search_history(created_at);

-- ================================================================
-- 7. 索引队列表 - 支持异步批量索引
-- ================================================================
CREATE TABLE IF NOT EXISTS index_queue (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    file_path       TEXT NOT NULL,
    operation       TEXT NOT NULL,                   -- add | update | delete
    priority        INTEGER DEFAULT 5,               -- 1-10, 数字越小优先级越高
    retries         INTEGER DEFAULT 0,
    error_msg       TEXT,
    created_at      INTEGER NOT NULL,
    processed_at    INTEGER
);

CREATE INDEX idx_index_queue_pending ON index_queue(processed_at, priority, created_at);
```

### 3.2 触发器设计（自动同步 FTS）

```sql
-- ================================================================
-- FTS5 自动同步触发器
-- ================================================================

-- 插入时同步到 FTS
CREATE TRIGGER IF NOT EXISTS trg_documents_fts_insert 
AFTER INSERT ON documents
BEGIN
    INSERT INTO documents_fts(rowid, title, content, tags)
    VALUES (
        NEW.id,
        COALESCE(NEW.title, ''),
        COALESCE(NEW.summary, ''),
        COALESCE((SELECT group_concat(t.name, ' ') 
                  FROM tags t 
                  JOIN document_tags dt ON t.id = dt.tag_id 
                  WHERE dt.doc_id = NEW.id), '')
    );
END;

-- 更新时同步
CREATE TRIGGER IF NOT EXISTS trg_documents_fts_update
AFTER UPDATE ON documents
BEGIN
    UPDATE documents_fts SET
        title = COALESCE(NEW.title, ''),
        content = COALESCE(NEW.summary, ''),
        tags = COALESCE((SELECT group_concat(t.name, ' ') 
                         FROM tags t 
                         JOIN document_tags dt ON t.id = dt.tag_id 
                         WHERE dt.doc_id = NEW.id), '')
    WHERE rowid = NEW.id;
END;

-- 删除时同步
CREATE TRIGGER IF NOT EXISTS trg_documents_fts_delete
AFTER DELETE ON documents
BEGIN
    DELETE FROM documents_fts WHERE rowid = OLD.id;
END;

-- ================================================================
-- 标签计数自动维护触发器
-- ================================================================

CREATE TRIGGER IF NOT EXISTS trg_tag_count_insert
AFTER INSERT ON document_tags
BEGIN
    UPDATE tags SET count = count + 1 WHERE id = NEW.tag_id;
END;

CREATE TRIGGER IF NOT EXISTS trg_tag_count_delete
AFTER DELETE ON document_tags
BEGIN
    UPDATE tags SET count = count - 1 WHERE id = OLD.tag_id;
END;
```

---

## 4. 增量索引算法（O(1) 更新）

### 4.1 核心算法流程

```
┌─────────────────────────────────────────────────────────────────────┐
│                      真增量索引算法流程                               │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│   输入: 文件系统当前状态                                              │
│   输出: 需要索引的文件列表                                            │
│                                                                      │
│   ┌─────────────────────────────────────────────────────────────┐   │
│   │  Phase 1: 扫描检测 (Scan Phase)                             │   │
│   │  ─────────────────────────────────────────────────────────  │   │
│   │                                                              │   │
│   │  1. 扫描 memory/ 目录获取当前所有 .md 文件                   │   │
│   │     → 得到: current_files[] {path, mtime, size}              │   │
│   │                                                              │   │
│   │  2. 从 file_state 表读取上次索引状态                         │   │
│   │     → 得到: indexed_files[] {path, mtime, size, hash}        │   │
│   │                                                              │   │
│   │  3. 对比计算变更集                                            │   │
│   │     ┌─────────────┐  ┌─────────────┐  ┌─────────────┐        │   │
│   │     │   ADDED     │  │  MODIFIED   │  │   DELETED   │        │   │
│   │     │  (新增)     │  │   (修改)    │  │   (删除)    │        │   │
│   │     └─────────────┘  └─────────────┘  └─────────────┘        │   │
│   │                                                              │   │
│   │  ADDED:    current 有但 indexed 没有                          │   │
│   │  MODIFIED: path 相同但 mtime/size/hash 不同                   │   │
│   │  DELETED:  indexed 有但 current 没有                          │   │
│   │                                                              │   │
│   └─────────────────────────────────────────────────────────────┘   │
│                              │                                        │
│                              ▼                                        │
│   ┌─────────────────────────────────────────────────────────────┐   │
│   │  Phase 2: 增量处理 (Update Phase)                           │   │
│   │  ─────────────────────────────────────────────────────────  │   │
│   │                                                              │   │
│   │  4. 处理 DELETED                                             │   │
│   │     DELETE FROM documents WHERE file_path IN (deleted)       │   │
│   │     UPDATE file_state SET status='deleted'                   │   │
│   │     → 触发器自动清理 FTS 和标签关联                           │   │
│   │                                                              │   │
│   │  5. 处理 ADDED                                               │   │
│   │     解析文件 → 提取元数据 → 计算 hash                        │   │
│   │     INSERT INTO documents (...)                              │   │
│   │     INSERT/UPDATE file_state                                 │   │
│   │     → 触发器自动更新 FTS                                     │   │
│   │                                                              │   │
│   │  6. 处理 MODIFIED                                            │   │
│   │     重新解析文件 → 计算新 hash                               │   │
│   │     如果 hash 不同:                                          │   │
│   │       UPDATE documents SET ...                               │   │
│   │       UPDATE file_state SET hash=..., mtime=...              │   │
│   │     如果 hash 相同 (仅 touch):                               │   │
│   │       仅 UPDATE file_state.mtime                             │   │
│   │                                                              │   │
│   └─────────────────────────────────────────────────────────────┘   │
│                              │                                        │
│                              ▼                                        │
│   ┌─────────────────────────────────────────────────────────────┐   │
│   │  Phase 3: 优化 (Optimize Phase)                             │   │
│   │  ─────────────────────────────────────────────────────────  │   │
│   │                                                              │   │
│   │  7. 批量更新标签计数                                         │   │
│   │  8. 如变更>1000条: INSERT INTO documents_fts(documents_fts)  │   │
│   │     VALUES('optimize')                                       │   │
│   │  9. 更新 index_meta 统计信息                                 │   │
│   │                                                              │   │
│   └─────────────────────────────────────────────────────────────┘   │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

### 4.2 算法实现（伪代码）

```javascript
class IncrementalIndexer {
    constructor(db, options = {}) {
        this.db = db;
        this.memoryDir = options.memoryDir || './memory';
        this.batchSize = options.batchSize || 100;
        this.hashAlgorithm = options.hashAlgorithm || 'xxhash64'; // 比 MD5 快 3-5x
    }

    /**
     * 执行增量索引 - 核心算法
     * 复杂度: O(m) 其中 m = 变更文件数，而非总文件数
     */
    async runIncrementalIndex() {
        const startTime = performance.now();
        
        // ─────────────────────────────────────────────────────────
        // Phase 1: 扫描检测
        // ─────────────────────────────────────────────────────────
        
        // 1.1 获取当前文件系统状态（快速扫描）
        const currentFiles = await this.scanDirectory(this.memoryDir);
        // → [{path: 'daily/2026-02-08.md', mtime: 173..., size: 1024}, ...]
        
        // 1.2 获取已索引状态（单次数据库查询）
        const indexedFiles = await this.db.all(`
            SELECT file_path, file_mtime, file_size, content_hash, doc_id
            FROM file_state
            WHERE status = 'indexed'
        `);
        // → Map<path, {mtime, size, hash}>
        
        // 1.3 计算变更集（内存中 O(n) 对比，n=总文件数，但无IO）
        const changes = this.computeChanges(currentFiles, indexedFiles);
        // → {
        //     added: [{path, mtime, size}, ...],
        //     modified: [{path, mtime, size, oldHash}, ...],
        //     deleted: [{path, doc_id}, ...]
        //   }
        
        if (changes.isEmpty()) {
            console.log('✅ 所有文件已是最新，无需更新');
            return { updated: 0, deleted: 0, time: 0 };
        }
        
        console.log(`📊 检测到变更: +${changes.added.length} ~${changes.modified.length} -${changes.deleted.length}`);
        
        // ─────────────────────────────────────────────────────────
        // Phase 2: 增量处理（事务中）
        // ─────────────────────────────────────────────────────────
        
        await this.db.transaction(async (trx) => {
            // 2.1 处理删除（最快，无文件读取）
            if (changes.deleted.length > 0) {
                await this.processDeletions(trx, changes.deleted);
            }
            
            // 2.2 处理新增（需读取文件）
            if (changes.added.length > 0) {
                await this.processAdditions(trx, changes.added);
            }
            
            // 2.3 处理修改（需读取文件验证 hash）
            if (changes.modified.length > 0) {
                await this.processModifications(trx, changes.modified);
            }
        });
        
        // ─────────────────────────────────────────────────────────
        // Phase 3: 优化
        // ─────────────────────────────────────────────────────────
        
        const totalChanges = changes.added.length + changes.modified.length + changes.deleted.length;
        
        if (totalChanges > 1000) {
            // 大量变更时优化 FTS 索引
            await this.db.run(`INSERT INTO documents_fts(documents_fts) VALUES('optimize')`);
        }
        
        // 更新统计信息
        await this.updateStats();
        
        const duration = performance.now() - startTime;
        
        return {
            added: changes.added.length,
            modified: changes.modified.length,
            deleted: changes.deleted.length,
            time: duration
        };
    }

    /**
     * 计算变更集 - 核心优化点
     * 使用 Map 实现 O(1) 查找
     */
    computeChanges(currentFiles, indexedFiles) {
        const indexedMap = new Map(indexedFiles.map(f => [f.file_path, f]));
        const currentMap = new Map(currentFiles.map(f => [f.path, f]));
        
        const added = [];
        const modified = [];
        const deleted = [];
        
        // 检测新增和修改
        for (const [path, current] of currentMap) {
            const indexed = indexedMap.get(path);
            
            if (!indexed) {
                // 新增文件
                added.push(current);
            } else if (current.mtime !== indexed.file_mtime || 
                       current.size !== indexed.file_size) {
                // 可能修改：mtime 或 size 变化
                // 注意：这里不读取文件内容，延迟到 processModifications 再验证 hash
                modified.push({
                    ...current,
                    oldHash: indexed.content_hash,
                    docId: indexed.doc_id
                });
            }
            // 如果 mtime 和 size 都相同，认为未变更（O(1) 判断）
        }
        
        // 检测删除
        for (const [path, indexed] of indexedMap) {
            if (!currentMap.has(path)) {
                deleted.push({ path, docId: indexed.doc_id });
            }
        }
        
        return { added, modified, deleted };
    }

    /**
     * 处理新增文件 - 批量插入
     */
    async processAdditions(trx, files) {
        for (let i = 0; i < files.length; i += this.batchSize) {
            const batch = files.slice(i, i + this.batchSize);
            
            // 并行解析文件
            const parsedFiles = await Promise.all(
                batch.map(async (file) => {
                    const content = await fs.readFile(file.fullPath, 'utf8');
                    const hash = this.computeHash(content);
                    const metadata = this.extractMetadata(content, file.path);
                    
                    return {
                        ...file,
                        content,
                        hash,
                        ...metadata
                    };
                })
            );
            
            // 批量插入 documents
            const placeholders = parsedFiles.map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').join(',');
            const values = parsedFiles.flatMap(f => [
                this.generateDocId(f.path),
                f.path,
                f.fullPath,
                f.title,
                f.hash,
                f.summary,
                JSON.stringify(f.headers),
                f.size,
                f.mtime,
                f.category,
                Date.now(),
                Date.now()
            ]);
            
            const result = await trx.run(`
                INSERT INTO documents 
                (doc_id, file_path, full_path, title, content_hash, summary, 
                 headers, file_size, file_mtime, category, created_at, updated_at, indexed_at)
                VALUES ${placeholders}
                RETURNING id
            `, ...values);
            
            // 批量插入 file_state
            // ...（类似批量插入）
            
            // 批量处理标签
            for (const file of parsedFiles) {
                await this.upsertTags(trx, file.tags);
                await this.linkDocumentTags(trx, result.lastID, file.tags);
            }
        }
    }

    /**
     * 处理修改文件 - 仅在 hash 真正变化时才更新
     */
    async processModifications(trx, files) {
        for (const file of files) {
            const content = await fs.readFile(file.fullPath, 'utf8');
            const newHash = this.computeHash(content);
            
            // 关键优化：如果 hash 相同，只是 touch，不更新内容
            if (newHash === file.oldHash) {
                // 仅更新 mtime
                await trx.run(`
                    UPDATE file_state 
                    SET file_mtime = ?, indexed_at = ?
                    WHERE file_path = ?
                `, file.mtime, Date.now(), file.path);
                continue;
            }
            
            // hash 变化，真正需要更新
            const metadata = this.extractMetadata(content, file.path);
            
            await trx.run(`
                UPDATE documents SET
                    title = ?,
                    content_hash = ?,
                    summary = ?,
                    headers = ?,
                    file_size = ?,
                    file_mtime = ?,
                    updated_at = ?,
                    indexed_at = ?
                WHERE id = ?
            `, metadata.title, newHash, metadata.summary, 
               JSON.stringify(metadata.headers), file.size, file.mtime,
               Date.now(), Date.now(), file.docId);
            
            // 更新 file_state
            await trx.run(`
                UPDATE file_state 
                SET content_hash = ?, file_mtime = ?, file_size = ?, indexed_at = ?
                WHERE file_path = ?
            `, newHash, file.mtime, file.size, Date.now(), file.path);
            
            // 更新标签关联
            await this.updateDocumentTags(trx, file.docId, metadata.tags);
        }
    }

    /**
     * 处理删除 - 级联删除自动处理关联
     */
    async processDeletions(trx, files) {
        const docIds = files.map(f => f.docId).filter(Boolean);
        
        if (docIds.length > 0) {
            // 批量删除 documents（触发器自动清理 FTS 和标签）
            const placeholders = docIds.map(() => '?').join(',');
            await trx.run(`
                DELETE FROM documents WHERE id IN (${placeholders})
            `, ...docIds);
        }
        
        // 标记 file_state 为 deleted
        for (const file of files) {
            await trx.run(`
                UPDATE file_state 
                SET status = 'deleted', indexed_at = ?
                WHERE file_path = ?
            `, Date.now(), file.path);
        }
    }
}
```

### 4.3 性能对比

```
场景: 10万文件，其中 100 个文件发生变更
─────────────────────────────────────────────────────────

V1 (JSON)                   V2 (SQLite 增量)
─────────────────────────────────────────────────────────
扫描:   O(n) = 100,000      O(n) = 100,000 (但更快 IO)
读取:   O(n) = 100,000      O(1) = 100 (仅变更文件)
解析:   O(n) = 100,000      O(1) = 100
写入:   O(n) = 50MB JSON    O(m) = 100 条 INSERT
─────────────────────────────────────────────────────────
时间:   ~10s                ~50ms (200x 提升)
内存:   500MB+              ~10MB

关键优化:
1. 文件状态持久化到 DB (file_state 表)
2. mtime/size 快速过滤 (无需读取文件)
3. hash 验证真正变更 (避免不必要的解析)
4. 批量插入 (减少事务开销)
5. 触发器自动维护 FTS (无需手动重建)
```

---

## 5. 并发安全设计

### 5.1 文件锁机制

```javascript
import { promises as fs } from 'fs';
import path from 'path';

/**
 * 跨进程文件锁 - 使用 Node.js 的原子操作
 */
class FileLock {
    constructor(lockFilePath) {
        this.lockFile = lockFilePath;
        this.lockFd = null;
    }

    /**
     * 获取锁 - 非阻塞
     * @returns {Promise<boolean>} 是否成功获取锁
     */
    async acquire(timeoutMs = 5000) {
        const startTime = Date.now();
        
        while (Date.now() - startTime < timeoutMs) {
            try {
                // O_EXCL 标志确保原子性创建
                this.lockFd = await fs.open(this.lockFile, 'wx');
                
                // 写入 PID 便于调试
                await this.lockFd.write(process.pid.toString());
                await this.lockFd.sync();
                
                return true;
            } catch (err) {
                if (err.code === 'EEXIST') {
                    // 锁已被占用，检查是否死锁
                    const stale = await this.isStaleLock();
                    if (stale) {
                        await this.forceUnlock();
                        continue;
                    }
                    
                    // 等待后重试
                    await this.sleep(100);
                } else {
                    throw err;
                }
            }
        }
        
        return false;
    }

    /**
     * 释放锁
     */
    async release() {
        if (this.lockFd) {
            await this.lockFd.close();
            this.lockFd = null;
        }
        
        try {
            await fs.unlink(this.lockFile);
        } catch (err) {
            // 可能已被其他进程释放
            if (err.code !== 'ENOENT') throw err;
        }
    }

    /**
     * 检查锁是否过期（防止死锁）
     */
    async isStaleLock(maxAgeMs = 60000) {
        try {
            const stat = await fs.stat(this.lockFile);
            return Date.now() - stat.mtimeMs > maxAgeMs;
        } catch {
            return false;
        }
    }

    /**
     * 强制解锁（清理死锁）
     */
    async forceUnlock() {
        try {
            await fs.unlink(this.lockFile);
        } catch (err) {
            if (err.code !== 'ENOENT') throw err;
        }
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}
```

### 5.2 SQLite WAL 模式配置

```sql
-- ================================================================
-- 并发优化配置 - WAL (Write-Ahead Logging) 模式
-- ================================================================

-- 启用 WAL 模式 - 读写不阻塞
PRAGMA journal_mode = WAL;

-- WAL 模式优势:
-- 1. 读操作不会阻塞写操作
-- 2. 写操作不会阻塞读操作
-- 3. 性能通常比 DELETE 模式更好
-- 4. 崩溃恢复更快

-- 同步模式设置
PRAGMA synchronous = NORMAL;  -- 平衡性能和安全性
-- FULL: 最安全，但最慢
-- NORMAL: 推荐设置，WAL 模式下安全
-- OFF: 最快，但可能损坏 (不推荐)

-- 缓存大小
PRAGMA cache_size = -64000;  -- 64MB 页缓存 (负值表示 KB)
PRAGMA temp_store = MEMORY;   -- 临时表存内存

-- WAL 检查点设置
PRAGMA wal_autocheckpoint = 1000;  -- 1000 页后自动 checkpoint

-- 忙等待超时（避免 "database is locked"）
PRAGMA busy_timeout = 5000;  -- 等待 5 秒
```

### 5.3 并发控制层实现

```javascript
class ConcurrentIndexManager {
    constructor(dbPath, options = {}) {
        this.dbPath = dbPath;
        this.lockFile = dbPath + '.lock';
        this.lock = new FileLock(this.lockFile);
        this.db = null;
    }

    /**
     * 初始化数据库（带锁保护）
     */
    async initialize() {
        const acquired = await this.lock.acquire(10000);
        if (!acquired) {
            throw new Error('无法获取索引锁，可能其他进程正在使用');
        }

        try {
            // 初始化 SQLite 连接
            this.db = await this.openDatabase();
            
            // 启用 WAL 模式
            await this.db.run('PRAGMA journal_mode = WAL');
            await this.db.run('PRAGMA synchronous = NORMAL');
            await this.db.run('PRAGMA cache_size = -64000');
            await this.db.run('PRAGMA busy_timeout = 5000');
            
            // 初始化表结构
            await this.initSchema();
            
        } finally {
            await this.lock.release();
        }
    }

    /**
     * 执行索引更新（带锁保护）
     */
    async withWriteLock(operation) {
        const acquired = await this.lock.acquire(30000);
        if (!acquired) {
            throw new Error('获取写锁超时');
        }

        try {
            return await operation();
        } finally {
            await this.lock.release();
        }
    }

    /**
     * 搜索（读操作，WAL 模式下无需锁）
     */
    async search(query, options = {}) {
        // WAL 模式下读操作不阻塞，无需获取锁
        const searcher = new MemorySearch(this.db);
        return await searcher.search(query, options);
    }

    /**
     * 增量索引（带写锁保护）
     */
    async incrementalIndex() {
        return await this.withWriteLock(async () => {
            const indexer = new IncrementalIndexer(this.db);
            return await indexer.runIncrementalIndex();
        });
    }
}
```

---

## 6. 容错机制设计

### 6.1 索引损坏检测

```javascript
class IndexHealthChecker {
    constructor(db) {
        this.db = db;
    }

    /**
     * 全面健康检查
     */
    async checkHealth() {
        const checks = await Promise.all([
            this.checkDatabaseIntegrity(),
            this.checkFtsIntegrity(),
            this.checkFileStateConsistency(),
            this.checkOrphanedRecords()
        ]);

        const issues = checks.flat();
        
        return {
            healthy: issues.length === 0,
            issues,
            severity: this.calculateSeverity(issues)
        };
    }

    /**
     * 检查数据库完整性
     */
    async checkDatabaseIntegrity() {
        const issues = [];
        
        try {
            // PRAGMA integrity_check 会扫描整个数据库
            const result = await this.db.get('PRAGMA integrity_check');
            
            if (result.integrity_check !== 'ok') {
                issues.push({
                    type: 'database_corruption',
                    severity: 'critical',
                    message: '数据库完整性检查失败: ' + result.integrity_check
                });
            }
            
            // 检查 FTS 表完整性
            const ftsCheck = await this.db.get(`
                SELECT COUNT(*) as count FROM documents_fts 
                WHERE rowid NOT IN (SELECT id FROM documents)
            `);
            
            if (ftsCheck.count > 0) {
                issues.push({
                    type: 'fts_orphaned',
                    severity: 'high',
                    message: `FTS 表中有 ${ftsCheck.count} 条孤立记录`
                });
            }
            
        } catch (err) {
            issues.push({
                type: 'integrity_check_error',
                severity: 'critical',
                message: err.message
            });
        }
        
        return issues;
    }

    /**
     * 检查文件状态一致性
     */
    async checkFileStateConsistency() {
        const issues = [];
        
        // 检查 file_state 中的记录是否都有对应的 documents
        const orphaned = await this.db.all(`
            SELECT fs.file_path
            FROM file_state fs
            LEFT JOIN documents d ON fs.doc_id = d.id
            WHERE fs.status = 'indexed' AND d.id IS NULL
        `);
        
        if (orphaned.length > 0) {
            issues.push({
                type: 'file_state_orphaned',
                severity: 'medium',
                message: `${orphaned.length} 个 file_state 记录缺少对应文档`,
                paths: orphaned.map(o => o.file_path)
            });
        }
        
        return issues;
    }
}
```

### 6.2 自动修复机制

```javascript
class IndexRepairService {
    constructor(db, memoryDir) {
        this.db = db;
        this.memoryDir = memoryDir;
        this.checker = new IndexHealthChecker(db);
    }

    /**
     * 自动修复索引
     */
    async autoRepair(options = {}) {
        const health = await this.checker.checkHealth();
        
        if (health.healthy) {
            return { repaired: false, message: '索引健康，无需修复' };
        }

        const repairs = [];
        
        for (const issue of health.issues) {
            switch (issue.type) {
                case 'database_corruption':
                    await this.rebuildDatabase();
                    repairs.push('重建整个数据库');
                    break;
                    
                case 'fts_orphaned':
                    await this.rebuildFtsIndex();
                    repairs.push('重建 FTS 索引');
                    break;
                    
                case 'file_state_orphaned':
                    await this.cleanOrphanedFileState();
                    repairs.push('清理孤立的 file_state 记录');
                    break;
                    
                // 其他修复...
            }
        }
        
        return { repaired: true, repairs };
    }

    /**
     * 重建 FTS 索引（轻量级修复）
     */
    async rebuildFtsIndex() {
        // 方法1: 使用 rebuild 命令
        await this.db.run(`INSERT INTO documents_fts(documents_fts) VALUES('rebuild')`);
        
        // 方法2: 手动重建（如果方法1失败）
        // await this.db.run('DELETE FROM documents_fts');
        // await this.db.run(`
        //     INSERT INTO documents_fts(rowid, title, content, tags)
        //     SELECT d.id, d.title, d.summary, 
        //            COALESCE(GROUP_CONCAT(t.name, ' '), '')
        //     FROM documents d
        //     LEFT JOIN document_tags dt ON d.id = dt.doc_id
        //     LEFT JOIN tags t ON dt.tag_id = t.id
        //     GROUP BY d.id
        // `);
    }

    /**
     * 完整数据库重建（最后手段）
     */
    async rebuildDatabase() {
        // 1. 备份现有数据
        const backupPath = this.dbPath + '.backup.' + Date.now();
        await fs.copyFile(this.dbPath, backupPath);
        
        // 2. 导出文件列表
        const fileStates = await this.db.all(`
            SELECT file_path, content_hash FROM file_state WHERE status = 'indexed'
        `);
        
        // 3. 关闭连接并删除损坏的数据库
        await this.db.close();
        await fs.unlink(this.dbPath);
        await fs.unlink(this.dbPath + '-shm').catch(() => {});
        await fs.unlink(this.dbPath + '-wal').catch(() => {});
        
        // 4. 重新初始化
        await this.initialize();
        
        // 5. 重建索引（利用 hash 跳过未变更文件）
        const indexer = new IncrementalIndexer(this.db);
        await indexer.runIncrementalIndex();
        
        return { success: true, backupPath };
    }
}
```

### 6.3 事务与回滚

```javascript
class TransactionManager {
    constructor(db) {
        this.db = db;
    }

    /**
     * 执行带自动重试的事务
     */
    async withTransaction(operation, maxRetries = 3) {
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                await this.db.run('BEGIN IMMEDIATE');
                
                const result = await operation(this.db);
                
                await this.db.run('COMMIT');
                return result;
                
            } catch (err) {
                await this.db.run('ROLLBACK').catch(() => {});
                
                if (err.code === 'SQLITE_BUSY' && attempt < maxRetries) {
                    // 忙等待，指数退避
                    await this.sleep(Math.pow(2, attempt) * 100);
                    continue;
                }
                
                throw err;
            }
        }
    }

    /**
     * 部分失败处理 - 记录失败的文件继续处理其他
     */
    async withPartialFailureHandling(files, processor) {
        const success = [];
        const failed = [];
        
        for (const file of files) {
            try {
                await processor(file);
                success.push(file);
            } catch (err) {
                failed.push({ file, error: err.message });
                // 记录到 index_queue 稍后重试
                await this.recordFailedOperation(file, err.message);
            }
        }
        
        return { success, failed };
    }

    async recordFailedOperation(file, error) {
        await this.db.run(`
            INSERT INTO index_queue (file_path, operation, error_msg, created_at)
            VALUES (?, 'retry', ?, ?)
        `, file.path, error, Date.now());
    }
}
```

---

## 7. 搜索接口设计

### 7.1 API 定义

```typescript
// 搜索选项
interface SearchOptions {
    query: string;
    
    // 过滤条件
    filters?: {
        categories?: string[];        // 分类过滤
        tags?: string[];              // 标签过滤 (AND)
        tagsAny?: boolean;            // true=OR, false=AND
        dateFrom?: number;            // 开始时间戳
        dateTo?: number;              // 结束时间戳
        importanceMin?: number;       // 最小重要性
        pathPattern?: string;         // 路径通配符
    };
    
    // 排序
    sort?: {
        field: 'relevance' | 'date' | 'importance' | 'title';
        order: 'asc' | 'desc';
    };
    
    // 分页
    pagination?: {
        limit: number;                // 默认 20，最大 100
        offset: number;               // 默认 0
    };
    
    // 高亮
    highlight?: {
        enabled: boolean;
        startTag: string;             // 默认: '<mark>'
        endTag: string;               // 默认: '</mark>'
        snippetLength: number;        // 默认: 150
    };
}

// 搜索结果
interface SearchResult {
    documents: Document[];
    total: number;
    hasMore: boolean;
    queryTimeMs: number;
    
    // 查询分析
    analysis?: {
        tokens: string[];             // 分词结果
        expandedQuery?: string;       // 扩展后的查询
    };
}

// 文档结构
interface Document {
    id: string;
    path: string;
    title: string;
    summary: string;
    tags: string[];
    category: string;
    importance: number;
    createdAt: number;
    modifiedAt: number;
    relevanceScore: number;
    highlights?: {
        title?: string;
        content?: string;
    };
}
```

### 7.2 核心搜索 SQL

```sql
-- ================================================================
-- 基础全文搜索 - 使用 BM25 排序
-- ================================================================

SELECT 
    d.*,
    -- BM25 分数 (越小越相关)
    -- 权重: title=10.0, content=5.0, tags=8.0
    bm25(documents_fts, 10.0, 5.0, 8.0) as relevance_score,
    
    -- 内容片段（带高亮标记）
    snippet(documents_fts, 1, '<mark>', '</mark>', '...', 32) as content_snippet

FROM documents_fts
JOIN documents d ON documents_fts.rowid = d.id

WHERE documents_fts MATCH :query

ORDER BY relevance_score ASC
LIMIT :limit OFFSET :offset;


-- ================================================================
-- 高级过滤搜索
-- ================================================================

WITH matched_docs AS (
    SELECT 
        d.id,
        d.file_path,
        d.title,
        d.summary,
        d.file_mtime,
        d.importance,
        d.category,
        bm25(documents_fts, 10.0, 5.0, 8.0) as score
    FROM documents_fts
    JOIN documents d ON documents_fts.rowid = d.id
    WHERE documents_fts MATCH :query
),
tagged_docs AS (
    SELECT 
        md.*,
        GROUP_CONCAT(t.name) as doc_tags
    FROM matched_docs md
    LEFT JOIN document_tags dt ON md.id = dt.doc_id
    LEFT JOIN tags t ON dt.tag_id = t.id
    GROUP BY md.id
)
SELECT * FROM tagged_docs
WHERE 
    -- 分类过滤
    (:category IS NULL OR category = :category)
    
    -- 时间范围过滤
    AND (:date_from IS NULL OR file_mtime >= :date_from)
    AND (:date_to IS NULL OR file_mtime <= :date_to)
    
    -- 重要性过滤
    AND (:min_importance IS NULL OR importance >= :min_importance)
    
    -- 标签过滤 (AND 模式)
    AND (
        :tag_filter IS NULL 
        OR doc_tags LIKE '%' || :tag_filter || '%'
    )

ORDER BY 
    CASE WHEN :sort_by = 'relevance' THEN score END ASC,
    CASE WHEN :sort_by = 'date' THEN file_mtime END DESC,
    CASE WHEN :sort_by = 'importance' THEN importance END DESC

LIMIT :limit OFFSET :offset;


-- ================================================================
-- 前缀搜索（自动补全）
-- ================================================================

-- 方法1: 使用 FTS5 词汇表
SELECT DISTINCT term,
    (SELECT COUNT(*) FROM documents_fts WHERE documents_fts MATCH term || '*') as freq
FROM documents_fts_vocab
WHERE term >= :prefix AND term < :prefix || CHAR(255)
ORDER BY freq DESC
LIMIT 10;

-- 方法2: 从标签中建议
SELECT name as term, count as freq
FROM tags
WHERE name LIKE :prefix || '%'
ORDER BY count DESC
LIMIT 10;


-- ================================================================
-- 相关文档推荐（基于标签相似度）
-- ================================================================

WITH target_tags AS (
    SELECT t.id, t.name
    FROM tags t
    JOIN document_tags dt ON t.id = dt.tag_id
    WHERE dt.doc_id = :target_doc_id
),
related_by_tags AS (
    SELECT 
        d.id,
        d.title,
        d.file_path,
        COUNT(DISTINCT tt.id) as common_tags,
        d.file_mtime
    FROM documents d
    JOIN document_tags dt ON d.id = dt.doc_id
    JOIN target_tags tt ON dt.tag_id = tt.id
    WHERE d.id != :target_doc_id
    GROUP BY d.id
    HAVING common_tags >= 2  -- 至少2个共同标签
)
SELECT * FROM related_by_tags
ORDER BY common_tags DESC, file_mtime DESC
LIMIT 5;
```

### 7.3 搜索实现

```javascript
class MemorySearch {
    constructor(db) {
        this.db = db;
        this.queryCache = new Map(); // 简单 LRU 缓存
    }

    /**
     * 执行搜索
     */
    async search(query, options = {}) {
        const startTime = performance.now();
        
        // 1. 预处理查询
        const processedQuery = this.processQuery(query);
        
        // 2. 检查缓存
        const cacheKey = this.getCacheKey(processedQuery, options);
        if (this.queryCache.has(cacheKey)) {
            return this.queryCache.get(cacheKey);
        }
        
        // 3. 构建 SQL
        const { sql, params } = this.buildSearchSql(processedQuery, options);
        
        // 4. 执行查询
        const rows = await this.db.all(sql, params);
        
        // 5. 格式化结果
        const documents = rows.map(row => this.formatDocument(row, options.highlight));
        
        // 6. 获取总数
        const total = await this.getTotalCount(processedQuery, options.filters);
        
        const result = {
            documents,
            total,
            hasMore: (options.pagination?.offset || 0) + documents.length < total,
            queryTimeMs: performance.now() - startTime,
            analysis: {
                tokens: processedQuery.tokens
            }
        };
        
        // 7. 缓存结果
        this.cacheResult(cacheKey, result);
        
        // 8. 记录搜索历史
        await this.logSearch(query, total, result.queryTimeMs);
        
        return result;
    }

    /**
     * 查询预处理
     */
    processQuery(query) {
        // 转义 FTS5 特殊字符
        const escaped = query
            .replace(/"/g, '""')
            .replace(/\*/g, '')
            .replace(/\(/g, '')
            .replace(/\)/g: '')
            .trim();
        
        // 分词
        const tokens = escaped
            .split(/\s+/)
            .filter(t => t.length > 1);
        
        // 构建 FTS 查询字符串
        // 示例: "hello world" → "hello* AND world*"
        const ftsQuery = tokens.map(t => t + '*').join(' AND ');
        
        return {
            original: query,
            escaped,
            tokens,
            ftsQuery
        };
    }

    /**
     * 构建搜索 SQL
     */
    buildSearchSql(processedQuery, options) {
        const limit = Math.min(options.pagination?.limit || 20, 100);
        const offset = options.pagination?.offset || 0;
        
        let sql = `
            SELECT 
                d.*,
                bm25(documents_fts, 10.0, 5.0, 8.0) as relevance_score,
                snippet(documents_fts, 1, 
                    COALESCE(?, '<mark>'), 
                    COALESCE(?, '</mark>'), 
                    '...', 32) as content_snippet
            FROM documents_fts
            JOIN documents d ON documents_fts.rowid = d.id
            WHERE documents_fts MATCH ?
        `;
        
        const params = [
            options.highlight?.startTag,
            options.highlight?.endTag,
            processedQuery.ftsQuery
        ];
        
        // 添加过滤条件...
        
        sql += ` ORDER BY relevance_score ASC LIMIT ? OFFSET ?`;
        params.push(limit, offset);
        
        return { sql, params };
    }

    /**
     * 搜索建议（自动补全）
     */
    async suggest(prefix, limit = 10) {
        if (prefix.length < 2) return [];
        
        const suggestions = await this.db.all(`
            -- 标签建议
            SELECT name as term, count as weight
            FROM tags
            WHERE name LIKE ? || '%'
            
            UNION ALL
            
            -- 历史搜索建议
            SELECT query as term, COUNT(*) as weight
            FROM search_history
            WHERE query LIKE ? || '%'
            GROUP BY query
            
            ORDER BY weight DESC
            LIMIT ?
        `, prefix, prefix, limit);
        
        return suggestions.map(s => s.term);
    }
}
```

---

## 8. 性能目标与基准

### 8.1 性能指标

| 指标 | V1 (JSON) | V2 目标 | 提升倍数 |
|------|-----------|---------|----------|
| **搜索延迟 (10万文件)** | ~500ms | **< 50ms** | 10x |
| **增量索引 (100变更)** | ~10s | **< 50ms** | 200x |
| **全量索引 (10万文件)** | ~30s | **< 30s** | 1x (持平) |
| **内存占用** | 500MB+ | **< 50MB** | 10x |
| **并发安全** | 不支持 | **完全支持** | ∞ |
| **索引损坏恢复** | 手动 | **自动** | ∞ |
| **最大支持文件数** | ~2万 | **100万+** | 50x |

### 8.2 性能优化策略汇总

```
┌─────────────────────────────────────────────────────────────────┐
│                      性能优化策略矩阵                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  搜索优化                                                        │
│  ─────────────────────────────────────────────────────────────   │
│  1. FTS5 虚拟表 - C 级实现，比 JS 遍历快 100x+                   │
│  2. BM25 相关性排序 - 内置算法，无需自定义                        │
│  3. 前缀索引 - prefix='2 3 4' 配置                               │
│  4. 查询缓存 - LRU 缓存热门查询                                   │
│  5. 延迟加载 - 只返回摘要，内容按需读取                            │
│                                                                  │
│  索引优化                                                        │
│  ─────────────────────────────────────────────────────────────   │
│  1. 真增量 - 仅处理变更文件，O(1) 而非 O(n)                      │
│  2. 状态持久化 - file_state 表记录已索引状态                      │
│  3. 批量插入 - 每批 100 条，减少事务开销                          │
│  4. 触发器同步 - FTS 自动更新，无需手动维护                        │
│  5. WAL 模式 - 读写分离，并发不阻塞                                │
│                                                                  │
│  存储优化                                                        │
│  ─────────────────────────────────────────────────────────────   │
│  1. SQLite 页存储 - 随机访问，非全量加载                          │
│  2. 压缩 - 文本内容可配合 zlib 压缩                               │
│  3. 分离大内容 - 正文存文件，DB 只存摘要和索引                     │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### 8.3 部署架构建议

```
生产环境部署
─────────────────────────────────────────────────────────────

┌─────────────────────────────────────────────────────────┐
│                    OpenClaw Agent                        │
│  ┌─────────────────────────────────────────────────┐   │
│  │           Memory Index V2 Service                │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────┐  │   │
│  │  │   Indexer   │  │   Search    │  │  Watch  │  │   │
│  │  │   Engine    │  │   Engine    │  │  Dog    │  │   │
│  │  └──────┬──────┘  └──────┬──────┘  └────┬────┘  │   │
│  │         └─────────────────┴──────────────┘       │   │
│  │                         │                        │   │
│  │              ┌──────────┴──────────┐             │   │
│  │              ▼                     ▼             │   │
│  │  ┌─────────────────────┐  ┌───────────────┐     │   │
│  │  │   SQLite Database   │  │  File Lock    │     │   │
│  │  │  ┌───────────────┐  │  │  .index.lock  │     │   │
│  │  │  │ memory.db     │  │  └───────────────┘     │   │
│  │  │  │ memory.db-wal │  │                        │   │
│  │  │  └───────────────┘  │                        │   │
│  │  └─────────────────────┘                        │   │
│  └─────────────────────────────────────────────────┘   │
│                           │                            │
│                           ▼                            │
│  ┌─────────────────────────────────────────────────┐   │
│  │              Memory File System                  │   │
│  │         ~/memory/**/*.md (100,000 files)         │   │
│  └─────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────┘

定时任务 (cron):
  - 每 5 分钟: 增量索引
  - 每天凌晨: 全量校验 + 优化
  - 每周: 备份数据库
```

---

## 9. 迁移指南

### 9.1 从 V1 迁移到 V2

```javascript
class MigrationService {
    async migrateFromV1(v1IndexPath, v2DbPath) {
        console.log('🚀 开始从 V1 迁移到 V2...');
        
        // 1. 加载 V1 索引
        const v1Index = JSON.parse(await fs.readFile(v1IndexPath, 'utf8'));
        
        // 2. 初始化 V2 数据库
        const db = await openDatabase(v2DbPath);
        await this.initV2Schema(db);
        
        // 3. 迁移数据
        const files = Object.values(v1Index.files);
        console.log(`📁 迁移 ${files.length} 个文件...`);
        
        for (let i = 0; i < files.length; i += 100) {
            const batch = files.slice(i, i + 100);
            await this.migrateBatch(db, batch);
            console.log(`  已迁移 ${Math.min(i + 100, files.length)}/${files.length}`);
        }
        
        // 4. 重建 FTS 索引
        await db.run(`INSERT INTO documents_fts(documents_fts) VALUES('rebuild')`);
        
        // 5. 验证
        const count = await db.get('SELECT COUNT(*) as count FROM documents');
        console.log(`✅ 迁移完成: ${count.count} 个文档`);
        
        // 6. 备份 V1 索引
        await fs.rename(v1IndexPath, v1IndexPath + '.backup');
    }
}
```

---

## 10. 总结

### 10.1 核心优化点

| 优化维度 | 关键技术 | 效果 |
|----------|----------|------|
| **存储层** | SQLite + FTS5 | 页级随机访问，支持 100万+ 文件 |
| **增量索引** | file_state 状态表 + hash 验证 | O(1) 更新，50ms 内完成 |
| **并发安全** | 文件锁 + WAL 模式 | 读写分离，多进程安全 |
| **容错机制** | 完整性检查 + 自动重建 | 损坏自动修复，零人工干预 |
| **搜索性能** | FTS5 + BM25 + 前缀索引 | < 50ms 响应 |

### 10.2 实施路线图

```
Phase 1: 核心迁移 (2周)
  - 数据库设计和初始化
  - 基础增量索引
  - FTS5 搜索

Phase 2: 优化增强 (1周)
  - 并发控制和文件锁
  - 容错和自动修复
  - 性能调优

Phase 3: 高级功能 (1周)
  - 搜索建议
  - 相关推荐
  - 监控和统计
```

### 10.3 风险与缓解

| 风险 | 缓解措施 |
|------|----------|
| SQLite FTS5 未启用 | 运行时检测，回退到 V1 |
| 数据库损坏 | 自动检测 + 重建机制 |
| 迁移数据丢失 | 完整备份，可回滚到 V1 |
| 并发冲突 | 文件锁 + WAL 模式 + 重试 |

---

*文档版本: 2.0.0*  
*设计日期: 2026-02-09*  
*架构师: AI Assistant*
