# 记忆索引 Skill 设计文档

## 需求分析
- 好用：简单易用，自动索引
- 效率高：快速检索，秒级响应
- 低 token：本地处理，不依赖外部 API

## 技术方案
- 后端：SQLite FTS5 (全文搜索)
- 索引：增量更新，只处理变更文件
- 存储：本地 SQLite 数据库
- 接口：简单的 CLI + OpenClaw skill

## 架构
```
smart-memory-index/
├── SKILL.md                 # Skill 定义
├── index.js                 # 主入口
├── lib/
│   ├── indexer.js          # 文件索引器
│   ├── searcher.js         # 搜索器
│   └── db.js               # SQLite 管理
└── package.json
```

## 核心功能
1. 自动扫描 memory/ 目录
2. 提取标题、标签、关键句
3. 建立 FTS5 全文索引
4. 支持语义化搜索
5. 增量更新机制

## Token 优化
- 本地 SQLite，零外部调用
- 增量索引，只处理变更
- 压缩存储，减少 I/O
