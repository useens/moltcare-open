# 多代理协作标准模板库 v1.0

> 多代理任务的标准化模板集合
> 版本: 1.0 | 创建日期: 2026-02-09

---

## 目录

1. [任务启动模板](#1-任务启动模板)
2. [进度跟踪模板](#2-进度跟踪模板)
3. [成果汇总模板](#3-成果汇总模板)
4. [代理指令模板](#4-代理指令模板)
5. [状态报告模板](#5-状态报告模板)
6. [冲突报告模板](#6-冲突报告模板)

---

## 1. 任务启动模板

### 1.1 协调器任务启动清单

```markdown
# 多代理任务启动清单

## 任务基本信息
- **任务ID**: {TASK_ID}
- **任务名称**: {TASK_NAME}
- **创建时间**: {TIMESTAMP}
- **协调器**: Coordinator Agent
- **优先级**: {HIGH/MEDIUM/LOW}
- **截止时间**: {DEADLINE}

## 任务描述
{详细描述任务目标、范围和预期成果}

## 代理分配
| 代理角色 | 标识符 | 分配任务 | 依赖 |
|----------|--------|----------|------|
| 架构师 | architect | {任务} | {依赖} |
| 安全审计员 | security | {任务} | {依赖} |
| 技术研究员 | researcher | {任务} | {依赖} |
| 开发工程师 | developer | {任务} | {依赖} |
| 测试工程师 | tester | {任务} | {依赖} |
| 项目经理 | pm | {任务} | {依赖} |

## 依赖关系图
```
{使用ASCII图表示依赖关系}
```

## 交付物清单
| 代理 | 交付物名称 | 格式 | 截止时间 |
|------|-----------|------|----------|
| {代理} | {名称} | {格式} | {时间} |

## 通信信道
- 状态同步: `memory/multi-agent/sync/task-{TASK_ID}-status.yaml`
- 消息队列: `memory/multi-agent/messages/`
- 成果目录: `memory/multi-agent/artifacts/`

## 启动确认
- [ ] 所有代理已分配任务
- [ ] 依赖关系已确认
- [ ] 通信信道已建立
- [ ] 监控已启动
- [ ] 任务正式开始
```

### 1.2 任务启动指令模板（协调器→代理）

```markdown
## 任务分配指令

**致**: {AGENT_ROLE} ({AGENT_ID})
**来自**: Coordinator Agent
**任务ID**: {TASK_ID}
**时间**: {TIMESTAMP}

### 你的任务
{TASK_DESCRIPTION}

### 输入依赖
{LIST_INPUT_DEPENDENCIES}

### 输出要求
- **交付物**: {DELIVERABLE_NAME}
- **格式**: {FORMAT}
- **位置**: {OUTPUT_PATH}
- **截止时间**: {DEADLINE}

### 质量标准
{QUALITY_CRITERIA}

### 阻塞处理
如果遇到阻塞：
1. 首先检查依赖是否已交付
2. 向相关代理发送协作请求
3. 15分钟后仍未解决，上报协调器

### 开始执行
请回复确认收到任务，并更新状态为 IN_PROGRESS。

**下一步**: 读取状态文件了解其他代理进度，开始执行任务。
```

---

## 2. 进度跟踪模板

### 2.1 任务状态总览模板

```yaml
# task-{TASK_ID}-status.yaml
task_id: "{TASK_ID}"
task_name: "{TASK_NAME}"
created_at: "{CREATED_AT}"
started_at: "{STARTED_AT}"
estimated_completion: "{ESTIMATED}"
actual_completion: null  # 完成后填写

overall_status: "IN_PROGRESS"  # PENDING/IN_PROGRESS/BLOCKED/COMPLETED/FAILED
overall_progress: 0  # 0-100

agents:
  architect:
    agent_id: "architect"
    status: "PENDING"  # PENDING/IN_PROGRESS/BLOCKED/COMPLETED/FAILED
    assigned_task: "{TASK_DESC}"
    started_at: null
    last_update: null
    completed_at: null
    progress_percent: 0
    deliverables:
      - name: "{NAME}"
        path: "{PATH}"
        status: "PENDING"  # PENDING/IN_PROGRESS/REVIEW/ACCEPTED/REJECTED
    blockers: []
    waiting_for: []
    quality_score: null
    notes: ""

  security:
    agent_id: "security"
    # ... 相同结构

  researcher:
    agent_id: "researcher"
    # ... 相同结构

  developer:
    agent_id: "developer"
    # ... 相同结构

  tester:
    agent_id: "tester"
    # ... 相同结构

  pm:
    agent_id: "pm"
    status: "MONITORING"
    last_check: "{TIMESTAMP}"
    risk_log: []
    decision_log: []

communication_log:
  - timestamp: "{TS}"
    from: "{AGENT}"
    to: "{AGENT}"
    type: "{TYPE}"
    summary: "{SUMMARY}"

events:
  - timestamp: "{TS}"
    event: "{EVENT_DESC}"
    agent: "{AGENT}"
    severity: "{INFO/WARNING/ERROR}"
```

### 2.2 进度报告模板（协调器生成）

```markdown
# 任务进度报告

**任务**: {TASK_NAME}  
**报告时间**: {TIMESTAMP}  
**报告周期**: {START_TIME} ~ {END_TIME}

## 执行摘要
- **总体进度**: {PROGRESS}%
- **总体状态**: {STATUS}
- **预计完成**: {ETA}
- **风险等级**: {RISK_LEVEL}

## 各代理状态

### 架构师 (architect)
- 状态: {STATUS}
- 进度: {PROGRESS}%
- 交付物: {DELIVERABLES}
- 阻塞: {BLOCKERS}
- 下一步: {NEXT_STEPS}

### 安全审计员 (security)
- ...

### 技术研究员 (researcher)
- ...

### 开发工程师 (developer)
- ...

### 测试工程师 (tester)
- ...

### 项目经理 (pm)
- ...

## 关键事件
| 时间 | 事件 | 代理 | 影响 |
|------|------|------|------|
| {TS} | {EVENT} | {AGENT} | {IMPACT} |

## 风险与问题
| 风险 | 等级 | 影响 | 缓解措施 |
|------|------|------|----------|
| {RISK} | {LEVEL} | {IMPACT} | {MITIGATION} |

## 下一步行动
1. {ACTION_1}
2. {ACTION_2}
3. {ACTION_3}
```

### 2.3 代理状态更新模板

```markdown
## 状态更新

**代理**: {AGENT_ROLE}  
**任务ID**: {TASK_ID}  
**更新时间**: {TIMESTAMP}

### 当前状态
- **状态**: {STATUS}
- **进度**: {PROGRESS}%
- **自上次更新**: {TIME_DELTA}

### 已完成工作
- [x] {COMPLETED_ITEM_1}
- [x] {COMPLETED_ITEM_2}

### 进行中工作
- [ ] {IN_PROGRESS_ITEM_1} ({PROGRESS}%)

### 交付物更新
| 名称 | 状态 | 位置 | 备注 |
|------|------|------|------|
| {NAME} | {STATUS} | {PATH} | {NOTE} |

### 阻塞与依赖
**当前阻塞**: {YES/NO}
- 阻塞原因: {REASON}
- 阻塞时长: {DURATION}
- 需要的帮助: {HELP_NEEDED}

### 预计完成
- **剩余工作量**: {ESTIMATE}
- **预计完成时间**: {ETA}

### 备注
{ADDITIONAL_NOTES}
```

---

## 3. 成果汇总模板

### 3.1 任务完成报告模板

```markdown
# 任务完成报告

## 任务信息
- **任务ID**: {TASK_ID}
- **任务名称**: {TASK_NAME}
- **开始时间**: {STARTED_AT}
- **完成时间**: {COMPLETED_AT}
- **总耗时**: {DURATION}
- **协调器**: Coordinator Agent

## 执行结果
- **最终状态**: {COMPLETED/FAILED/PARTIAL}
- **完成度**: {COMPLETION_PERCENT}%
- **质量评分**: {QUALITY_SCORE}/100

## 代理成果汇总

### 架构师 (architect)
- **状态**: {STATUS}
- **耗时**: {DURATION}
- **交付物**:
  - [{NAME}]({PATH}) - {STATUS}
- **质量指标**:
  - 文档完整性: {SCORE}%
  - 设计合理性: {SCORE}%

### 安全审计员 (security)
- ...

### 技术研究员 (researcher)
- ...

### 开发工程师 (developer)
- ...

### 测试工程师 (tester)
- ...

### 项目经理 (pm)
- ...

## 交付物清单
| # | 名称 | 类型 | 路径 | 创建者 | 状态 |
|---|------|------|------|--------|------|
| 1 | {NAME} | {TYPE} | {PATH} | {AGENT} | {STATUS} |

## 关键决策记录
| 时间 | 决策 | 决策者 | 理由 |
|------|------|--------|------|
| {TS} | {DECISION} | {AGENT} | {REASON} |

## 问题与解决
| 问题 | 影响 | 解决方案 | 解决者 |
|------|------|----------|--------|
| {ISSUE} | {IMPACT} | {SOLUTION} | {AGENT} |

## 经验教训

### 成功经验
- {SUCCESS_1}
- {SUCCESS_2}

### 改进建议
- {IMPROVEMENT_1}
- {IMPROVEMENT_2}

## 后续行动
- [ ] {FOLLOW_UP_1}
- [ ] {FOLLOW_UP_2}

## 附件
- 完整状态日志: `{STATUS_LOG_PATH}`
- 通信记录: `{MESSAGE_LOG_PATH}`
- 成果归档: `{ARTIFACTS_PATH}`
```

### 3.2 交付物索引模板

```yaml
# task-{TASK_ID}-artifacts-index.yaml
task_id: "{TASK_ID}"
indexed_at: "{TIMESTAMP}"
total_artifacts: 0

artifacts:
  architect:
    - name: "{NAME}"
      type: "document|code|config|test"
      path: "{RELATIVE_PATH}"
      format: "md|py|yaml|json|..."
      size_bytes: 0
      created_at: "{TS}"
      checksum: "{HASH}"
      description: "{DESC}"
      dependencies: []
      quality_check: "PASSED"
      reviewed_by: []

  security:
    - # ...

  researcher:
    - # ...

  developer:
    - # ...

  tester:
    - # ...

  pm:
    - # ...

relationships:
  - from: "{ARTIFACT_1}"
    to: "{ARTIFACT_2}"
    type: "depends_on|references|extends"
```

---

## 4. 代理指令模板

### 4.1 架构师代理指令

```markdown
# 架构师代理任务指令

**角色**: 架构师代理 (architect)  
**任务ID**: {TASK_ID}  
**指令时间**: {TIMESTAMP}

## 任务目标
{SYSTEM_DESIGN_GOALS}

## 设计范围
- 系统边界: {BOUNDARIES}
- 核心模块: {MODULES}
- 集成点: {INTEGRATION_POINTS}

## 设计要求
1. 模块划分清晰，职责单一
2. 接口定义完整，包含输入输出规范
3. 考虑扩展性和可维护性
4. 文档化所有关键决策

## 输出要求
- **系统架构文档**: `artifacts/architect/system-architecture.md`
  - 架构图
  - 模块说明
  - 接口契约
  - 数据流图
- **模块边界定义**: `artifacts/architect/module-boundaries.yaml`

## 协作要求
- 完成后通知: security, developer
- 接受来自: security 的审查反馈
- 响应时间: < 5分钟

## 质量标准
- [ ] 所有模块有明确职责
- [ ] 所有接口有详细定义
- [ ] 架构图清晰可读
- [ ] 通过安全审查

开始执行后更新状态文件为 IN_PROGRESS。
```

### 4.2 安全审计员代理指令

```markdown
# 安全审计员代理任务指令

**角色**: 安全审计员代理 (security)  
**任务ID**: {TASK_ID}

## 审计范围
- 系统架构安全审查
- 数据流安全分析
- 接口安全评估
- 合规性检查

## 审计标准
- OWASP Top 10
- 数据保护最佳实践
- 最小权限原则
- 纵深防御策略

## 输入依赖
- 架构师: 系统架构文档
- 技术研究员: 技术选型报告

## 输出要求
- **安全审查报告**: `artifacts/security/security-review.md`
- **风险清单**: `artifacts/security/risk-register.yaml`
- **修复建议**: `artifacts/security/remediation-plan.md`

## 协作要求
- 依赖: architect, researcher
- 通知: developer, pm
- 响应阻塞: 高优先级
```

### 4.3 技术研究员代理指令

```markdown
# 技术研究员代理任务指令

**角色**: 技术研究员代理 (researcher)  
**任务ID**: {TASK_ID}

## 调研范围
- 技术方案对比
- 框架/库评估
- 性能基准测试
- 社区成熟度分析

## 调研维度
1. 功能性
2. 性能
3. 安全性
4. 可维护性
5. 社区支持
6. 学习曲线

## 输出要求
- **技术调研报告**: `artifacts/researcher/tech-research.md`
- **方案对比矩阵**: `artifacts/researcher/comparison-matrix.yaml`
- **选型建议**: `artifacts/researcher/recommendation.md`

## 协作要求
- 并行: architect
- 通知: developer
```

### 4.4 开发工程师代理指令

```markdown
# 开发工程师代理任务指令

**角色**: 开发工程师代理 (developer)  
**任务ID**: {TASK_ID}

## 开发任务
{IMPLEMENTATION_TASKS}

## 输入依赖
- architect: 系统架构文档、接口契约
- researcher: 技术选型报告
- security: 安全审查反馈

## 编码标准
- 遵循语言规范
- 编写单元测试（覆盖率 > 80%）
- 代码注释完整
- 通过静态检查

## 输出要求
- **源代码**: `artifacts/developer/src/`
- **单元测试**: `artifacts/developer/tests/`
- **API文档**: `artifacts/developer/api-docs.md`
- **部署配置**: `artifacts/developer/config/`

## 质量门禁
- [ ] 代码编译/运行通过
- [ ] 单元测试通过率 100%
- [ ] 代码覆盖率 >= 80%
- [ ] 无高危安全漏洞
- [ ] 通过代码审查

## 协作要求
- 依赖: architect, researcher, security
- 通知: tester
```

### 4.5 测试工程师代理指令

```markdown
# 测试工程师代理任务指令

**角色**: 测试工程师代理 (tester)  
**任务ID**: {TASK_ID}

## 测试范围
- 功能测试
- 集成测试
- 性能测试
- 安全测试
- 兼容性测试

## 输入依赖
- developer: 源代码、单元测试
- architect: 接口契约

## 测试标准
- 测试用例覆盖所有需求
- 边界条件测试
- 异常场景测试
- 性能基准验证

## 输出要求
- **测试计划**: `artifacts/tester/test-plan.md`
- **测试用例**: `artifacts/tester/test-cases/`
- **测试报告**: `artifacts/tester/test-report.md`
- **缺陷清单**: `artifacts/tester/bug-tracker.yaml`

## 质量指标
- 测试通过率: >= 95%
- 代码覆盖率: >= 85%
- 关键缺陷: 0
- 高危缺陷: 0

## 协作要求
- 依赖: developer
- 通知: pm, developer
```

### 4.6 项目经理代理指令

```markdown
# 项目经理代理任务指令

**角色**: 项目经理代理 (pm)  
**任务ID**: {TASK_ID}

## 管理职责
- 进度跟踪与报告
- 风险管理
- 资源协调
- 决策支持
- 冲突调解

## 监控范围
- 所有代理状态
- 任务依赖关系
- 进度偏差
- 阻塞与风险

## 输出要求
- **项目计划**: `artifacts/pm/project-plan.md`
- **进度报告**: `artifacts/pm/progress-reports/`
- **风险日志**: `artifacts/pm/risk-log.yaml`
- **决策记录**: `artifacts/pm/decisions.md`

## 干预触发条件
- 进度偏差 > 20%
- 阻塞时间 > 15分钟
- 质量分数 < 70
- 代理异常 > 10分钟

## 协作要求
- 监控: 所有代理
- 响应: 所有代理的升级请求
```

---

## 5. 状态报告模板

### 5.1 代理完成报告

```markdown
## 任务完成报告

**代理**: {AGENT_ROLE}  
**任务ID**: {TASK_ID}  
**完成时间**: {TIMESTAMP}

### 执行摘要
- **状态**: COMPLETED
- **耗时**: {DURATION}
- **质量自评**: {SCORE}/100

### 交付物清单
| # | 名称 | 路径 | 状态 | 备注 |
|---|------|------|------|------|
| 1 | {NAME} | {PATH} | COMPLETED | {NOTE} |

### 关键决策
- {DECISION_1}: {REASON}
- {DECISION_2}: {REASON}

### 已知问题
- {ISSUE_1}: {IMPACT} - {WORKAROUND}

### 建议
- {SUGGESTION_1}
- {SUGGESTION_2}

### 交接信息
- **下游代理**: {DOWNSTREAM_AGENTS}
- **需要同步的信息**: {SYNC_INFO}
- **特别注意事项**: {NOTES}

任务已完成，等待验收。
```

### 5.2 异常报告模板

```markdown
## 异常报告

**代理**: {AGENT_ROLE}  
**任务ID**: {TASK_ID}  
**报告时间**: {TIMESTAMP}

### 异常类型
- [ ] 技术错误
- [ ] 依赖缺失
- [ ] 资源不足
- [ ] 设计问题
- [ ] 其他: {SPECIFY}

### 异常描述
{DETAILED_DESCRIPTION}

### 影响评估
- **影响范围**: {SCOPE}
- **严重程度**: {CRITICAL/HIGH/MEDIUM/LOW}
- **阻塞代理**: {BLOCKED_AGENTS}
- **预计延迟**: {DELAY}

### 已尝试解决
- {ATTEMPT_1}: {RESULT}
- {ATTEMPT_2}: {RESULT}

### 需要的支持
{SUPPORT_NEEDED}

### 建议方案
{PROPOSED_SOLUTION}

---
**需要协调器介入**: {YES/NO}
```

---

## 6. 冲突报告模板

### 6.1 冲突报告

```markdown
## 代理间冲突报告

**冲突ID**: {CONFLICT_ID}  
**任务ID**: {TASK_ID}  
**报告时间**: {TIMESTAMP}

### 冲突双方
- **代理A**: {AGENT_A} ({AGENT_A_ROLE})
- **代理B**: {AGENT_B} ({AGENT_B_ROLE})

### 冲突类型
- [ ] 技术方案分歧
- [ ] 接口定义冲突
- [ ] 资源竞争
- [ ] 质量要求矛盾
- [ ] 其他: {SPECIFY}

### 冲突描述
{CONFLICT_DESCRIPTION}

### 各方立场

#### {AGENT_A} 立场
- {POINT_A1}
- {POINT_A2}

#### {AGENT_B} 立场
- {POINT_B1}
- {POINT_B2}

### 已尝试协商
{NEGOTIATION_ATTEMPTS}

### 请求仲裁
{ARBITRATION_REQUEST}

### 建议决策
{RECOMMENDED_DECISION}

---
**冲突等级**: {LEVEL}  
**紧急程度**: {URGENCY}  
**建议仲裁者**: {ARBITRATOR}
```

---

## 7. 快速参考

### 7.1 文件命名规范

```
# 状态文件
task-{TASK_ID}-status.yaml

# 消息文件
{TIMESTAMP}-{FROM_AGENT}-{TO_AGENT}-{MSG_TYPE}.md

# 交付物目录
artifacts/{AGENT_ID}/{DELIVERABLE_NAME}.{EXT}

# 报告文件
reports/{TIMESTAMP}-{REPORT_TYPE}.md

# 日志文件
logs/{DATE}-{AGENT_ID}.log
```

### 7.2 状态值枚举

```yaml
agent_status:
  - PENDING      # 待启动
  - IN_PROGRESS  # 进行中
  - BLOCKED      # 阻塞中
  - COMPLETED    # 已完成
  - FAILED       # 失败
  - REVIEW       # 审核中
  - ACCEPTED     # 已验收

deliverable_status:
  - PENDING      # 待开始
  - IN_PROGRESS  # 进行中
  - REVIEW       # 待审核
  - ACCEPTED     # 已通过
  - REJECTED     # 未通过

task_status:
  - PENDING
  - IN_PROGRESS
  - BLOCKED
  - COMPLETED
  - FAILED
  - CANCELLED
```

### 7.3 常用命令

```bash
# 读取任务状态
cat memory/multi-agent/sync/task-{ID}-status.yaml

# 查看消息队列
ls -la memory/multi-agent/messages/ | tail -20

# 查看成果目录
tree memory/multi-agent/artifacts/

# 生成进度报告
# (通过协调器工具生成)
```

---

*模板库版本: 1.0 | 最后更新: 2026-02-09*
