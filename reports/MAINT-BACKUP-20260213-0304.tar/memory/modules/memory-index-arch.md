# 本地记忆索引系统设计文档

> 设计目标：零外部依赖、增量更新、搜索响应 < 100ms

## 1. 系统概述

### 1.1 设计原则
- **零外部依赖**：仅使用 SQLite 内置功能
- **增量索引**：只处理变更数据，避免全量重建
- **高性能**：搜索响应 < 100ms，适用于 10万+ 记忆条目

### 1.2 核心特性
| 特性 | 实现方式 |
|------|----------|
| 全文搜索 | SQLite FTS5 虚拟表 |
| 增量更新 | 基于 `modified_at` 时间戳的变更检测 |
| 多字段搜索 | 标题、内容、标签、元数据联合索引 |
| 相关性排序 | BM25 算法 + 自定义权重 |
| 前缀搜索 | FTS5 前缀匹配 + 边缘 n-gram |

---

## 2. 数据库表结构

### 2.1 主表：记忆内容表
```sql
-- 记忆主表：存储所有记忆内容
CREATE TABLE IF NOT EXISTS memories (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    memory_id       TEXT UNIQUE NOT NULL,           -- 业务层唯一ID (UUID)
    title           TEXT NOT NULL,                   -- 标题
    content         TEXT NOT NULL,                   -- 内容
    summary         TEXT,                            -- 摘要（可选）
    category        TEXT,                            -- 分类
    importance      INTEGER DEFAULT 5,               -- 重要性 1-10
    created_at      INTEGER NOT NULL,                -- 创建时间 (Unix 秒)
    modified_at     INTEGER NOT NULL,                -- 修改时间 (Unix 秒)
    source_type     TEXT,                            -- 来源类型: note/chat/file
    source_id       TEXT,                            -- 来源ID
    metadata        TEXT                             -- JSON 元数据
);

-- 索引
CREATE INDEX idx_memories_modified ON memories(modified_at);
CREATE INDEX idx_memories_category ON memories(category);
CREATE INDEX idx_memories_source ON memories(source_type, source_id);
```

### 2.2 全文搜索虚拟表 (FTS5)
```sql
-- FTS5 虚拟表：支持高效全文搜索
CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
    title,                      -- 标题
    content,                    -- 内容
    tags,                       -- 标签（空格分隔）
    content='memories',         -- 关联外部内容表
    content_rowid='id',         -- 关联主键
    tokenize='porter unicode61 remove_diacritics 2'  -- 分词配置
);

-- 配置说明：
-- porter: 英语词干提取
-- unicode61: Unicode 分词，支持中文等
-- remove_diacritics 2: 移除重音符号
```

### 2.3 标签关联表
```sql
-- 标签表
CREATE TABLE IF NOT EXISTS tags (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT UNIQUE NOT NULL,
    count       INTEGER DEFAULT 0,
    created_at  INTEGER NOT NULL
);

-- 记忆-标签关联表
CREATE TABLE IF NOT EXISTS memory_tags (
    memory_id   INTEGER NOT NULL REFERENCES memories(id) ON DELETE CASCADE,
    tag_id      INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (memory_id, tag_id)
);

CREATE INDEX idx_memory_tags_tag ON memory_tags(tag_id);
```

### 2.4 索引状态表（增量更新关键）
```sql
-- 索引状态追踪表
CREATE TABLE IF NOT EXISTS index_state (
    key         TEXT PRIMARY KEY,
    value       TEXT NOT NULL,
    updated_at  INTEGER NOT NULL
);

-- 初始化状态
INSERT OR IGNORE INTO index_state (key, value, updated_at) VALUES
    ('last_indexed_time', '0', 0),
    ('total_documents', '0', 0),
    ('index_version', '1', 0);
```

### 2.5 搜索历史表（可选优化）
```sql
-- 搜索历史：用于自动补全和搜索建议
CREATE TABLE IF NOT EXISTS search_history (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    query       TEXT NOT NULL,
    results_count INTEGER,
    search_time INTEGER NOT NULL,  -- 搜索耗时(ms)
    created_at  INTEGER NOT NULL
);

CREATE INDEX idx_search_history_query ON search_history(query);
CREATE INDEX idx_search_history_created ON search_history(created_at);
```

---

## 3. 索引策略

### 3.1 FTS5 触发器（自动同步）
```sql
-- 插入时自动同步到 FTS 表
CREATE TRIGGER IF NOT EXISTS memories_fts_insert 
AFTER INSERT ON memories BEGIN
    INSERT INTO memories_fts(rowid, title, content, tags)
    SELECT 
        NEW.id,
        NEW.title,
        NEW.content,
        COALESCE((SELECT group_concat(t.name, ' ') 
                  FROM tags t 
                  JOIN memory_tags mt ON t.id = mt.tag_id 
                  WHERE mt.memory_id = NEW.id), '');
END;

-- 更新时同步
CREATE TRIGGER IF NOT EXISTS memories_fts_update
AFTER UPDATE ON memories BEGIN
    UPDATE memories_fts SET
        title = NEW.title,
        content = NEW.content,
        tags = COALESCE((SELECT group_concat(t.name, ' ') 
                         FROM tags t 
                         JOIN memory_tags mt ON t.id = mt.tag_id 
                         WHERE mt.memory_id = NEW.id), '')
    WHERE rowid = NEW.id;
END;

-- 删除时同步
CREATE TRIGGER IF NOT EXISTS memories_fts_delete
AFTER DELETE ON memories BEGIN
    DELETE FROM memories_fts WHERE rowid = OLD.id;
END;
```

### 3.2 标签变更触发器
```sql
-- 标签关联变更时更新 FTS
CREATE TRIGGER IF NOT EXISTS memory_tags_insert_fts
AFTER INSERT ON memory_tags BEGIN
    UPDATE memories SET modified_at = strftime('%s', 'now')
    WHERE id = NEW.memory_id;
END;

CREATE TRIGGER IF NOT EXISTS memory_tags_delete_fts
AFTER DELETE ON memory_tags BEGIN
    UPDATE memories SET modified_at = strftime('%s', 'now')
    WHERE id = OLD.memory_id;
END;
```

### 3.3 增量索引算法

#### 3.3.1 算法流程
```
┌─────────────────────────────────────────────────────────────┐
│                    增量索引流程                              │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1. 读取上次索引时间戳 (last_indexed_time)                  │
│         │                                                   │
│         ▼                                                   │
│  2. 查询变更: SELECT * FROM memories                        │
│              WHERE modified_at > last_indexed_time          │
│         │                                                   │
│         ▼                                                   │
│  3. 批量处理变更                                            │
│     ┌─────────────┐  ┌─────────────┐  ┌─────────────┐      │
│     │   INSERT    │  │   UPDATE    │  │   DELETE    │      │
│     └─────────────┘  └─────────────┘  └─────────────┘      │
│         │                                                   │
│         ▼                                                   │
│  4. 更新 FTS 索引 (通过触发器自动完成)                      │
│         │                                                   │
│         ▼                                                   │
│  5. 更新状态: last_indexed_time = now()                     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

#### 3.3.2 核心算法实现
```sql
-- 步骤1: 获取待索引的记忆ID
WITH changes AS (
    SELECT id, memory_id, title, content,
           CASE 
               WHEN modified_at > :last_indexed 
                    AND id NOT IN (SELECT rowid FROM memories_fts)
               THEN 'INSERT'
               WHEN modified_at > :last_indexed 
                    AND id IN (SELECT rowid FROM memories_fts)
               THEN 'UPDATE'
               ELSE 'SKIP'
           END as action
    FROM memories
    WHERE modified_at > :last_indexed
)
SELECT * FROM changes WHERE action != 'SKIP';

-- 步骤2: 批量重建（针对大量变更时）
-- 如果变更超过1000条，使用重建策略
INSERT INTO memories_fts(memories_fts) VALUES('rebuild');

-- 步骤3: 优化 FTS 索引
INSERT INTO memories_fts(memories_fts) VALUES('optimize');
```

#### 3.3.3 增量索引代码逻辑
```javascript
// 伪代码示例
class IncrementalIndexer {
    constructor(db) {
        this.db = db;
    }

    async runIncrementalIndex() {
        const lastIndexed = await this.getLastIndexedTime();
        const batchSize = 100;
        
        // 1. 统计待处理数量
        const pendingCount = await this.db.get(
            `SELECT COUNT(*) as count FROM memories 
             WHERE modified_at > ?`, 
            lastIndexed
        );

        // 2. 大量变更时使用重建策略
        if (pendingCount.count > 1000) {
            await this.rebuildIndex();
            return;
        }

        // 3. 增量处理
        let offset = 0;
        while (true) {
            const batch = await this.db.all(
                `SELECT * FROM memories 
                 WHERE modified_at > ? 
                 LIMIT ? OFFSET ?`,
                lastIndexed, batchSize, offset
            );
            
            if (batch.length === 0) break;
            
            // 通过触发器自动更新 FTS
            // 此处只需更新 modified_at 触发重新索引
            for (const memory of batch) {
                await this.touchMemory(memory.id);
            }
            
            offset += batchSize;
        }

        // 4. 更新时间戳
        await this.updateLastIndexedTime();
    }

    async touchMemory(id) {
        // 触发更新，让触发器处理 FTS 同步
        await this.db.run(
            `UPDATE memories SET modified_at = ? WHERE id = ?`,
            Date.now() / 1000, id
        );
    }

    async rebuildIndex() {
        // 全量重建
        await this.db.run(`DELETE FROM memories_fts`);
        await this.db.run(`
            INSERT INTO memories_fts(rowid, title, content, tags)
            SELECT m.id, m.title, m.content,
                   COALESCE(GROUP_CONCAT(t.name, ' '), '')
            FROM memories m
            LEFT JOIN memory_tags mt ON m.id = mt.memory_id
            LEFT JOIN tags t ON mt.tag_id = t.id
            GROUP BY m.id
        `);
    }
}
```

---

## 4. 搜索接口设计

### 4.1 搜索 API

```typescript
interface SearchOptions {
    query: string;                    // 搜索关键词
    filters?: {
        category?: string;            // 分类过滤
        tags?: string[];              // 标签过滤
        dateFrom?: number;            // 开始时间戳
        dateTo?: number;              // 结束时间戳
        importance?: number;          // 最小重要性
        sourceType?: string;          // 来源类型
    };
    sort?: {
        field: 'relevance' | 'date' | 'importance';
        order: 'asc' | 'desc';
    };
    pagination?: {
        limit: number;                // 默认 20
        offset: number;               // 默认 0
    };
    highlight?: boolean;              // 是否高亮匹配内容
}

interface SearchResult {
    memories: MemoryItem[];
    total: number;
    queryTime: number;                // 查询耗时(ms)
    hasMore: boolean;
}

interface MemoryItem {
    id: string;
    title: string;
    content: string;
    summary?: string;
    tags: string[];
    category: string;
    importance: number;
    createdAt: number;
    modifiedAt: number;
    relevanceScore: number;           // BM25 相关性分数
    highlights?: {                    // 匹配高亮
        title?: string;
        content?: string;
    };
}
```

### 4.2 核心搜索 SQL

#### 4.2.1 基础全文搜索
```sql
-- 基础搜索：标题+内容+标签
SELECT 
    m.*,
    bm25(memories_fts, 10.0, 5.0, 3.0) as rank_score,
    snippet(memories_fts, 1, '<b>', '</b>', '...', 32) as content_snippet
FROM memories_fts
JOIN memories m ON memories_fts.rowid = m.id
WHERE memories_fts MATCH :query
ORDER BY rank_score ASC
LIMIT :limit OFFSET :offset;

-- 权重说明：title=10.0, content=5.0, tags=3.0
-- BM25 分数越小越相关
```

#### 4.2.2 高级搜索（带过滤）
```sql
-- 带过滤条件的搜索
WITH ranked AS (
    SELECT 
        rowid,
        bm25(memories_fts, 10.0, 5.0, 3.0) as score
    FROM memories_fts
    WHERE memories_fts MATCH :query
),
filtered AS (
    SELECT 
        m.*,
        r.score,
        (SELECT group_concat(t.name) 
         FROM tags t 
         JOIN memory_tags mt ON t.id = mt.tag_id 
         WHERE mt.memory_id = m.id) as tag_list
    FROM memories m
    JOIN ranked r ON m.id = r.rowid
    WHERE 1=1
        AND (:category IS NULL OR m.category = :category)
        AND (:date_from IS NULL OR m.created_at >= :date_from)
        AND (:date_to IS NULL OR m.created_at <= :date_to)
        AND (:importance IS NULL OR m.importance >= :importance)
        AND (:source_type IS NULL OR m.source_type = :source_type)
)
SELECT * FROM filtered
WHERE (:tag_filter IS NULL OR tag_list LIKE '%' || :tag_filter || '%')
ORDER BY 
    CASE WHEN :sort_by = 'relevance' THEN score END ASC,
    CASE WHEN :sort_by = 'date' THEN modified_at END DESC,
    CASE WHEN :sort_by = 'importance' THEN importance END DESC
LIMIT :limit OFFSET :offset;
```

#### 4.2.3 前缀搜索（自动补全）
```sql
-- 前缀匹配搜索
SELECT DISTINCT 
    term,
    (SELECT COUNT(*) FROM memories_fts WHERE memories_fts MATCH term || '*') as freq
FROM memories_fts_vocab
WHERE term >= :prefix AND term < :prefix || CHAR(255)
ORDER BY freq DESC
LIMIT 10;

-- 或使用 LIKE 进行前缀匹配
SELECT DISTINCT term 
FROM memories_fts_vocab
WHERE term LIKE :prefix || '%'
ORDER BY 
    (SELECT COUNT(*) FROM memories_fts WHERE memories_fts MATCH term) DESC
LIMIT 10;
```

#### 4.2.4 相关记忆推荐
```sql
-- 基于标签和内容的相似记忆推荐
WITH target_tags AS (
    SELECT t.name
    FROM tags t
    JOIN memory_tags mt ON t.id = mt.tag_id
    WHERE mt.memory_id = :target_memory_id
),
target_content AS (
    SELECT title || ' ' || content as text
    FROM memories
    WHERE id = :target_memory_id
)
SELECT 
    m.*,
    COUNT(DISTINCT tt.name) as common_tags,
    bm25(memories_fts, 1.0, 1.0, 5.0) as content_sim
FROM memories m
LEFT JOIN memory_tags mt ON m.id = mt.memory_id
LEFT JOIN tags t ON mt.tag_id = t.id
LEFT JOIN target_tags tt ON t.name = tt.name
JOIN memories_fts ON memories_fts.rowid = m.id
WHERE m.id != :target_memory_id
  AND memories_fts MATCH (SELECT text FROM target_content)
GROUP BY m.id
ORDER BY common_tags DESC, content_sim ASC
LIMIT 5;
```

### 4.3 搜索接口实现

```javascript
class MemorySearch {
    constructor(db) {
        this.db = db;
    }

    /**
     * 执行搜索
     * @param {SearchOptions} options
     * @returns {Promise<SearchResult>}
     */
    async search(options) {
        const startTime = Date.now();
        
        // 构建查询
        const { sql, params } = this.buildSearchQuery(options);
        
        // 执行搜索
        const rows = await this.db.all(sql, params);
        const total = await this.getTotalCount(options);
        
        // 构建结果
        const memories = await Promise.all(
            rows.map(row => this.formatMemoryItem(row, options.highlight))
        );
        
        const queryTime = Date.now() - startTime;
        
        // 记录搜索历史
        await this.logSearch(options.query, total, queryTime);
        
        return {
            memories,
            total,
            queryTime,
            hasMore: options.pagination.offset + memories.length < total
        };
    }

    /**
     * 搜索建议/自动补全
     * @param {string} prefix
     * @returns {Promise<string[]>}
     */
    async suggest(prefix) {
        if (prefix.length < 2) return [];
        
        // 从搜索历史和标签中获取建议
        const suggestions = await this.db.all(`
            SELECT query as term, COUNT(*) as freq
            FROM search_history
            WHERE query LIKE ? || '%'
            GROUP BY query
            
            UNION ALL
            
            SELECT name as term, count as freq
            FROM tags
            WHERE name LIKE ? || '%'
            
            ORDER BY freq DESC
            LIMIT 10
        `, prefix, prefix);
        
        return suggestions.map(s => s.term);
    }

    buildSearchQuery(options) {
        // 转义 FTS 特殊字符
        const safeQuery = this.escapeFtsQuery(options.query);
        
        const sql = `
            WITH ranked AS (
                SELECT rowid, bm25(memories_fts, 10.0, 5.0, 3.0) as score
                FROM memories_fts
                WHERE memories_fts MATCH ?
            )
            SELECT m.*, r.score
            FROM memories m
            JOIN ranked r ON m.id = r.rowid
            WHERE 1=1
                ${options.filters?.category ? 'AND m.category = ?' : ''}
                ${options.filters?.dateFrom ? 'AND m.created_at >= ?' : ''}
                ${options.filters?.dateTo ? 'AND m.created_at <= ?' : ''}
            ORDER BY r.score ASC
            LIMIT ? OFFSET ?
        `;
        
        const params = [safeQuery];
        // 添加过滤参数...
        
        return { sql, params };
    }

    escapeFtsQuery(query) {
        // 转义 FTS5 特殊字符: " * ( )
        return query
            .replace(/"/g, '""')
            .replace(/\*/g, '')
            .replace(/\(/g, '')
            .replace(/\)/g, '');
    }
}
```

---

## 5. 性能优化策略

### 5.1 索引优化

```sql
-- 1. 为常用过滤条件创建索引
CREATE INDEX idx_memories_time_range ON memories(created_at, modified_at);
CREATE INDEX idx_memories_importance ON memories(importance DESC);

-- 2. FTS5 前缀索引配置（加快前缀搜索）
-- 在创建虚拟表时添加 prefix 选项
CREATE VIRTUAL TABLE memories_fts USING fts5(
    title, content, tags,
    content='memories',
    content_rowid='id',
    tokenize='porter unicode61',
    prefix='2 3 4'  -- 索引 2/3/4 字符前缀
);

-- 3. 定期优化 FTS 索引（建议在低峰期执行）
INSERT INTO memories_fts(memories_fts) VALUES('optimize');

-- 4. 定期清理过期的搜索历史
DELETE FROM search_history WHERE created_at < strftime('%s', 'now') - 86400 * 30;
```

### 5.2 查询优化

| 优化项 | 策略 | 效果 |
|--------|------|------|
| 延迟加载 | 搜索结果只返回摘要，详情按需加载 | 减少 I/O |
| 结果缓存 | 缓存热门查询结果 5 分钟 | 减少重复计算 |
| 分页查询 | 限制每页最多 50 条 | 控制内存占用 |
| 预编译语句 | 使用参数化查询 | 提升解析效率 |
| 并行查询 | 计数和搜索并行执行 | 减少总耗时 |

### 5.3 性能基准

```sql
-- 测试查询性能
EXPLAIN QUERY PLAN
SELECT m.*, bm25(memories_fts, 10.0, 5.0, 3.0) as score
FROM memories_fts
JOIN memories m ON memories_fts.rowid = m.id
WHERE memories_fts MATCH '测试'
ORDER BY score ASC
LIMIT 20;

-- 预期执行计划：
-- 1. 使用 memories_fts 的自动索引进行 MATCH 搜索 (O(log n))
-- 2. 通过 rowid 回查 memories 表 (O(1) 每行)
-- 3. 排序后返回结果
```

### 5.4 预期性能指标

| 数据规模 | 索引大小 | 搜索延迟 | 增量更新时间 |
|----------|----------|----------|--------------|
| 1万条 | ~15MB | < 10ms | < 100ms |
| 10万条 | ~120MB | < 50ms | < 500ms |
| 50万条 | ~600MB | < 100ms | < 2s |

---

## 6. 部署与维护

### 6.1 初始化脚本

```sql
-- 完整的数据库初始化脚本
-- 执行顺序很重要！

-- 1. 创建主表
CREATE TABLE IF NOT EXISTS memories (...);

-- 2. 创建 FTS5 虚拟表
CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(...);

-- 3. 创建其他表
CREATE TABLE IF NOT EXISTS tags (...);
CREATE TABLE IF NOT EXISTS memory_tags (...);
CREATE TABLE IF NOT EXISTS index_state (...);
CREATE TABLE IF NOT EXISTS search_history (...);

-- 4. 创建索引
CREATE INDEX ...;

-- 5. 创建触发器
CREATE TRIGGER ...;

-- 6. 初始化状态
INSERT OR IGNORE INTO index_state ...;
```

### 6.2 日常维护任务

```javascript
// 维护任务调度
class IndexMaintenance {
    // 每小时执行：增量索引
    async hourly() {
        await this.incrementalIndexer.run();
    }

    // 每天执行：优化索引
    async daily() {
        await this.db.run(`INSERT INTO memories_fts(memories_fts) VALUES('optimize')`);
        await this.db.run(`DELETE FROM search_history WHERE created_at < ?`, 
            Date.now() / 1000 - 30 * 86400);
    }

    // 每周执行：重建索引（碎片整理）
    async weekly() {
        await this.db.run(`INSERT INTO memories_fts(memories_fts) VALUES('rebuild')`);
        await this.db.run(`VACUUM`);  // 释放磁盘空间
    }
}
```

---

## 7. 错误处理与边界情况

### 7.1 常见问题

| 问题 | 原因 | 解决方案 |
|------|------|----------|
| FTS5 未启用 | SQLite 编译时未包含 FTS5 | 使用支持 FTS5 的 SQLite |
| "database is locked" | 并发写入冲突 | 使用 WAL 模式 |
| 搜索结果为空 | 中文分词问题 | 确认 unicode61 tokenizer |
| 索引膨胀 | 大量更新导致碎片 | 定期执行 optimize/rebuild |

### 7.2 WAL 模式配置

```sql
-- 启用 WAL 模式提升并发性能
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
PRAGMA cache_size = -64000;  -- 64MB 缓存
PRAGMA temp_store = MEMORY;
```

---

## 8. 扩展性设计

### 8.1 未来扩展方向

1. **向量搜索扩展**：预留字段存储 embedding，未来对接向量检索
2. **多语言支持**：配置多语言 tokenizer
3. **语义搜索**：结合 LLM 生成 query expansion
4. **分布式索引**：数据分片到多个 SQLite 文件

### 8.2 版本管理

```sql
-- 数据库版本追踪
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY,
    applied_at INTEGER NOT NULL,
    description TEXT
);

-- 迁移脚本模板
-- v1 -> v2: 添加新字段
ALTER TABLE memories ADD COLUMN embedding BLOB;
```

---

## 9. 总结

本设计实现了一个**零外部依赖、高性能、可增量更新**的本地记忆索引系统：

- **存储层**：SQLite + FTS5 虚拟表
- **索引层**：自动触发器 + 增量更新算法
- **搜索层**：BM25 相关性排序 + 多维度过滤
- **性能目标**：10万条数据下搜索 < 100ms

核心优势：
1. 部署简单，单个 SQLite 文件即可运行
2. 增量更新，避免全量重建的开销
3. 查询高效，FTS5 专为全文搜索优化
4. 功能完整，支持过滤、排序、高亮、建议

---

*文档版本: 1.0*  
*最后更新: 2026-02-09*
