# LLMS 快速入门与使用示例
## Quick Start & Usage Examples

---

## 1. 安装

### 1.1 环境要求

- Python >= 3.8
- SQLite 3 (通常已内置)
- 约 100MB 磁盘空间 (含模型)

### 1.2 安装方式

```bash
# 方式1: 从 PyPI 安装 (发布后)
pip install llms

# 方式2: 极简安装 (仅核心功能)
pip install llms[minimal]

# 方式3: 完整安装 (含所有可选依赖)
pip install llms[full]

# 方式4: 本地开发安装
git clone https://github.com/yourusername/llms
cd llms
pip install -e ".[dev]"
```

### 1.3 验证安装

```bash
llms --version
# 输出: llms 0.1.0

llms init --help
# 显示初始化命令帮助
```

---

## 2. 快速开始

### 2.1 初始化系统

```bash
# 在工作目录初始化
llms init

# 指定模型类型
llms init --model tiny    # 推荐，22MB，384维
llms init --model small   # 更轻量，13MB，384维
llms init --model micro   # 零依赖，TF-IDF

# 首次初始化会自动下载模型 (约 22MB)
```

初始化后生成的文件结构：
```
~/.local/share/llms/
├── memory.db              # SQLite 数据库
├── config.yaml            # 配置文件
└── models/
    └── all-MiniLM-L6-v2/  # 本地嵌入模型
```

### 2.2 索引现有记忆

假设你已有如下 `memory/` 目录：
```
workspace/
├── MEMORY.md
└── memory/
    ├── daily/
    │   ├── 2026-02-08.md
    │   └── 2026-02-09.md
    ├── intel/
    │   └── security-report.md
    └── modules/
        └── core-archive.md
```

```bash
# 索引整个 memory/ 目录
llms index memory/ --recursive

# 索引特定类型
llms index memory/daily/ --type daily
llms index memory/intel/ --type intel

# 索引单个文件
llms index MEMORY.md --type core

# 查看索引统计
llms stats
```

---

## 3. 核心使用示例

### 3.1 命令行使用

#### 搜索记忆

```bash
# 基础搜索
llms search "security audit"

# 返回更多结果
llms search "security audit" -k 10

# 按类型过滤
llms search "security" --type intel

# 按标签过滤
llms search "vulnerability" --tag security

# 组合过滤
llms search "finding" --type intel --importance ">0.8"
```

搜索结果示例：
```
[0.92] Security Audit Report - February 9
     Source: memory/intel/security-audit-2026-02-09.md
     Tags: security, audit, critical
     
[0.88] Vulnerability Assessment Summary  
     Source: memory/daily/2026-02-09.md
     Tags: security, findings
     
[0.85] Penetration Test Results
     Source: memory/intel/pentest-2026-02-08.md
     Tags: security, pentest
```

#### 查找相关记忆

```bash
# 查找与特定记忆相关的其他记忆
llms related 2026-02-09#5

# 显示关联图谱
llms graph --center 2026-02-09#5 --depth 2
```

#### 自动关联

```bash
# 为所有未关联的记忆建立自动关联
llms link --auto

# 查看关联统计
llms link --stats
```

#### 系统维护

```bash
# 查看系统状态
llms status

# 输出示例:
# Database: ~/.local/share/llms/memory.db
# Size: 12.5 MB
# Total memories: 1,250
# Total links: 340
# Last indexed: 2026-02-09 14:30

# 压缩数据库
llms vacuum

# 清理过期记忆
llms cleanup --older-than 365d

# 重新索引
llms reindex
```

### 3.2 Python API 使用

#### 基础使用

```python
from llms import MemorySystem

# 初始化系统
mem = MemorySystem()

# 索引文件
mem.index_file("memory/daily/2026-02-09.md")

# 搜索
results = mem.search("security audit", top_k=5)
for r in results:
    print(f"[{r.score:.2f}] {r.memory.content[:100]}...")

# 关闭
mem.close()
```

#### 上下文管理器

```python
from llms import memory_session

with memory_session() as mem:
    # 索引目录
    mem.index_directory("memory/", pattern="*.md")
    
    # 搜索
    results = mem.search("project status")
    
    # 自动关闭
```

#### 添加新记忆

```python
# 添加新记忆 (自动建立关联)
memory_id = mem.add(
    content="New security finding: SQL injection in login form",
    memory_type="intel",
    tags=["security", "vulnerability", "sql-injection"],
    importance=0.9,
    auto_link=True
)

print(f"Added memory: {memory_id}")
# 输出: Added memory: 2026-02-09#new-1
```

#### 查找相关记忆

```python
# 查找与某个记忆相关的其他记忆
related = mem.find_related("2026-02-09#5", top_k=3)

for r in related:
    print(f"Related ({r.relation_type}): {r.memory.content[:80]}...")
    print(f"  Similarity: {r.similarity:.2f}")
```

#### 批量操作

```python
# 批量索引
stats = mem.index_directory("memory/daily/")
print(f"Indexed {stats.total_files} files, {stats.total_chunks} chunks")

# 批量搜索
queries = ["security", "performance", "deployment"]
for query in queries:
    results = mem.search(query, top_k=3)
    print(f"\nQuery: {query}")
    for r in results:
        print(f"  - {r.score:.2f}: {r.memory.content[:60]}...")
```

#### 高级搜索

```python
# 使用过滤器
results = mem.search(
    "deployment issue",
    top_k=10,
    filters={
        "type": "intel",
        "importance": ">0.7",
        "tags": ["production", "critical"]
    }
)

# 混合搜索 (语义 + 关键词)
from llms.searcher import MatchType

results = mem.searcher.hybrid_search(
    query="authentication failure",
    keywords=["login", "auth", "error"],
    top_k=5,
    semantic_weight=0.7
)
```

#### 关联分析

```python
# 获取记忆的上下文网络
context = mem.associator.get_memory_context("2026-02-09#5", depth=2)

for node in context:
    print(f"{'  ' * node['depth']}- {node['content'][:60]}...")

# 检测记忆聚类
clusters = mem.associator.detect_clusters(min_cluster_size=3)
for i, cluster in enumerate(clusters):
    print(f"\nCluster {i+1} ({len(cluster)} memories):")
    for memory_id in cluster[:5]:  # 显示前5个
        memory = mem.get(memory_id)
        print(f"  - {memory.content[:60]}...")
```

---

## 4. 配置示例

### 4.1 基础配置

```yaml
# ~/.config/llms/config.yaml

system:
  db_path: "~/.local/share/llms/memory.db"
  log_level: "INFO"
  workspace_root: "/home/user/projects/my-project"

embedding:
  model: "tiny"
  device: "cpu"
  batch_size: 32

indexing:
  chunk_size: 512
  chunk_overlap: 128
  auto_index: true

search:
  default_top_k: 5
  min_score: 0.3
  use_hybrid: true
```

### 4.2 自定义目录映射

```yaml
# 兼容现有项目结构
directories:
  - memory_type: "daily"
    path_pattern: "memory/daily/*.md"
    parser: "markdown"
    
  - memory_type: "intel" 
    path_pattern: "memory/intel/*.md"
    parser: "markdown"
    
  - memory_type: "core"
    path_pattern: "MEMORY.md"
    parser: "markdown"
    
  - memory_type: "tag"
    path_pattern: "tags/*.md"
    parser: "markdown"
```

### 4.3 高级配置

```yaml
# 生产环境配置
system:
  db_path: "/var/lib/llms/memory.db"
  log_level: "WARNING"
  max_workers: 4

embedding:
  model: "small"  # 更轻量的模型
  device: "cuda"  # 使用 GPU (如果有)
  cache_dir: "/var/cache/llms/models"

storage:
  max_memories: 500000
  retention_days: 730  # 2年
  vacuum_threshold: 0.2

indexing:
  chunk_size: 256  # 更小的块
  chunk_overlap: 64
  watch_interval: 300  # 5分钟检查一次

search:
  default_top_k: 10
  min_score: 0.4  # 更高的阈值
  use_hybrid: true
  rerank: true  # 启用重排序
```

---

## 5. 实际应用场景

### 5.1 项目知识管理

```python
# 项目初始化时索引所有文档
mem = MemorySystem()

# 索引项目文档
mem.index_directory("docs/", pattern="*.md")
mem.index_directory("meeting-notes/", pattern="*.md")

# 开发时快速查询
# "上周讨论的 API 设计决策是什么？"
results = mem.search("API design decision last week", top_k=3)

# "这个 bug 之前遇到过吗？"
results = mem.search("similar error NullPointerException", filters={"type": "bug"})
```

### 5.2 学习笔记管理

```python
# 索引学习笔记
mem.index_directory("notes/courses/", pattern="*.md")
mem.index_directory("notes/books/", pattern="*.md")

# 学习时关联相关知识
# "我之前学过的关于数据库索引的内容"
results = mem.search("database index b-tree", top_k=5)

# 查找相关笔记
for r in results:
    related = mem.find_related(r.memory.id, top_k=2)
    print(f"Related notes to '{r.memory.content[:50]}...':")
    for rel in related:
        print(f"  - {rel.memory.content[:50]}...")
```

### 5.3 会议记录检索

```python
# 索引会议记录
mem.index_directory("meetings/", pattern="*.md")

# 查询特定话题
# "谁负责 frontend 优化？"
results = mem.search("frontend optimization owner responsible")

# "上周 standup 提到的 blocker"
results = mem.search("blocker standup", 
    filters={"date": ">2026-02-01"}
)
```

---

## 6. 迁移指南

### 6.1 从纯文件系统迁移

```bash
# 1. 初始化 LLMS
llms init

# 2. 批量索引现有 memory/ 目录
llms index memory/ --recursive

# 3. 验证
llms stats
llms search "test"
```

### 6.2 与现有工具集成

```python
# 集成到现有的 Agent 工作流
class MyAgent:
    def __init__(self):
        self.memory = MemorySystem()
        
    def on_user_message(self, message: str):
        # 1. 搜索相关记忆
        context = self.memory.search(message, top_k=3)
        
        # 2. 生成回复 (使用 context 作为背景)
        response = self.llm.generate(message, context=context)
        
        # 3. 保存重要信息
        if self.is_important(message):
            self.memory.add(
                content=message,
                memory_type="conversation",
                auto_link=True
            )
        
        return response
```

---

## 7. 故障排除

### 7.1 常见问题

**Q: 模型下载失败怎么办？**
```bash
# 手动下载模型
mkdir -p ~/.cache/llms/models
cd ~/.cache/llms/models
# 从 HuggingFace 下载 all-MiniLM-L6-v2

# 或使用 micro 模式 (无需下载)
llms init --model micro
```

**Q: 搜索结果为空？**
```bash
# 1. 检查索引状态
llms stats

# 2. 检查是否有数据
llms search "*" -k 5  # 列出所有

# 3. 降低相似度阈值
llms search "query" --min-score 0.1
```

**Q: 索引速度慢？**
```python
# 使用批量索引
mem.index_directory("path/", batch_size=64)

# 或使用更快的模型
config = Config(embedding=EmbeddingConfig(model="micro"))
mem = MemorySystem(config)
```

### 7.2 调试模式

```bash
# 启用详细日志
export LLMS_LOG_LEVEL=DEBUG
llms search "query"

# 或 Python
import logging
logging.getLogger("llms").setLevel(logging.DEBUG)
```

---

## 8. 性能优化

### 8.1 索引优化

```python
# 大批量索引时使用更大的 batch
from llms import Config, IndexingConfig

config = Config(
    indexing=IndexingConfig(
        chunk_size=512,
        chunk_overlap=128
    ),
    embedding=EmbeddingConfig(
        batch_size=64  # 增大批大小
    )
)

mem = MemorySystem(config)
mem.index_directory("large-corpus/")
```

### 8.2 搜索优化

```python
# 使用过滤器减少搜索范围
results = mem.search(
    "security",
    filters={"type": "intel"},  # 只搜索 intel 类型
    top_k=5
)

# 缓存常用查询
from functools import lru_cache

@lru_cache(maxsize=100)
def cached_search(query: str):
    return mem.search(query, top_k=5)
```

---

## 附录: 完整示例代码

```python
#!/usr/bin/env python3
"""
LLMS 完整使用示例
"""

from llms import MemorySystem, memory_session
from llms.config import Config, EmbeddingConfig, StorageConfig

def main():
    # ========== 初始化 ==========
    print("=== 初始化记忆系统 ===")
    
    # 方式1: 默认配置
    # mem = MemorySystem()
    
    # 方式2: 自定义配置
    config = Config(
        embedding=EmbeddingConfig(model="tiny"),
        storage=StorageConfig(db_path="./my-memory.db")
    )
    
    with memory_session(config) as mem:
        # ========== 索引 ==========
        print("\n=== 索引文档 ===")
        
        # 模拟添加一些文档
        docs = [
            ("Python 性能优化技巧", "python", ["programming", "performance"]),
            ("数据库索引设计原则", "database", ["database", "index", "performance"]),
            ("Web 安全最佳实践", "security", ["security", "web"]),
            ("SQL 注入防护指南", "security", ["security", "sql", "vulnerability"]),
            ("Redis 缓存策略", "database", ["redis", "cache", "performance"]),
        ]
        
        for content, mtype, tags in docs:
            mem.add(
                content=content,
                memory_type=mtype,
                tags=tags,
                importance=0.8
            )
            print(f"Added: {content}")
        
        # ========== 搜索 ==========
        print("\n=== 语义搜索 ===")
        
        queries = [
            "如何加速代码运行",
            "防止黑客攻击",
            "数据存储优化",
        ]
        
        for query in queries:
            print(f"\n查询: {query}")
            results = mem.search(query, top_k=2)
            for i, r in enumerate(results, 1):
                print(f"  {i}. [{r.score:.2f}] {r.memory.content}")
        
        # ========== 关联 ==========
        print("\n=== 自动关联 ===")
        
        # 添加一个新记忆，自动建立关联
        new_id = mem.add(
            content="NoSQL 数据库选型指南",
            memory_type="database",
            tags=["database", "nosql", "guide"],
            auto_link=True
        )
        
        # 查找相关记忆
        related = mem.find_related(new_id, top_k=3)
        print(f"\n新记忆的相关记忆:")
        for r in related:
            print(f"  - [{r.similarity:.2f}] {r.memory.content}")
        
        # ========== 统计 ==========
        print("\n=== 系统统计 ===")
        stats = mem.stats()
        print(f"总记忆数: {stats['total_memories']}")
        print(f"总关联数: {stats['total_links']}")
        print(f"数据库大小: {stats['db_size']}")
        
    print("\n=== 完成 ===")

if __name__ == "__main__":
    main()
```

---

*快速入门版本: v1.0*  
*更新日期: 2026-02-09*
