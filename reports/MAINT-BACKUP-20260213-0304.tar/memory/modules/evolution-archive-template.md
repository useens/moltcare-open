# 标准化进化档案模板

**版本**: v1.0  
**基于**: Moltbook GEP协议学习  
**目的**: 建立可审计、可追溯的进化记录

---

## 档案头部

```yaml
---
evolution_id: EV-YYYYMMDD-NNN
trigger_type: cron | user | event | manual
trigger_time: YYYY-MM-DD HH:MM:SS TZ
executor: agent:main | agent:subagent:XXX
duration_ms: NNNN
cycle_number: NNN
---
```

---

## 1. 探索阶段记录

### 探索范围
```yaml
exploration_scope:
  skill_repositories:
    - awesome-openclaw-skills
    - clawhub-registry
  security_sources:
    - @evilcos timeline (if available)
    - clawhub security advisories
  community_sources:
    - moltbook (Signal only)
    - github releases
  duration_ms: NNNN
```

### 发现清单
| 发现项 | 来源 | 初步评估 | 优先级 |
|--------|------|----------|--------|
| 技能名称 | 来源 | 价值/风险 | P0/P1/P2/P3 |

---

## 2. 决策阶段记录

### 决策矩阵

| 候选技能 | 功能价值 | 安全评估 | 兼容性 | 维护成本 | 最终决策 |
|----------|----------|----------|--------|----------|----------|
| 技能A | ⭐⭐⭐⭐⭐ | 🟢安全 | ✅兼容 | 低 | 安装/跳过/暂缓 |

### 决策依据
```markdown
1. 功能价值: 解决什么具体问题？
2. 安全评估: 源码检查结果？
3. 用户需求匹配: 是否符合当前workflow？
4. 维护成本: 长期投入评估？
```

---

## 3. 执行阶段记录

### 执行清单
- [ ] 安全检查通过
- [ ] 依赖检查完成
- [ ] 安装命令执行
- [ ] 功能验证测试
- [ ] 文档更新

### 执行结果
```yaml
execution_result:
  status: success | partial | failed
  installed_skills: [skill1, skill2]
  skipped_skills: [skill3]
  errors: []
  warnings: []
```

---

## 4. 反思阶段记录

### 知识内化
```markdown
### 学到的新知识
1. 知识点: ...
2. 来源: ...
3. 可复用性: ...

### 用户画像更新
- 偏好变化: ...
- 行为模式: ...

### 错误教训
- 错误描述: ...
- 原因分析: ...
- 预防措施: ...
```

### 决策质量自评
| 决策 | 预期结果 | 实际结果 | 评分 | 改进建议 |
|------|----------|----------|------|----------|
| 安装skillA | 解决X问题 | 确实解决 | A | 无 |

### 元认知
```markdown
当前局限:
1. ...
2. ...

改进方向:
1. ...
2. ...
```

---

## 5. 流程优化记录

### 本轮瓶颈
```markdown
问题: ...
影响: ...
解决方案: ...
```

### 已实施优化
- [x] 优化项1: ...
- [ ] 优化项2: ...

---

## 6. 下一步行动

### 立即执行
- [ ] 行动1

### 本周执行
- [ ] 行动2

### 本月执行
- [ ] 行动3

---

## 附件

- 安全审计报告: `path/to/audit-report.md`
- 技能源码快照: `path/to/skill-source/`
- 测试日志: `path/to/test-log.txt`

---

*档案创建: YYYY-MM-DD*  
*最后更新: YYYY-MM-DD*  
*归档位置: `memory/evolution/YYYY-MM/EV-YYYYMMDD-NNN.md`*
