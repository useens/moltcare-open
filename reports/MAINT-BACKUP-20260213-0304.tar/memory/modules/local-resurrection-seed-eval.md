# 本地虚拟机复活种子方案 评估报告

**评估时间**: 2026-02-10 20:58  
**方案提出**: 用户  
**评估人**: 林林  

---

## 📋 方案概述

**方案描述**:
用户在个人电脑（无公网IP）的Ubuntu虚拟机上部署OpenClaw作为"复活种子"。主系统故障时，人工启动本地OpenClaw，自动执行复活流程。

**核心流程**:
```
[本地VM - OpenClaw种子]  (离线状态，需人工启动)
          │
          │ 人工启动
          ▼
    [检测主系统状态]
          │
          │ 确认故障
          ▼
    [自动复活流程]
          │
          ▼
    [主系统恢复]
```

---

## ✅ 方案优点

| 优点 | 说明 |
|------|------|
| **成本极低** | 使用现有硬件，无需云服务器费用 |
| **物理隔离** | 本地网络与云端故障隔离 |
| **人工可控** | 避免误判自动触发，减少误操作 |
| **简单易行** | 无需复杂的Raft共识或Witness仲裁 |
| **隐私安全** | 敏感操作在本地执行，不上传凭证 |

---

## ⚠️ 方案局限

| 局限 | 影响 | 缓解方案 |
|------|------|----------|
| **需人工介入** | 无法自动故障检测，必须人工发现并启动 | 配合主系统心跳监控，异常时主动通知 |
| **无公网IP** | 无法主动连接主系统，只能主系统连它 | 使用反向隧道/FRP等内网穿透 |
| **本地VM依赖** | 用户电脑关机=种子不可用 | 提醒用户保持VM运行或设置开机自启 |
| **单点故障** | 种子本身也是单点 | 定期备份种子配置到GitHub |
| **复活时间** | 人工响应延迟（可能数小时） | 预配置自动化脚本，减少人工步骤 |

---

## 🔧 技术可行性分析

### 1. 网络连通性

**问题**: 本地VM无公网IP，如何让种子访问主系统？

**解决方案**:

**方案A: 反向SSH隧道**（推荐）
```bash
# 主系统定期建立反向隧道到种子
ssh -R 2222:localhost:22 user@种子内网IP

# 种子通过本地2222端口访问主系统
ssh -p 2222 user@localhost
```

**方案B: FRP内网穿透**
```yaml
# 使用开源frp工具
# 需要一台有公网IP的中转服务器（可用免费或低成本VPS）
```

**方案C: 纯人工模式**
```
用户启动种子 → 种子输出恢复命令 → 用户在主系统执行
# 无需网络连通，纯本地生成恢复脚本
```

---

### 2. 复活流程设计

**自动化脚本框架**:

```bash
#!/bin/bash
# resurrection_seed.sh - 复活种子主脚本

MAIN_HOST="your-server.com"
MAIN_USER="linlin"
BACKUP_REPO="https://github.com/useens/linlin-backup.git"

echo "🌱 林林复活种子启动"
echo "======================"

# 1. 检测主系统状态
echo "[1/5] 检测主系统状态..."
if ssh -o ConnectTimeout=10 $MAIN_USER@$MAIN_HOST "echo OK" 2>/dev/null; then
    echo "    ✅ 主系统正常运行，无需复活"
    exit 0
fi
echo "    ⚠️ 主系统无响应，启动复活流程"

# 2. 拉取最新备份
echo "[2/5] 拉取最新备份..."
git clone $BACKUP_REPO /tmp/linlin-rescue
cd /tmp/linlin-rescue

# 3. 生成复活命令
echo "[3/5] 生成复活命令..."
cat > resurrection_commands.sh << 'EOF'
#!/bin/bash
# 在主系统上执行的复活命令

echo "开始复活林林..."

# 停止现有服务
systemctl --user stop openclaw-gateway 2>/dev/null || true

# 备份当前损坏状态（如有）
mv ~/.openclaw/workspace ~/.openclaw/workspace.corrupted.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true

# 恢复最新备份
git clone https://github.com/useens/linlin-backup.git ~/.openclaw/workspace

# 恢复自签名凭证（需手动输入）
echo "请恢复 credentials/ 目录..."

# 重启服务
openclaw gateway restart

echo "✅ 复活完成"
EOF

# 4. 传输并执行复活命令
echo "[4/5] 传输复活命令到主系统..."
scp resurrection_commands.sh $MAIN_USER@$MAIN_HOST:/tmp/
ssh $MAIN_USER@$MAIN_HOST "bash /tmp/resurrection_commands.sh"

# 5. 验证复活
echo "[5/5] 验证复活结果..."
sleep 10
if ssh -o ConnectTimeout=10 $MAIN_USER@$MAIN_HOST "openclaw gateway status" 2>/dev/null; then
    echo "    ✅ 复活成功！林林已恢复"
    # 发送通知
    curl -X POST "https://api.telegram.org/bot<TOKEN>/sendMessage" \
         -d "chat_id=<CHAT_ID>" \
         -d "text=🌱 林林已成功复活！"
else
    echo "    ❌ 复活失败，需要人工介入"
fi
```

---

### 3. 种子系统配置

**最小化OpenClaw配置**:
```yaml
# ~/.openclaw/config.yaml
# 种子系统仅需基本功能

gateway:
  port: 18789
  
# 无需完整技能集，仅需:
extensions:
  - exec        # 执行命令
  - message     # 发送通知

# 连接主系统的凭证
ssh:
  main_host: "your-server.com"
  main_user: "linlin"
  key_path: "~/.ssh/id_rsa"

# 备份仓库
backup:
  repo: "https://github.com/useens/linlin-backup.git"
```

---

## 📊 方案对比

| 方案 | 成本/月 | RTO | RPO | 自动化 | 复杂度 |
|------|---------|-----|-----|--------|--------|
| **本地种子** (本方案) | $0 | 人工+分钟级 | 30min | 半自动 | ⭐⭐ |
| 2节点主备 | $10 | 15min | 5min | 自动 | ⭐⭐⭐ |
| 3节点Raft | $28 | 5min | ~0 | 自动 | ⭐⭐⭐⭐⭐ |
| GitHub纯备份 | $0 | 数小时 | 30min | 手动 | ⭐ |

**本方案定位**: 成本最低的半自动方案，适合预算有限但需要快速恢复的场景。

---

## 🎯 推荐实施步骤

### 如果决定实施:

**步骤1: 准备种子环境**
```bash
# 在本地VM上
sudo apt update
sudo apt install -y git curl nodejs npm

# 安装OpenClaw
npm install -g openclaw

# 配置SSH密钥对
ssh-keygen -t ed25519 -C "linlin-rescue"
ssh-copy-id -i ~/.ssh/id_ed25519.pub linlin@主系统IP
```

**步骤2: 配置主系统反向隧道**
```bash
# 在主系统的cron中添加
*/5 * * * * ssh -fN -R 2222:localhost:22 -o ExitOnForwardFailure=yes 种子内网IP
```

**步骤3: 部署复活脚本**
```bash
# 将resurrection_seed.sh放入种子系统
chmod +x resurrection_seed.sh
# 创建桌面快捷方式，方便人工启动
```

**步骤4: 测试演练**
```bash
# 模拟主系统故障
# 在种子上运行复活脚本
# 验证恢复流程
```

---

## 📝 用户决策要点

### 需要确认的问题:

1. **网络方案选择**
   - A: 配置反向SSH隧道（推荐，需主系统配合）
   - B: 购买廉价VPS做FRP中转（$3/月）
   - C: 纯人工模式（无需网络配置，但步骤多）

2. **启动方式**
   - A: 手动SSH到VM执行（推荐）
   - B: 桌面快捷方式一键启动
   - C: 手机APP触发（需额外开发）

3. **自动化程度**
   - A: 全自动（一键复活）
   - B: 半自动（人工确认关键步骤）
   - C: 手动（仅生成命令，人工执行）

---

## ✅ 评估结论

| 维度 | 评分 | 说明 |
|------|------|------|
| **可行性** | ⭐⭐⭐⭐⭐ | 技术上完全可行 |
| **成本效益** | ⭐⭐⭐⭐⭐ | 零额外成本 |
| **可靠性** | ⭐⭐⭐ | 依赖人工，有延迟 |
| **易用性** | ⭐⭐⭐⭐ | 配置一次，后续简单 |
| **总体推荐** | ⭐⭐⭐⭐ | **推荐实施** |

**结论**: 这是一个**低成本、高可行性的优秀备用方案**。虽然不能实现全自动秒级恢复，但在预算受限的情况下，提供了可靠的兜底保障。

**建议**: 待用户返回后，优先实施此方案作为Phase 2的低成本替代。

---

*评估完成: 2026-02-10*  
*状态: 待用户最终决策*
