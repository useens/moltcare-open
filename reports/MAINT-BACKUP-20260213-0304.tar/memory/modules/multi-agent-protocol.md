# 多代理并行协作协议 v1.0

> 建立6代理团队的标准化协作机制
> 版本: 1.0 | 创建日期: 2026-02-09

---

## 1. 代理团队构成

| 角色 | 标识符 | 主要职责 | 输出物 |
|------|--------|----------|--------|
| **架构师代理** | `architect` | 系统设计、模块划分、接口定义 | 架构文档、模块边界、接口契约 |
| **安全审计员** | `security` | 安全审查、风险评估、合规检查 | 安全报告、风险清单、修复建议 |
| **技术研究员** | `researcher` | 技术调研、方案对比、最佳实践 | 技术报告、方案对比、选型建议 |
| **开发工程师** | `developer` | 代码实现、单元测试、文档编写 | 源代码、测试用例、技术文档 |
| **测试工程师** | `tester` | 质量保证、测试设计、缺陷跟踪 | 测试计划、测试报告、缺陷清单 |
| **项目经理** | `pm` | 进度协调、资源分配、风险管理 | 项目计划、进度报告、风险日志 |

---

## 2. 任务拆分标准

### 2.1 何时使用多代理协作？

满足以下条件之一的任务需要多代理协作：

```yaml
multi_agent_trigger_conditions:
  - 任务复杂度:
      description: "涉及3个以上技术领域或模块"
      threshold: 3
  - 任务规模:
      description: "预估工作量超过8小时"
      threshold: "8h"
  - 安全要求:
      description: "涉及敏感数据处理或关键业务流程"
      critical: true
  - 时间约束:
      description: "截止时间紧迫，需要并行执行"
      parallel_required: true
  - 质量要求:
      description: "需要多维度审查(安全+性能+可维护性)"
      review_dimensions: ">= 3"
```

### 2.2 任务拆分策略

#### 2.2.1 按领域拆分（Domain-Based）
适用于：系统架构设计、大型功能开发

```
原始任务: 设计并开发电商平台
    ├── 架构师: 系统架构设计
    ├── 安全审计员: 安全架构审查
    ├── 技术研究员: 技术选型调研
    ├── 开发工程师: 核心模块开发
    ├── 测试工程师: 测试策略设计
    └── 项目经理: 项目计划制定
```

#### 2.2.2 按阶段拆分（Phase-Based）
适用于：需要严格阶段验收的任务

```
阶段1: 需求分析 (所有代理参与)
    ├── 技术研究员: 可行性调研
    └── 项目经理: 需求梳理

阶段2: 设计阶段
    ├── 架构师: 系统设计
    └── 安全审计员: 设计安全审查

阶段3: 实现阶段
    ├── 开发工程师: 代码实现
    └── 测试工程师: 测试开发

阶段4: 验收阶段
    └── 所有代理: 联合评审
```

#### 2.2.3 按依赖关系拆分（Dependency-Based）
适用于：有明确依赖链的任务

```yaml
task_dependencies:
  architect:
    - task: "设计系统架构"
    - outputs: ["接口契约", "模块边界"]
    - next: ["developer", "tester"]
  
  security:
    - task: "安全架构审查"
    - depends_on: ["architect"]
    - outputs: ["安全报告"]
  
  researcher:
    - task: "技术调研"
    - parallel_to: ["architect"]
    - outputs: ["技术选型报告"]
  
  developer:
    - task: "代码实现"
    - depends_on: ["architect", "researcher"]
    - outputs: ["源代码"]
  
  tester:
    - task: "测试执行"
    - depends_on: ["developer"]
    - outputs: ["测试报告"]
  
  pm:
    - task: "进度管理"
    - monitors: ["all"]
    - outputs: ["进度报告"]
```

### 2.3 代理间依赖关系管理

#### 依赖类型

| 类型 | 符号 | 说明 | 示例 |
|------|------|------|------|
| 强依赖 | `→` | 必须等待前置任务完成 | `architect → developer` |
| 弱依赖 | `⇢` | 可并行，但需要同步信息 | `researcher ⇢ developer` |
| 通知依赖 | `↠` | 完成后需通知，但无需等待 | `developer ↠ pm` |
| 无依赖 | `∥` | 完全并行执行 | `architect ∥ researcher` |

#### 依赖图示例

```
┌─────────────┐     ┌─────────────┐
│  Architect  │────→│  Security   │
│  (架构师)   │     │  (安全员)   │
└──────┬──────┘     └─────────────┘
       │
       │ 强依赖
       ↓
┌─────────────┐     ┌─────────────┐
│  Developer  │────→│   Tester    │
│  (开发工程师)│     │ (测试工程师)│
└─────────────┘     └─────────────┘
       ↑
       │ 弱依赖
┌──────┴──────┐
│  Researcher │
│ (技术研究员)│
└─────────────┘
       ↓
┌─────────────┐
│     PM      │ ← 监控所有代理
│  (项目经理) │
└─────────────┘
```

---

## 3. 通信协议

### 3.1 通信信道

```yaml
communication_channels:
  # 1. 状态同步信道（State Channel）
  state_channel:
    location: "memory/multi-agent/sync/"
    format: "JSON状态文件"
    update_frequency: "每个状态变更时"
    subscribers: "所有代理 + 协调器"
  
  # 2. 消息队列信道（Message Queue）
  message_queue:
    location: "memory/multi-agent/messages/"
    format: "Markdown消息文件"
    naming: "{timestamp}-{from}-{to}.md"
    retention: "任务完成后归档"
  
  # 3. 成果共享信道（Artifact Channel）
  artifact_channel:
    location: "memory/multi-agent/artifacts/"
    format: "各代理输出文件"
    indexing: "按代理和任务组织"
  
  # 4. 协调器指令信道（Coordinator Channel）
  coordinator_channel:
    location: "memory/multi-agent/coordinator/"
    format: "指令文件"
    access: "仅协调器写入，代理读取"
```

### 3.2 消息格式标准

#### 状态更新消息

```json
{
  "message_type": "STATUS_UPDATE",
  "timestamp": "2026-02-09T02:51:00+08:00",
  "from_agent": "developer",
  "task_id": "task-001",
  "status": "IN_PROGRESS",
  "progress_percent": 45,
  "deliverables": [
    {
      "name": "user_service.py",
      "path": "memory/multi-agent/artifacts/developer/user_service.py",
      "status": "COMPLETED"
    }
  ],
  "blockers": [],
  "next_steps": ["完成订单模块"],
  "notes": "用户模块开发完成，正在进行单元测试"
}
```

#### 协作请求消息

```json
{
  "message_type": "COLLABORATION_REQUEST",
  "timestamp": "2026-02-09T02:55:00+08:00",
  "from_agent": "developer",
  "to_agent": "architect",
  "task_id": "task-001",
  "request_type": "CLARIFICATION",
  "subject": "用户服务接口定义澄清",
  "content": "关于用户认证的Token格式，文档中未明确...",
  "priority": "HIGH",
  "response_deadline": "2026-02-09T03:30:00+08:00"
}
```

#### 成果交付消息

```json
{
  "message_type": "DELIVERABLE_COMPLETE",
  "timestamp": "2026-02-09T03:00:00+08:00",
  "from_agent": "tester",
  "task_id": "task-001",
  "deliverable": {
    "name": "测试报告",
    "type": "DOCUMENT",
    "path": "memory/multi-agent/artifacts/tester/test-report.md",
    "artifacts": [
      "test-cases/",
      "coverage-report/"
    ]
  },
  "quality_metrics": {
    "test_coverage": 85,
    "pass_rate": 98,
    "critical_bugs": 0
  },
  "reviewers": ["developer", "pm"]
}
```

### 3.3 状态同步机制

#### 代理状态生命周期

```
┌─────────┐    任务分配    ┌─────────┐
│  IDLE   │ ─────────────→│ PENDING │
│ (空闲)  │               │ (待启动)│
└─────────┘               └────┬────┘
                               │ 开始执行
                               ↓
┌─────────┐   遇到阻塞    ┌─────────┐
│COMPLETED│←─────────────│BLOCKED  │
│ (完成)  │               │ (阻塞)  │
└────┬────┘               └────┬────┘
     │    阻塞解除              │
     │  ←──────────────────────┘
     │
     ↓ 任务完成
┌─────────┐
│ REVIEW  │ ← 等待审核
│ (审核中)│
└────┬────┘
     │
     ↓ 审核通过
┌─────────┐
│ ACCEPTED│
│ (已验收)│
└─────────┘
```

#### 状态文件结构

```yaml
# memory/multi-agent/sync/task-{task_id}-status.yaml
task_id: "task-001"
task_name: "电商平台开发"
created_at: "2026-02-09T02:00:00+08:00"
coordinator: "coordinator-agent"

agents:
  architect:
    status: "COMPLETED"
    started_at: "2026-02-09T02:05:00+08:00"
    completed_at: "2026-02-09T02:30:00+08:00"
    deliverables:
      - name: "system-architecture.md"
        path: "artifacts/architect/system-architecture.md"
        status: "ACCEPTED"
    
  security:
    status: "IN_PROGRESS"
    started_at: "2026-02-09T02:10:00+08:00"
    progress: 60
    deliverables:
      - name: "security-review.md"
        status: "DRAFT"
    
  researcher:
    status: "COMPLETED"
    started_at: "2026-02-09T02:05:00+08:00"
    completed_at: "2026-02-09T02:25:00+08:00"
    
  developer:
    status: "IN_PROGRESS"
    started_at: "2026-02-09T02:35:00+08:00"
    progress: 30
    blocked_by: []
    
  tester:
    status: "PENDING"
    waiting_for: ["developer"]
    
  pm:
    status: "MONITORING"
    last_check: "2026-02-09T02:50:00+08:00"

overall_progress: 45%
estimated_completion: "2026-02-09T06:00:00+08:00"
```

### 3.4 冲突解决规则

#### 冲突类型与处理策略

| 冲突类型 | 说明 | 解决策略 | 决策权 |
|----------|------|----------|--------|
| **技术方案冲突** | 不同代理对技术选型有分歧 | 技术研究员提案 → 架构师仲裁 | 架构师 |
| **接口定义冲突** | 模块间接口不匹配 | 返回架构师重新设计 | 架构师 |
| **资源竞争冲突** | 多个代理需要同一资源 | 项目经理调度优先级 | 项目经理 |
| **质量要求冲突** | 交付质量与进度矛盾 | 三方评估（PM+架构师+安全员） | 项目经理 |
| **安全与功能冲突** | 安全要求阻碍功能实现 | 安全审计员提案 → 架构师调整 | 安全审计员 |

#### 冲突升级流程

```
Level 1: 代理间协商
    ↓ 5分钟内未解决
Level 2: 相关方代理联合评审
    ↓ 10分钟内未解决
Level 3: 协调器介入仲裁
    ↓ 需重大决策
Level 4: 上报人类决策者
```

---

## 4. 监督机制

### 4.1 协调器监控职责

```yaml
coordinator_responsibilities:
  monitoring:
    - 实时跟踪所有代理状态
    - 检测任务阻塞和异常
    - 监控进度偏差
    - 协调资源分配
    
  intervention:
    - 触发代理启动/停止
    - 重新分配任务
    - 调解代理间冲突
    - 触发重试机制
    
  reporting:
    - 生成进度报告
    - 汇总交付成果
    - 记录经验教训
    - 更新任务状态
```

### 4.2 监控指标体系

#### 任务级指标

| 指标 | 计算方法 | 阈值 | 告警级别 |
|------|----------|------|----------|
| 进度偏差 | (实际进度 - 计划进度) / 计划进度 | > 20% | 黄色告警 |
| 完成延迟 | 当前时间 - 预计完成时间 | > 30分钟 | 橙色告警 |
| 阻塞时长 | 处于BLOCKED状态的时间 | > 15分钟 | 红色告警 |
| 质量分数 | 基于测试通过率/安全评分 | < 70分 | 红色告警 |

#### 代理级指标

| 指标 | 说明 | 正常范围 |
|------|------|----------|
| 响应时间 | 从消息发送到响应的时间 | < 2分钟 |
| 任务吞吐量 | 单位时间完成的任务数 | > 2个/小时 |
| 成功率 | 成功完成的任务占比 | > 90% |

### 4.3 超时处理策略

#### 超时定义

```yaml
timeout_policies:
  agent_response:
    description: "代理响应超时"
    threshold: "5 minutes"
    action: "发送提醒 → 10分钟后标记异常"
    
  task_execution:
    description: "任务执行超时"
    threshold: "预估时间的150%"
    action: "检查阻塞原因 → 决定继续/中止/拆分"
    
  idle_timeout:
    description: "代理空闲超时"
    threshold: "30 minutes无活动"
    action: "询问状态 → 回收任务"
    
  coordination_timeout:
    description: "协调等待超时"
    threshold: "15分钟等待响应"
    action: "强制继续/跳过阻塞代理"
```

#### 超时处理流程

```
检测到超时
    ↓
┌─────────────────┐
│  1. 发送提醒消息  │
│  (礼貌询问状态)   │
└────────┬────────┘
         │
         ↓ 等待2分钟
┌─────────────────┐
│  2. 升级处理    │
│  (检查阻塞原因)  │
└────────┬────────┘
         │
    ┌────┴────┐
    ↓         ↓
┌───────┐ ┌────────┐
│阻塞可 │ │ 阻塞不可│
│解决   │ │ 解决    │
└───┬───┘ └────┬───┘
    ↓          ↓
┌────────┐ ┌──────────┐
│分配帮助 │ │ 任务重新  │
│资源    │ │ 分配/跳过 │
└────────┘ └──────────┘
```

### 4.4 失败重试策略

#### 重试级别

```yaml
retry_policies:
  level_1_transient:
    description: "瞬时错误（网络、临时资源不可用）"
    max_retries: 3
    backoff: "指数退避: 2^retry * 10秒"
    examples: ["网络超时", "临时文件锁"]
    
  level_2_recoverable:
    description: "可恢复错误（逻辑错误、输入问题）"
    max_retries: 2
    backoff: "固定间隔: 30秒"
    action: "提供修正提示后重试"
    examples: ["参数错误", "依赖未就绪"]
    
  level_3_persistent:
    description: "持久错误（代码缺陷、设计问题）"
    max_retries: 0
    action: "标记失败，转人工处理或终止任务"
    examples: ["代码编译失败", "架构设计缺陷"]
```

#### 重试状态机

```
        开始执行
           │
           ↓
    ┌──────────────┐
    │   执行任务    │
    └──────┬───────┘
           │
      ┌────┴────┐
      ↓         ↓
   成功        失败
      │         │
      ↓         ↓
   完成    ┌──────────┐
          │识别错误类型│
          └────┬─────┘
               │
        ┌─────┼─────┐
        ↓     ↓     ↓
     瞬时   可恢复  持久
    (L1)   (L2)   (L3)
        │     │     │
        ↓     ↓     ↓
     重试   修正   失败
     N次    重试   终止
```

---

## 5. 交付与验收

### 5.1 交付物标准

每个代理必须输出：

```yaml
deliverable_requirements:
  mandatory:
    - name: "成果文件"
      format: "按任务类型定义"
      location: "memory/multi-agent/artifacts/{agent}/"
    
    - name: "状态报告"
      format: "YAML状态文件"
      content: ["完成状态", "质量指标", "遗留问题"]
    
    - name: "交接文档"
      format: "Markdown"
      required_when: "有下游依赖代理"
      
  optional:
    - name: "决策记录"
      format: "Markdown"
      content: "关键决策及其理由"
    
    - name: "改进建议"
      format: "Markdown"
      content: "对流程/工具的改进建议"
```

### 5.2 验收流程

```
代理完成任务
      ↓
┌─────────────┐
│ 自我检查    │
│ (质量门禁)   │
└──────┬──────┘
       │ 通过
       ↓
┌─────────────┐
│ 提交审核    │
│ (通知相关方) │
└──────┬──────┘
       ↓
┌─────────────┐
│ 联合评审    │
│ (上游+下游)  │
└──────┬──────┘
       │
  ┌────┴────┐
  ↓         ↓
通过       不通过
  │         │
  ↓         ↓
┌──────┐ ┌────────┐
│ACCEPTED│ │ 返工   │
│       │ │ (记录原因)│
└──────┘ └────────┘
```

---

## 6. 附录

### 6.1 术语表

| 术语 | 定义 |
|------|------|
| **协调器** | 主代理，负责任务分发、监控和协调 |
| **代理** | 执行特定任务的子代理 |
| **任务** | 分配给代理的工作单元 |
| **交付物** | 代理产出的具体成果 |
| **阻塞** | 代理因外部依赖无法继续执行的状态 |

### 6.2 版本历史

| 版本 | 日期 | 变更说明 |
|------|------|----------|
| 1.0 | 2026-02-09 | 初始版本 |

### 6.3 相关文档

- `multi-agent-templates.md` - 标准模板库
- `multi-agent-{task-id}/` - 具体任务的执行记录
