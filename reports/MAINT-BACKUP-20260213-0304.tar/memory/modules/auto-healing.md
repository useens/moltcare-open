# 自动故障检测与自愈系统 v1.0

## 系统概述

这是一个智能的故障检测和自动恢复系统，能够：
- 持续监控系统健康状态
- 检测到故障时自动选择合适的备份恢复
- 无需人工干预即可自我治愈

---

## 监测指标

### 1. 核心文件完整性
- MEMORY.md 是否存在且非空
- AGENTS.md 是否存在且非空
- SOUL.md 是否存在且非空
- USER.md 是否存在

### 2. 技能系统状态
- 技能目录是否存在
- 核心技能（healthcheck, clawhub）是否可用

### 3. 记忆系统状态
- 记忆目录是否存在
- 是否有记忆文件
- 记忆系统是否活跃（48小时内是否有更新）

### 4. Gateway 运行状态
- Gateway 进程是否存在
- 监听端口是否正常

### 5. 备份系统状态
- 备份目录是否存在
- 是否有可用备份
- 备份是否新鲜（24小时内）

---

## 故障分级

### 🔴 严重故障（立即触发恢复）
- 核心配置文件丢失或损坏
- 记忆系统完全不可用
- 备份系统损坏

### 🟠 中度故障（累计3次触发恢复）
- 技能系统部分损坏
- 记忆文件缺失
- 连续检查失败

### 🟡 轻微故障（仅记录警告）
- 备份超过24小时未更新
- 记忆系统超过48小时未更新
- Gateway 未运行

---

## 自动恢复流程

```
检测到故障
    ↓
失败计数 +1
    ↓
失败次数 ≥ 3？
    ↓ 是
创建恢复前紧急备份
    ↓
查找最新可用备份
    ↓
验证备份完整性（SHA256）
    ↓
停止 Gateway
    ↓
备份当前损坏状态
    ↓
解压恢复备份
    ↓
重启 Gateway
    ↓
恢复成功，重置失败计数
    ↓
记录恢复日志
```

---

## 恢复策略

### 选择备份版本的逻辑

1. **首选**：最新的完整备份（*_full.tar.gz）
2. **验证失败**：尝试更早的备份
3. **无完整备份**：尝试小时备份
4. **全部失败**：使用紧急备份

### 冷却机制

- 恢复后 5 分钟内不再触发恢复
- 防止恢复过程中的循环恢复

---

## 使用方法

### 手动检查健康状态

```bash
/root/.openclaw/workspace/scripts/health-monitor.sh check
```

### 手动触发恢复

```bash
/root/.openclaw/workspace/scripts/health-monitor.sh recover
```

### 查看健康状态

```bash
/root/.openclaw/workspace/scripts/health-monitor.sh status
```

### 持续监控模式

```bash
/root/.openclaw/workspace/scripts/health-monitor.sh monitor
```

---

## 状态文件

健康状态保存在：
```
/root/.openclaw/backups/.health-state.json
```

包含：
- 检查次数
- 失败次数
- 上次失败时间
- 上次恢复时间
- 各检查项状态

---

## 日志文件

监控日志保存在：
```
/root/.openclaw/backups/health-monitor.log
```

---

## 定时任务

每 5 分钟自动执行一次健康检查：

```cron
*/5 * * * * /root/.openclaw/workspace/scripts/health-monitor.sh check
```

如果检查失败，自动尝试恢复。

---

## 恢复后检查

恢复成功后：
1. 自动重启 Gateway
2. 重置失败计数
3. 记录恢复使用的备份版本
4. 生成恢复报告

---

## 故障排除

### 如果自动恢复失败

1. 检查健康状态：
   ```bash
   cat /root/.openclaw/backups/.health-state.json
   ```

2. 查看恢复日志：
   ```bash
   tail -50 /root/.openclaw/backups/health-monitor.log
   ```

3. 手动选择备份恢复：
   ```bash
   # 查看可用备份
   ls -lt /root/.openclaw/backups/local/*.tar.gz
   
   # 手动恢复
   tar -xzf /path/to/backup.tar.gz -C /root/.openclaw
   ```

4. 如果全部失败，参考完整恢复指南：
   ```
   /root/.openclaw/workspace/memory/modules/restore-guide.md
   ```

---

## 安全机制

1. **恢复前备份**：自动备份当前损坏状态
2. **备份验证**：恢复前验证 SHA256 校验和
3. **冷却时间**：恢复后 5 分钟冷却期
4. **失败上限**：最多尝试 3 次自动恢复

---

## 当前状态

**系统健康状态**：✅ 健康  
**自动监控**：✅ 运行中  
**上次检查**：刚刚  
**失败次数**：0  

---

*系统版本：v1.0*  
*最后更新：2026-02-09*
