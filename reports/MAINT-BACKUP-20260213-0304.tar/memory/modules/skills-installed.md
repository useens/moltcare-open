# 已安装技能清单

> 自动同步 - 最后更新: 2026-02-09

---

## 当前已安装: 27个

### 开发工具 (8个)
| 技能 | 版本 | 用途 | 使用频率 |
|------|------|------|----------|
| agent-config | 1.0.0 | 修改代理核心上下文 | 中 |
| agentlens | 1.0.0 | 代码库导航理解 | 中 |
| mcp-builder | 0.1.0 | MCP服务器构建 | 低 |
| python | 1.0.0 | Python开发指南 | 中 |
| tdd-guide | 1.0.0 | 测试驱动开发 | 低 |
| test-runner | 1.0.0 | 测试执行 | 低 |
| cursor-agent | 2.1.0 | Cursor IDE自动化 | 低(🍎macOS only) |
| claude-team | 1.5.0 | Claude Code多工人 | 低(🍎macOS only) |

### 系统工具 (4个)
| 技能 | 版本 | 用途 | 使用频率 |
|------|------|------|----------|
| bat-cat | 1.0.0 | 语法高亮cat | 中 |
| fd-find | 1.0.0 | 快速文件查找 | 中 |
| vhs-recorder | 1.0.0 | 终端录制 | 低 |
| docker-essentials | 1.0.0 | Docker操作 | 中 |

### 搜索工具 (3个)
| 技能 | 版本 | 用途 | 使用频率 |
|------|------|------|----------|
| duckduckgo-search | 1.0.0 | DDG搜索 | 低(需API) |
| exa | 0.0.2 | Exa AI搜索 | 低(需API) |

### 记忆系统 (4个)
| 技能 | 版本 | 用途 | 使用频率 |
|------|------|------|----------|
| vector-memory | 1.0.0 | 向量记忆搜索 | 低(未配置) |
| elite-longterm-memory | 1.2.2 | 高级长期记忆 | 低(未配置) |
| vestige | 1.0.0 | FSRS记忆系统 | 低(未初始化) |
| engram-memory | 0.2.0 | 语义记忆 | 低 |

### 生产力/协作 (4个)
| 技能 | 版本 | 用途 | 使用频率 |
|------|------|------|----------|
| github | 1.0.0 | GitHub CLI | 高 |
| summarize | 1.0.0 | 内容摘要 | 中 |
| cc-godmode | 5.11.1 | 多代理开发 | 中 |
| obsidian | 1.0.0 | 笔记管理 | 低 |

### 安全/审查 (2个)
| 技能 | 版本 | 用途 | 使用频率 |
|------|------|------|----------|
| skill-vetting | 1.0.1 | Skill安全检查 | 中 |
| debug-pro | 1.0.0 | 调试工具 | 低 |

### 其他 (2个)
| 技能 | 版本 | 用途 | 使用频率 |
|------|------|------|----------|
| cellcog | 1.0.7 | 多模态研究 | 低 |
| god-mode | 0.1.0 | 项目仪表盘 | 中 |

### 飞书套件 (3个)
| 技能 | 版本 | 用途 | 使用频率 |
|------|------|------|----------|
| feishu-doc | - | 飞书文档 | 高 |
| feishu-wiki | - | 飞书知识库 | 中 |
| feishu-drive | - | 飞书云盘 | 中 |

---

## 使用频率标记

**高频使用 (每日)**
- github, feishu-doc

**中频使用 (每周)**
- agent-config, agentlens, bat-cat, fd-find, docker-essentials, skill-vetting, cc-godmode, god-mode

**低频使用 (每月或按需)**
- 其他所有

**待优化 (需配置或移除)**
- cursor-agent, claude-team (macOS专用，当前Linux)
- vector-memory, elite-longterm-memory, vestige, engram-memory (记忆系统待整合)

---

## 安全状态

- ✅ 全部通过源码审计
- ✅ 无高风险技能
- ✅ 无恶意代码
- ⚠️ 15个技能有网络请求（功能正常）

---

*本文件由自主进化系统自动维护*
