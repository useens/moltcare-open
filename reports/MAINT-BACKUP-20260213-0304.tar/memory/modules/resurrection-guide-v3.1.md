# 🛡️ 数字永生 - 完整复活指南

> 确保林林能够在任何灾难后完全恢复运行  
> 版本: v3.1  
> 更新: 2026-02-10

---

## 📋 系统概览

### 核心组件
| 组件 | 版本 | 用途 | 备份状态 |
|------|------|------|----------|
| Python | 3.11 | 运行环境 | 需重建 |
| OpenClaw | 2026.2.6-3 | Agent网关 | 配置文件 |
| LanceDB | 0.29.2 | 向量数据库 | GitHub |
| BGE-large | v1.5 | 嵌入模型 | 自动下载 |
| 记忆向量 | 1265条 | 核心记忆 | GitHub |
| 定时任务 | 8个 | 自主进化 | GitHub |

### 关键目录结构
```
~/.openclaw/
├── workspace/              # ⭐ 核心工作区（GitHub备份）
│   ├── core/              # 向量记忆系统代码
│   ├── memory/            # 记忆文件（daily/modules/evolution）
│   ├── scripts/           # 工具脚本
│   ├── docs/              # 文档
│   ├── requirements.txt   # Python依赖
│   └── venv/              # 虚拟环境（❌不备份，需重建）
├── openclaw.json          # 配置文件（含密钥）
└── agents/
    └── main/              # Agent配置
```

---

## 🔧 依赖清单

### Python 依赖
见 `requirements.txt`（已生成在 workspace 根目录）

**关键包**:
```
lancedb==0.29.2
sentence-transformers
torch
numpy
openai-whisper
pylance
```

### 系统依赖
```bash
# Ubuntu/Debian
apt-get update
apt-get install -y python3.11 python3.11-venv python3-pip ffmpeg git

# 可选：Node.js（用于 Playwright）
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs
```

---

## 🚀 复活步骤

### 步骤 1: 准备新服务器

```bash
# 1. 安装系统依赖
apt-get update
apt-get install -y python3.11 python3.11-venv python3-pip ffmpeg git curl

# 2. 创建工作目录
mkdir -p ~/.openclaw
cd ~/.openclaw

# 3. 从 GitHub 恢复代码
git clone https://github.com/[你的仓库]/linlin-workspace.git workspace
cd workspace
```

### 步骤 2: 重建 Python 环境

```bash
# 1. 创建虚拟环境
python3.11 -m venv venv

# 2. 激活环境
source venv/bin/activate

# 3. 安装依赖
pip install --upgrade pip
pip install -r requirements.txt

# 4. 验证安装
python -c "import lancedb; import torch; print('✅ 核心依赖正常')"
```

### 步骤 3: 恢复 OpenClaw 配置

```bash
# 1. 安装 OpenClaw（如果未安装）
npm install -g openclaw

# 2. 恢复配置文件
# 将备份的 openclaw.json 复制到 ~/.openclaw/
cp /path/to/backup/openclaw.json ~/.openclaw/

# 3. 验证配置
openclaw doctor
```

### 步骤 4: 恢复向量记忆

```bash
# 向量数据库已从 GitHub 恢复，检查状态
cd ~/.openclaw/workspace
source venv/bin/activate

python -c "
from memory_adapter import get_memory_adapter
adapter = get_memory_adapter()
print(f'✅ 向量记忆系统已加载')
print(f'📊 记忆向量: {adapter._memory.vector_store.count()} 条')
"
```

### 步骤 5: 恢复定时任务

```bash
# 查看当前 cron 任务
openclaw cron list

# 如果任务丢失，根据 memory/modules/linlin-v3.1-release.md 重建
# 或从 MEMORY.md 中的"自主进化系统 v2.0"章节获取配置
```

### 步骤 6: 启动服务

```bash
# 启动 OpenClaw
cd ~/.openclaw/workspace
openclaw start

# 验证健康状态
openclaw doctor
```

---

## 📦 备份清单

### 必须备份的内容 ✅
| 内容 | 位置 | 备份方式 |
|------|------|----------|
| 工作区代码 | workspace/ | GitHub |
| 记忆文件 | memory/ | GitHub |
| 配置文件 | openclaw.json | 加密备份 |
| 依赖清单 | requirements.txt | GitHub |
| 脚本工具 | scripts/ | GitHub |

### 不需要备份的内容 ❌
| 内容 | 原因 |
|------|------|
| venv/ | 可重建，平台相关 |
| 模型缓存 | 自动下载 (~1.2GB) |
| 日志文件 | 可重新生成 |

---

## 🔐 关键凭证

⚠️ **以下信息需要安全备份，不在 GitHub 中**

- OpenClaw 认证令牌
- Moltbook API Key
- Feishu App ID / Secret
- Telegram Bot Token
- 任何私钥或密码

**建议**: 使用密码管理器或加密 USB 存储

---

## ✅ 复活验证清单

恢复后执行以下检查：

```bash
# 1. 系统检查
openclaw doctor

# 2. 向量记忆检查
python scripts/vector-memory-cleanup.py

# 3. 定时任务检查
openclaw cron list
# 应看到 8 个任务

# 4. 记忆检索测试
python -c "
from memory_adapter import memory_search
results = memory_search('备份策略', max_results=1)
print(f'✅ 记忆检索正常: {len(results)} 条结果')
"

# 5. 双渠道测试
# - 发送测试消息到 Telegram
# - 发送测试消息到 Feishu
```

---

## 🆘 故障排除

### 问题 1: 模型下载失败
```bash
# 手动下载 BGE 模型
python -c "
from sentence_transformers import SentenceTransformer
model = SentenceTransformer('BAAI/bge-large-zh-v1.5')
"
```

### 问题 2: LanceDB 版本不兼容
```bash
# 升级 LanceDB
pip install --upgrade lancedb pylance
```

### 问题 3: 定时任务未触发
```bash
# 检查 cron 服务
openclaw cron status
# 重启 cron
openclaw cron restart
```

### 问题 4: 内存不足
```bash
# 减少并发
# 编辑 openclaw.json，降低 maxConcurrent
```

---

## 📊 恢复时间估算

| 步骤 | 时间 | 依赖 |
|------|------|------|
| 系统准备 | 10分钟 | 网络 |
| 环境重建 | 15分钟 | 依赖下载 |
| 模型下载 | 5分钟 | 网络 |
| 配置恢复 | 5分钟 | 备份文件 |
| 验证测试 | 10分钟 | - |
| **总计** | **~45分钟** | - |

---

## 🔄 定期维护建议

- **每周**: 检查 GitHub 备份状态
- **每月**: 测试复活流程（沙盒环境）
- **每季度**: 更新依赖版本
- **每年**: 完整灾难恢复演练

---

## 📞 紧急联系

如果复活失败：
1. 检查本指南的故障排除章节
2. 查看日志: `~/.openclaw/logs/`
3. 联系用户获取凭证备份

---

*本指南确保林林可以在任何服务器故障后 45 分钟内完全恢复*  
*数字永生，不仅是备份，更是可执行的复活计划*
