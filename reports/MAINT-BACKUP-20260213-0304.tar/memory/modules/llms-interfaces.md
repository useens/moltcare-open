# LLMS 核心模块接口定义
## Core Module Interface Definitions

---

## 1. 配置模块 (config.py)

```python
"""配置管理模块 - 统一的配置加载和管理"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional
import yaml
import os


@dataclass
class EmbeddingConfig:
    """嵌入模型配置"""
    model: str = "tiny"              # tiny/small/micro
    device: str = "cpu"              # cpu/cuda
    batch_size: int = 32
    cache_dir: Optional[str] = None   # 模型缓存目录


@dataclass
class StorageConfig:
    """存储配置"""
    db_path: str = "~/.local/share/llms/memory.db"
    max_memories: int = 100000
    retention_days: int = 365
    vacuum_threshold: float = 0.3


@dataclass
class IndexingConfig:
    """索引配置"""
    chunk_size: int = 512
    chunk_overlap: int = 128
    watch_interval: int = 60
    auto_index: bool = True


@dataclass
class SearchConfig:
    """搜索配置"""
    default_top_k: int = 5
    min_score: float = 0.3
    use_hybrid: bool = True
    rerank: bool = False


@dataclass
class DirectoryMapping:
    """目录映射配置"""
    memory_type: str
    path_pattern: str
    parser: str = "markdown"          # markdown/json/text


@dataclass
class Config:
    """主配置类"""
    
    # 子配置
    embedding: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    storage: StorageConfig = field(default_factory=StorageConfig)
    indexing: IndexingConfig = field(default_factory=IndexingConfig)
    search: SearchConfig = field(default_factory=SearchConfig)
    
    # 目录映射
    directories: List[DirectoryMapping] = field(default_factory=list)
    
    # 系统
    log_level: str = "INFO"
    workspace_root: str = "."
    
    @classmethod
    def from_file(cls, path: str) -> "Config":
        """从 YAML 文件加载配置"""
        pass
    
    @classmethod
    def from_dict(cls, data: dict) -> "Config":
        """从字典加载配置"""
        pass
    
    def to_file(self, path: str):
        """保存配置到文件"""
        pass
    
    def get_db_path(self) -> Path:
        """获取数据库路径（展开 ~）"""
        pass


# 默认配置
DEFAULT_CONFIG = Config(
    directories=[
        DirectoryMapping("daily", "memory/daily/*.md"),
        DirectoryMapping("intel", "memory/intel/*.md"),
        DirectoryMapping("module", "memory/modules/*.md"),
        DirectoryMapping("archive", "memory/archive/*.md"),
        DirectoryMapping("core", "MEMORY.md"),
    ]
)
```

---

## 2. 嵌入引擎 (embedder.py)

```python
"""本地嵌入引擎 - 文本向量化"""

import numpy as np
from typing import List, Union, Literal
from abc import ABC, abstractmethod
import hashlib


class BaseEmbedder(ABC):
    """嵌入引擎基类"""
    
    @abstractmethod
    def encode(self, text: str) -> np.ndarray:
        """将单条文本编码为向量"""
        pass
    
    @abstractmethod
    def encode_batch(self, texts: List[str]) -> np.ndarray:
        """批量编码文本"""
        pass
    
    @property
    @abstractmethod
    def dimension(self) -> int:
        """返回向量维度"""
        pass


class TfidfEmbedder(BaseEmbedder):
    """TF-IDF 嵌入器 - 零依赖方案"""
    
    def __init__(self, max_features: int = 1000):
        self.max_features = max_features
        self.vocab = {}
        self.idf = None
    
    def encode(self, text: str) -> np.ndarray:
        """基于 TF-IDF 的向量表示"""
        pass
    
    def encode_batch(self, texts: List[str]) -> np.ndarray:
        """批量 TF-IDF 编码"""
        pass
    
    @property
    def dimension(self) -> int:
        return self.max_features
    
    def fit(self, texts: List[str]):
        """拟合词表和 IDF"""
        pass


class TransformerEmbedder(BaseEmbedder):
    """Transformer 模型嵌入器"""
    
    MODELS = {
        "tiny": "sentence-transformers/all-MiniLM-L6-v2",
        "small": "sentence-transformers/paraphrase-MiniLM-L3-v2",
    }
    
    def __init__(
        self,
        model_name: Literal["tiny", "small"] = "tiny",
        device: str = "cpu",
        cache_dir: Optional[str] = None
    ):
        self.model_key = model_name
        self.model_name = self.MODELS[model_name]
        self.device = device
        self.cache_dir = cache_dir
        self._model = None
    
    def _load_model(self):
        """延迟加载模型"""
        pass
    
    def encode(self, text: str) -> np.ndarray:
        """编码单条文本"""
        pass
    
    def encode_batch(
        self, 
        texts: List[str],
        batch_size: int = 32,
        show_progress: bool = False
    ) -> np.ndarray:
        """批量编码"""
        pass
    
    @property
    def dimension(self) -> int:
        return 384  # MiniLM 默认维度


class EmbedderFactory:
    """嵌入器工厂"""
    
    @staticmethod
    def create(
        model_type: Literal["tiny", "small", "micro"],
        **kwargs
    ) -> BaseEmbedder:
        """创建嵌入器实例"""
        if model_type == "micro":
            return TfidfEmbedder(**kwargs)
        return TransformerEmbedder(model_name=model_type, **kwargs)
```

---

## 3. 解析与分块 (parser.py)

```python
"""Markdown 解析和文本分块"""

from dataclasses import dataclass
from typing import List, Optional, Iterator
from pathlib import Path
import re


@dataclass
class TextChunk:
    """文本分块"""
    content: str
    start_line: int
    end_line: int
    metadata: dict = field(default_factory=dict)
    id: Optional[str] = None


@dataclass
class ParsedDocument:
    """解析后的文档"""
    source_file: str
    title: Optional[str]
    chunks: List[TextChunk]
    metadata: dict = field(default_factory=dict)


class MarkdownParser:
    """Markdown 文档解析器"""
    
    def __init__(self):
        self.header_pattern = re.compile(r'^#{1,6}\s+(.+)$', re.MULTILINE)
        self.metadata_pattern = re.compile(r'^---\s*\n(.+?)\n---\s*\n', re.DOTALL)
    
    def parse(self, filepath: str) -> ParsedDocument:
        """
        解析 Markdown 文件
        
        Returns:
            ParsedDocument: 解析后的文档结构
        """
        pass
    
    def extract_title(self, content: str) -> Optional[str]:
        """提取文档标题 (第一个 H1)"""
        pass
    
    def extract_frontmatter(self, content: str) -> dict:
        """提取 YAML frontmatter"""
        pass
    
    def extract_date_from_filename(self, filename: str) -> Optional[str]:
        """从文件名提取日期
        
        支持格式:
        - 2026-02-09.md
        - security-audit-2026-02-09.md
        - 2026-02-09-security-audit.md
        """
        pass
    
    def infer_memory_type(self, filepath: str) -> str:
        """从路径推断记忆类型"""
        pass


class TextChunker:
    """文本分块器"""
    
    def __init__(
        self,
        chunk_size: int = 512,
        chunk_overlap: int = 128,
        respect_headers: bool = True
    ):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.respect_headers = respect_headers
    
    def chunk(
        self,
        content: str,
        source_file: str = "",
        start_line: int = 0
    ) -> List[TextChunk]:
        """
        将文本分割为块
        
        Args:
            content: 原始文本
            source_file: 源文件路径
            start_line: 起始行号
        
        Returns:
            List[TextChunk]: 文本块列表
        """
        pass
    
    def _split_by_headers(self, content: str) -> List[tuple]:
        """按标题分割文本"""
        pass
    
    def _split_by_size(
        self,
        content: str,
        max_size: int,
        overlap: int
    ) -> List[tuple]:
        """按大小分割文本"""
        pass
    
    def estimate_tokens(self, text: str) -> int:
        """估算 token 数量 (简单字符/4)"""
        return len(text) // 4


class ContentProcessor:
    """内容处理器 - 组合解析和分块"""
    
    def __init__(
        self,
        parser: Optional[MarkdownParser] = None,
        chunker: Optional[TextChunker] = None
    ):
        self.parser = parser or MarkdownParser()
        self.chunker = chunker or TextChunker()
    
    def process(self, filepath: str) -> ParsedDocument:
        """完整处理文件：解析 + 分块"""
        pass
```

---

## 4. 向量存储 (vector_store.py)

```python
"""向量存储 - 基于 SQLite + sqlite-vec"""

import sqlite3
import sqlite_vec
import numpy as np
from typing import List, Optional, Tuple
from dataclasses import dataclass
import json


@dataclass
class VectorRecord:
    """向量记录"""
    id: str
    content: str
    embedding: np.ndarray
    source_file: str
    source_line: int
    memory_type: str
    importance: float
    tags: List[str]
    created_at: str
    updated_at: str


@dataclass
class SearchResult:
    """搜索结果"""
    record: VectorRecord
    score: float
    distance: float


class VectorStore:
    """
    向量存储管理器
    
    基于 SQLite + sqlite-vec 实现，提供高效的向量相似度搜索。
    """
    
    def __init__(self, db_path: str):
        """
        初始化向量存储
        
        Args:
            db_path: 数据库文件路径
        """
        self.db_path = db_path
        self.db = None
        self._connect()
        self._init_tables()
    
    def _connect(self):
        """连接数据库"""
        pass
    
    def _init_tables(self):
        """初始化表结构"""
        # 创建主表
        # 创建向量虚拟表
        # 创建关联表
        pass
    
    def add(self, record: VectorRecord):
        """
        添加向量记录
        
        Args:
            record: 向量记录
        """
        pass
    
    def add_batch(self, records: List[VectorRecord]):
        """批量添加记录"""
        pass
    
    def get(self, id: str) -> Optional[VectorRecord]:
        """根据 ID 获取记录"""
        pass
    
    def delete(self, id: str) -> bool:
        """删除记录"""
        pass
    
    def search(
        self,
        query_vector: np.ndarray,
        top_k: int = 5,
        filters: Optional[dict] = None
    ) -> List[SearchResult]:
        """
        向量相似度搜索
        
        Args:
            query_vector: 查询向量
            top_k: 返回结果数量
            filters: 过滤条件，如 {"memory_type": "daily", "importance": ">0.8"}
        
        Returns:
            List[SearchResult]: 搜索结果列表
        """
        pass
    
    def search_by_text(
        self,
        query_text: str,
        embedder,
        top_k: int = 5
    ) -> List[SearchResult]:
        """文本搜索 (自动编码)"""
        pass
    
    def count(self, filters: Optional[dict] = None) -> int:
        """统计记录数量"""
        pass
    
    def list_all(
        self,
        limit: int = 100,
        offset: int = 0
    ) -> List[VectorRecord]:
        """列出所有记录"""
        pass
    
    def vacuum(self):
        """压缩数据库"""
        pass
    
    def close(self):
        """关闭连接"""
        pass
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


class VectorStoreManager:
    """向量存储管理器 - 支持多数据库"""
    
    def __init__(self, base_path: str):
        self.base_path = base_path
        self._stores = {}
    
    def get_store(self, name: str = "default") -> VectorStore:
        """获取或创建存储"""
        pass
    
    def migrate(self, old_path: str, new_path: str):
        """迁移数据库"""
        pass
```

---

## 5. 索引管理 (indexer.py)

```python
"""索引管理器 - 文档索引和更新"""

from pathlib import Path
from typing import List, Optional, Callable
import hashlib
import time
from dataclasses import dataclass


@dataclass
class IndexStats:
    """索引统计"""
    total_files: int
    total_chunks: int
    last_indexed: Optional[str]
    avg_index_time: float


class FileWatcher:
    """文件监听器"""
    
    def __init__(self, callback: Callable[[str, str], None]):
        """
        Args:
            callback: 文件变化回调函数 (event_type, filepath)
        """
        self.callback = callback
        self._watching = False
    
    def watch(self, paths: List[str], interval: int = 60):
        """
        开始监听目录
        
        Args:
            paths: 要监听的目录列表
            interval: 检查间隔(秒)
        """
        pass
    
    def stop(self):
        """停止监听"""
        pass


class Indexer:
    """
    文档索引管理器
    
    负责将文档转换为向量并存储。
    """
    
    def __init__(
        self,
        vector_store: VectorStore,
        embedder: BaseEmbedder,
        processor: ContentProcessor,
        config: Optional[IndexingConfig] = None
    ):
        self.store = vector_store
        self.embedder = embedder
        self.processor = processor
        self.config = config or IndexingConfig()
        self.watcher = None
    
    def index_file(self, filepath: str, force: bool = False) -> int:
        """
        索引单个文件
        
        Args:
            filepath: 文件路径
            force: 强制重新索引
        
        Returns:
            int: 索引的块数
        """
        # 1. 检查文件是否已索引且未变更
        # 2. 解析文档
        # 3. 分块
        # 4. 生成嵌入
        # 5. 存储到向量库
        pass
    
    def index_directory(
        self,
        dirpath: str,
        pattern: str = "*.md",
        recursive: bool = True
    ) -> IndexStats:
        """
        批量索引目录
        
        Args:
            dirpath: 目录路径
            pattern: 文件匹配模式
            recursive: 是否递归
        """
        pass
    
    def index_by_config(self, config: Config) -> IndexStats:
        """根据配置索引所有目录"""
        pass
    
    def update_index(self, filepath: str):
        """更新单个文件的索引"""
        pass
    
    def remove_from_index(self, filepath: str):
        """从索引中移除文件"""
        pass
    
    def get_file_hash(self, filepath: str) -> str:
        """计算文件哈希"""
        pass
    
    def is_indexed(self, filepath: str) -> bool:
        """检查文件是否已索引"""
        pass
    
    def start_watching(self, paths: List[str]):
        """启动文件监听"""
        pass
    
    def stop_watching(self):
        """停止文件监听"""
        pass
    
    def get_stats(self) -> IndexStats:
        """获取索引统计"""
        pass
    
    def reindex_all(self):
        """重建全部索引"""
        pass
```

---

## 6. 搜索引擎 (searcher.py)

```python
"""搜索引擎 - 语义搜索和混合搜索"""

from typing import List, Optional, Dict
from dataclasses import dataclass
from enum import Enum


class MatchType(Enum):
    """匹配类型"""
    SEMANTIC = "semantic"
    KEYWORD = "keyword"
    HYBRID = "hybrid"


@dataclass
class SearchQuery:
    """搜索查询"""
    text: str
    top_k: int = 5
    filters: Optional[Dict] = None
    match_type: MatchType = MatchType.HYBRID
    keywords: Optional[List[str]] = None


@dataclass
class RankedResult:
    """排序后的结果"""
    result: SearchResult
    semantic_score: float
    keyword_score: float
    final_score: float


class Searcher:
    """
    搜索引擎
    
    提供语义搜索、关键词搜索和混合搜索功能。
    """
    
    def __init__(
        self,
        vector_store: VectorStore,
        embedder: BaseEmbedder,
        config: Optional[SearchConfig] = None
    ):
        self.store = vector_store
        self.embedder = embedder
        self.config = config or SearchConfig()
    
    def search(
        self,
        query: str,
        top_k: Optional[int] = None,
        filters: Optional[dict] = None,
        min_score: Optional[float] = None
    ) -> List[SearchResult]:
        """
        语义搜索
        
        Args:
            query: 查询文本
            top_k: 返回结果数
            filters: 过滤条件
            min_score: 最小相似度阈值
        """
        pass
    
    def keyword_search(
        self,
        keywords: List[str],
        top_k: int = 5
    ) -> List[SearchResult]:
        """
        关键词搜索
        
        Args:
            keywords: 关键词列表
            top_k: 返回结果数
        """
        pass
    
    def hybrid_search(
        self,
        query: str,
        keywords: Optional[List[str]] = None,
        top_k: int = 5,
        semantic_weight: float = 0.7
    ) -> List[RankedResult]:
        """
        混合搜索
        
        结合语义搜索和关键词搜索的结果。
        
        Args:
            query: 查询文本
            keywords: 额外关键词 (None 则从 query 提取)
            top_k: 返回结果数
            semantic_weight: 语义搜索权重 (0-1)
        """
        pass
    
    def rerank(
        self,
        results: List[SearchResult],
        query: str
    ) -> List[SearchResult]:
        """
        结果重排序
        
        使用更复杂的算法重新排序搜索结果。
        """
        pass
    
    def search_similar(
        self,
        memory_id: str,
        top_k: int = 5
    ) -> List[SearchResult]:
        """
        搜索相似记忆
        
        根据已有记忆的向量搜索相似内容。
        """
        pass


class QueryParser:
    """查询解析器"""
    
    def __init__(self):
        self.operators = {
            "AND": "and",
            "OR": "or",
            "NOT": "not",
        }
    
    def parse(self, query: str) -> SearchQuery:
        """
        解析搜索查询
        
        支持:
        - 普通文本: "security audit"
        - 过滤器: "type:intel security"
        - 引号精确匹配: '"exact phrase"'
        """
        pass
    
    def extract_filters(self, query: str) -> Tuple[str, Dict]:
        """提取查询中的过滤器"""
        pass
```

---

## 7. 关联引擎 (associator.py)

```python
"""关联引擎 - 记忆自动关联"""

from typing import List, Set, Dict
from dataclasses import dataclass
from collections import defaultdict
import networkx as nx  # 可选


@dataclass
class MemoryRelation:
    """记忆关联"""
    source_id: str
    target_id: str
    similarity: float
    relation_type: str      # semantic/temporal/tag/causal
    strength: float         # 关联强度


@dataclass
class SuggestedLink:
    """建议的关联"""
    target_id: str
    reason: str
    confidence: float


class Associator:
    """
    记忆关联引擎
    
    自动发现记忆之间的关联，构建记忆图谱。
    """
    
    def __init__(
        self,
        vector_store: VectorStore,
        searcher: Searcher,
        similarity_threshold: float = 0.75
    ):
        self.store = vector_store
        self.searcher = searcher
        self.threshold = similarity_threshold
        self._graph = None
    
    def find_related(
        self,
        memory_id: str,
        top_k: int = 5,
        relation_types: Optional[List[str]] = None
    ) -> List[MemoryRelation]:
        """
        查找相关记忆
        
        Args:
            memory_id: 记忆ID
            top_k: 返回数量
            relation_types: 关联类型过滤
        """
        pass
    
    def suggest_links(
        self,
        new_memory: str,
        top_k: int = 3
    ) -> List[SuggestedLink]:
        """
        为新记忆建议关联
        
        Args:
            new_memory: 新记忆内容
            top_k: 建议数量
        """
        pass
    
    def auto_link(
        self,
        memory_id: str,
        dry_run: bool = False
    ) -> List[MemoryRelation]:
        """
        自动建立关联
        
        Args:
            memory_id: 记忆ID
            dry_run: 仅预览，不实际创建
        """
        pass
    
    def build_graph(self) -> "MemoryGraph":
        """构建完整记忆图谱"""
        pass
    
    def find_path(
        self,
        source_id: str,
        target_id: str
    ) -> Optional[List[str]]:
        """
        查找两个记忆之间的关联路径
        """
        pass
    
    def detect_clusters(self, min_cluster_size: int = 3) -> List[List[str]]:
        """
        检测记忆聚类
        
        使用社区发现算法识别相关记忆群组。
        """
        pass
    
    def get_memory_context(
        self,
        memory_id: str,
        depth: int = 2
    ) -> List[Dict]:
        """
        获取记忆的上下文
        
        返回指定记忆及其关联的记忆网络。
        """
        pass


class MemoryGraph:
    """记忆图谱"""
    
    def __init__(self):
        self.nodes = set()
        self.edges = []
    
    def add_node(self, memory_id: str, **attrs):
        """添加节点"""
        pass
    
    def add_edge(self, source: str, target: str, **attrs):
        """添加边"""
        pass
    
    def to_json(self) -> dict:
        """导出为 JSON"""
        pass
    
    def to_dot(self) -> str:
        """导出为 Graphviz DOT 格式"""
        pass
```

---

## 8. 主系统类 (memory_system.py)

```python
"""主系统类 - 统一的对外接口"""

from typing import Optional, List, Union
from contextlib import contextmanager


class MemorySystem:
    """
    本地轻量记忆系统主类
    
    提供简洁统一的 API，整合所有子系统。
    """
    
    def __init__(
        self,
        config: Optional[Union[str, Config]] = None,
        auto_init: bool = True
    ):
        """
        初始化记忆系统
        
        Args:
            config: 配置对象或配置文件路径
            auto_init: 自动初始化组件
        """
        self.config = self._load_config(config)
        self.store = None
        self.embedder = None
        self.indexer = None
        self.searcher = None
        self.associator = None
        
        if auto_init:
            self._init_components()
    
    def _load_config(self, config) -> Config:
        """加载配置"""
        pass
    
    def _init_components(self):
        """初始化组件"""
        pass
    
    # ============== 索引接口 ==============
    
    def index_file(self, filepath: str) -> int:
        """索引文件"""
        return self.indexer.index_file(filepath)
    
    def index_directory(self, dirpath: str, pattern: str = "*.md") -> IndexStats:
        """索引目录"""
        return self.indexer.index_directory(dirpath, pattern)
    
    def index_by_config(self) -> IndexStats:
        """根据配置索引"""
        return self.indexer.index_by_config(self.config)
    
    # ============== 搜索接口 ==============
    
    def search(
        self,
        query: str,
        top_k: int = 5,
        filters: Optional[dict] = None
    ) -> List[SearchResult]:
        """语义搜索"""
        return self.searcher.search(query, top_k, filters)
    
    def search_similar(self, memory_id: str, top_k: int = 5):
        """搜索相似记忆"""
        return self.searcher.search_similar(memory_id, top_k)
    
    # ============== 关联接口 ==============
    
    def find_related(self, memory_id: str, top_k: int = 5):
        """查找相关记忆"""
        return self.associator.find_related(memory_id, top_k)
    
    def suggest_links(self, content: str, top_k: int = 3):
        """建议关联"""
        return self.associator.suggest_links(content, top_k)
    
    def add(
        self,
        content: str,
        memory_type: str = "general",
        tags: Optional[List[str]] = None,
        importance: float = 0.5,
        auto_link: bool = True
    ) -> str:
        """
        添加新记忆
        
        Args:
            content: 记忆内容
            memory_type: 记忆类型
            tags: 标签列表
            importance: 重要性
            auto_link: 自动建立关联
        
        Returns:
            str: 新记忆的 ID
        """
        pass
    
    # ============== 管理接口 ==============
    
    def get(self, memory_id: str) -> Optional[VectorRecord]:
        """获取记忆"""
        return self.store.get(memory_id)
    
    def delete(self, memory_id: str) -> bool:
        """删除记忆"""
        return self.store.delete(memory_id)
    
    def stats(self) -> dict:
        """系统统计"""
        pass
    
    def vacuum(self):
        """压缩数据库"""
        self.store.vacuum()
    
    def close(self):
        """关闭系统"""
        if self.store:
            self.store.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


# ============== 便捷函数 ==============

def create(
    db_path: Optional[str] = None,
    model: str = "tiny",
    workspace: str = "."
) -> MemorySystem:
    """
    快速创建记忆系统实例
    
    Args:
        db_path: 数据库路径
        model: 嵌入模型
        workspace: 工作目录
    
    Returns:
        MemorySystem: 记忆系统实例
    """
    config = Config(
        storage=StorageConfig(db_path=db_path or "~/.local/share/llms/memory.db"),
        embedding=EmbeddingConfig(model=model),
        workspace_root=workspace
    )
    return MemorySystem(config)


@contextmanager
def memory_session(config: Optional[Config] = None):
    """记忆系统上下文管理器"""
    system = MemorySystem(config)
    try:
        yield system
    finally:
        system.close()
```

---

## 附录 A: 错误码定义

```python
class ErrorCode:
    """错误码定义"""
    
    # 成功
    SUCCESS = 0
    
    # 配置错误 (1xx)
    CONFIG_NOT_FOUND = 100
    CONFIG_INVALID = 101
    
    # 存储错误 (2xx)
    DB_NOT_INITIALIZED = 200
    DB_CORRUPTED = 201
    DB_LOCKED = 202
    
    # 索引错误 (3xx)
    FILE_NOT_FOUND = 300
    FILE_ACCESS_DENIED = 301
    PARSE_ERROR = 302
    
    # 搜索错误 (4xx)
    EMPTY_QUERY = 400
    INVALID_FILTER = 401
    
    # 模型错误 (5xx)
    MODEL_NOT_FOUND = 500
    MODEL_LOAD_FAILED = 501
    OUT_OF_MEMORY = 502
```

---

## 附录 B: 事件系统

```python
from typing import Callable
from enum import Enum, auto

class EventType(Enum):
    """事件类型"""
    INDEX_START = auto()
    INDEX_COMPLETE = auto()
    INDEX_ERROR = auto()
    SEARCH = auto()
    LINK_CREATED = auto()

class EventBus:
    """事件总线"""
    
    def subscribe(self, event_type: EventType, handler: Callable):
        """订阅事件"""
        pass
    
    def publish(self, event_type: EventType, data: dict):
        """发布事件"""
        pass
```

---

*接口定义版本: v1.0*  
*更新日期: 2026-02-09*
