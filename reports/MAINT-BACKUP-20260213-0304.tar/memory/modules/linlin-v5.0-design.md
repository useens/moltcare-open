# 🚀 林林 v5.0 - 预判先知系统 设计文档

**版本代号**: Prophet (先知)  
**发布时间**: 待定 (预计2-3周开发)  
**上一版本**: v4.1 - 工具链完善版  
**设计目标**: 零成本实现从"响应"到"预判"的质变  

---

## 🎯 核心概念

### 什么是预判？

| 层次 | 描述 | 示例 |
|------|------|------|
| **L1 响应** | 用户问，我答 | "今天天气？" → 查天气 |
| **L2 关联** | 基于关键词联想 | "天气" → 主动查天气 |
| **L3 预判** (v5.0) | 基于时间/地点/行为预测 | 周一8点 → 自动发本周日程 |
| **L4 直觉** | 像人一样"懂"你 | 你还没想，我已经做了 |

### v5.0 目标：达到 L3 预判

---

## 📊 预判维度设计

### 1. 时间模式预判

**检测模式**:
```python
time_patterns = {
    "周一早上": {
        "trigger": "datetime.now().weekday() == 0 and 8 <= hour < 10",
        "action": "send_weekly_calendar",
        "confidence": 0.85
    },
    "周五下午": {
        "trigger": "weekday == 4 and 16 <= hour < 18",
        "action": "suggest_weekend_plans",
        "confidence": 0.70
    },
    "月底": {
        "trigger": "day >= 28",
        "action": "remind_monthly_tasks",
        "confidence": 0.75
    },
    "连续工作3h+": {
        "trigger": "active_duration > 180min",
        "action": "suggest_break",
        "confidence": 0.80
    }
}
```

**用户配置**:
```json
{
  "time_based_prophecies": {
    "weekly_calendar": {"enabled": true, "time": "08:00"},
    "break_reminder": {"enabled": true, "interval": 120},
    "monthly_summary": {"enabled": false}
  }
}
```

---

### 2. 行为链预判

**学习用户行为链**:
```
历史模式识别:
  搜索酒店 → 30分钟后搜索机票 → 1小时后问签证
  ↓
  模式: [酒店] → [机票] → [签证] = 出行准备链
  ↓
  预判: 当检测到[酒店]搜索，30分钟后主动推送机票信息
```

**实现机制**:
```python
class BehaviorChainDetector:
    def __init__(self):
        self.chains = []  # 从memory学习
        
    def detect_chain(self, action):
        """检测当前行为属于哪个链"""
        for chain in self.chains:
            if action in chain.steps:
                position = chain.steps.index(action)
                if position < len(chain.steps) - 1:
                    next_action = chain.steps[position + 1]
                    delay = chain.delays[position]
                    return Prophecy(
                        action=f"预判用户可能需要: {next_action}",
                        delay=delay,
                        confidence=chain.confidence
                    )
        return None
```

---

### 3. 上下文关联预判

**多源信息融合**:
```python
context_fusion = {
    "邮件": {
        "meeting_invite": {
            "extract": ["time", "location", "participants"],
            "prophecy": {
                "1h_before": "准备会议材料",
                "15min_before": "提醒参会",
                "after": "生成会议纪要模板"
            }
        }
    },
    "日历": {
        "upcoming_event": {
            "extract": ["type", "location", "duration"],
            "prophecy": {
                "day_before": "确认准备情况",
                "2h_before": "天气+交通提醒",
                "15min_before": "最终提醒"
            }
        }
    },
    "对话": {
        "mentioned_task": {
            "extract": ["task", "deadline", "priority"],
            "prophecy": {
                "daily": "进度检查",
                "deadline-1d": "紧急提醒"
            }
        }
    }
}
```

---

## 🛠️ 技术架构

### 整体架构

```
┌─────────────────────────────────────────────────────────┐
│                   林林 v5.0 预判系统                     │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌──────────────┐    ┌──────────────┐                  │
│  │  输入监听器   │───▶│  上下文融合   │                  │
│  │              │    │  (多源聚合)   │                  │
│  └──────────────┘    └──────┬───────┘                  │
│                             │                          │
│                             ▼                          │
│                    ┌──────────────┐                    │
│                    │  模式识别器   │                    │
│                    │  (学习历史)   │                    │
│                    └──────┬───────┘                    │
│                           │                            │
│              ┌────────────┼────────────┐              │
│              ▼            ▼            ▼              │
│        ┌─────────┐  ┌─────────┐  ┌─────────┐        │
│        │时间预判 │  │行为预判 │  │关联预判 │        │
│        └────┬────┘  └────┬────┘  └────┬────┘        │
│             └─────────────┼─────────────┘            │
│                           ▼                          │
│                    ┌──────────────┐                  │
│                    │  预判仲裁器   │                  │
│                    │ (置信度排序)  │                  │
│                    └──────┬───────┘                  │
│                           │                          │
│                           ▼                          │
│                    ┌──────────────┐                  │
│                    │   决策门     │                  │
│                    │ (L1-L5分级)  │                  │
│                    └──────┬───────┘                  │
│                           │                          │
│                           ▼                          │
│                    ┌──────────────┐                  │
│                    │   执行器     │                  │
│                    │ (静默/通知)  │                  │
│                    └──────────────┘                  │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

### 模块详细设计

#### 1. 输入监听器 (Input Listener)

**职责**: 监听所有用户交互和系统事件

```python
class InputListener:
    """监听所有输入源"""
    
    def __init__(self):
        self.sources = [
            MessageListener(),      # 监听消息
            CalendarListener(),     # 监听日历
            EmailListener(),        # 监听邮件
            ActivityListener(),     # 监听用户活动
        ]
    
    async def start(self):
        """启动所有监听器"""
        for source in self.sources:
            asyncio.create_task(source.listen())
    
    def on_event(self, event):
        """统一事件处理"""
        context = self.build_context(event)
        return context
```

---

#### 2. 模式识别器 (Pattern Recognizer)

**职责**: 从记忆中学习用户行为模式

```python
class PatternRecognizer:
    """识别用户行为模式"""
    
    def learn_from_memory(self, days=30):
        """从近期记忆学习模式"""
        # 读取 daily logs
        logs = self.load_recent_logs(days)
        
        # 识别时间模式
        time_patterns = self.extract_time_patterns(logs)
        
        # 识别行为链
        behavior_chains = self.extract_behavior_chains(logs)
        
        # 保存模式
        self.save_patterns({
            'time': time_patterns,
            'chains': behavior_chains
        })
    
    def extract_time_patterns(self, logs):
        """提取时间相关模式"""
        patterns = []
        
        # 分析每日活跃时间
        active_hours = self.analyze_active_hours(logs)
        
        # 识别周期性行为
        for action in ['calendar_check', 'weather_query', 'news_read']:
            schedule = self.find_regular_schedule(logs, action)
            if schedule:
                patterns.append({
                    'action': action,
                    'schedule': schedule,
                    'confidence': schedule.confidence
                })
        
        return patterns
```

---

#### 3. 预判仲裁器 (Prophecy Arbiter)

**职责**: 当多个预判冲突时，决定执行哪个

```python
class ProphecyArbiter:
    """预判仲裁与排序"""
    
    def arbitrate(self, prophecies: List[Prophecy]) -> Prophecy:
        """从多个预判中选择最优"""
        
        # 过滤低置信度
        filtered = [p for p in prophecies if p.confidence > 0.6]
        
        # 按优先级排序
        prioritized = sorted(filtered, key=lambda p: (
            -p.confidence,      # 置信度高的优先
            -p.urgency,          # 紧急度高的优先
            p.user_preference    # 用户偏好的优先
        ))
        
        return prioritized[0] if prioritized else None
```

---

#### 4. 决策门 (Decision Gate)

**职责**: 根据L1-L5分级决定如何处理预判

```python
class DecisionGate:
    """预判决策分级"""
    
    def evaluate(self, prophecy: Prophecy) -> Action:
        """评估预判并决定执行方式"""
        
        if prophecy.risk_level == "L1":
            # 无风险，静默执行
            return Action.EXECUTE_SILENT
        
        elif prophecy.risk_level == "L2":
            # 极低风险，执行后记录
            return Action.EXECUTE_LOG
        
        elif prophecy.risk_level == "L3":
            # 低风险，执行后汇报
            return Action.EXECUTE_NOTIFY
        
        elif prophecy.risk_level == "L4":
            # 中风险，预执行+确认
            return Action.PREVIEW_CONFIRM
        
        elif prophecy.risk_level == "L5":
            # 中高风险，方案+请示
            return Action.PROPOSE_WAIT
        
        else:
            # 高风险，禁止自动
            return Action.BLOCK_MANUAL
```

---

## 📋 预判规则库 (v1.0)

### 内置预判规则

```yaml
rules:
  # 时间类预判
  - name: "周一早晨日程"
    trigger:
      type: "time"
      condition: "weekday == 0 and 08:00 <= time < 10:00"
    action:
      type: "send_calendar"
      template: "本周日程"
    risk: "L2"
    
  - name: "工作休息提醒"
    trigger:
      type: "activity"
      condition: "active_duration > 120min and no_break"
    action:
      type: "suggest_break"
      template: "休息提醒"
    risk: "L1"
    
  - name: "会议准备"
    trigger:
      type: "calendar"
      condition: "event_in_1h and type == 'meeting'"
    action:
      type: "prepare_materials"
      template: "会议准备"
    risk: "L3"
    
  # 行为链预判
  - name: "出行准备链"
    trigger:
      type: "behavior_chain"
      pattern: ["search_hotel", "search_flight"]
      position: 0
    action:
      type: "suggest_next"
      next_step: "search_flight"
      delay: "30min"
    risk: "L2"
    
  - name: "签证提醒"
    trigger:
      type: "behavior_chain"
      pattern: ["search_hotel", "search_flight", "ask_visa"]
      position: 1
    action:
      type: "suggest_next"
      next_step: "visa_info"
      delay: "1h"
    risk: "L2"
    
  # 上下文预判
  - name: "邮件任务追踪"
    trigger:
      type: "email"
      condition: "contains_task and has_deadline"
    action:
      type: "track_task"
      reminders: ["daily", "deadline-1d"]
    risk: "L3"
```

---

## 🔧 实施计划

### Phase 1: 基础设施 (Week 1)

- [ ] 创建 `memory/modules/prophecy/` 目录结构
- [ ] 实现输入监听器框架
- [ ] 连接现有 memory_search 系统
- [ ] 创建用户配置界面

### Phase 2: 模式学习 (Week 1-2)

- [ ] 实现时间模式识别
- [ ] 实现行为链提取算法
- [ ] 从历史记忆学习用户习惯
- [ ] 保存学习到的模式

### Phase 3: 预判引擎 (Week 2)

- [ ] 实现预判生成器
- [ ] 实现仲裁器
- [ ] 实现决策门
- [ ] 连接执行器

### Phase 4: 集成测试 (Week 3)

- [ ] 集成到主会话
- [ ] 添加预判日志记录
- [ ] 用户可调整预判敏感度
- [ ] 测试各种场景

### Phase 5: 发布 (Week 3)

- [ ] 创建 v5.0 发布档案
- [ ] 更新 MEMORY.md
- [ ] 备份并推送GitHub
- [ ] 监控运行效果

---

## 📊 成功度量

| 指标 | 基线 (v4.1) | 目标 (v5.0) | 测量方式 |
|------|-------------|-------------|----------|
| 预判准确率 | 0% | > 70% | 用户反馈 |
| 预判有用率 | N/A | > 60% | 用户采纳率 |
| 打扰率 | N/A | < 20% | 用户关闭数 |
| 预判覆盖场景 | 0 | 10+ | 规则数量 |

---

## ⚠️ 风险控制

### 避免过度打扰

```python
# 打扰控制机制
class DisturbanceController:
    def __init__(self):
        self.daily_quota = 5  # 每日最多预判提醒次数
        self.quiet_hours = [(23, 8)]  # 静默时段
        
    def should_deliver(self, prophecy) -> bool:
        """判断是否应交付预判"""
        # 检查静默时段
        if self.is_quiet_hour():
            return False
        
        # 检查每日配额
        if self.daily_count >= self.daily_quota:
            return False
        
        # 检查用户反馈
        if self.user_rejected_similar(prophecy):
            return False
        
        return True
```

### 用户随时可关闭

```yaml
user_controls:
  master_switch: true  # 总开关
  
  categories:
    time_based: true
    behavior_chain: true
    context_aware: false  # 用户可单独关闭某类
  
  quiet_hours:
    start: "23:00"
    end: "08:00"
  
  max_daily_prophecies: 5
```

---

## 🎁 用户价值

### 使用前后对比

| 场景 | v4.1 | v5.0 |
|------|------|------|
| 周一早晨 | 等你问"这周有什么安排" | 自动发送本周日程 |
| 准备出行 | 每次单独查询 | 自动推荐下一步 |
| 工作3小时 | 无反应 | 提醒休息+天气 |
| 会议前 | 可能忘记 | 提前准备提醒 |
| 月底 | 无反应 | 提醒待办事项 |

---

## 📝 设计备注

**设计原则**:
1. **零成本**: 不依赖外部API，纯本地实现
2. **可配置**: 用户完全掌控，随时开关
3. **可学习**: 从用户行为中学习，越用越准
4. **不打扰**: 严格配额控制，质量>数量

**技术选择**:
- 使用现有向量记忆系统存储模式
- 使用现有cron系统触发定时预判
- 使用现有memory_search进行关联分析
- 复用现有L1-L5决策分级体系

---

*设计文档完成: 2026-02-10*  
*状态: 已批准，待实施*  
*预计完成: 2-3周*
