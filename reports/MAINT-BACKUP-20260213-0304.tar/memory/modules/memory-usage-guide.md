# 记忆系统使用规范 v2.0

> 决策辅助指南：基于向量搜索的记忆检索规范

---

## 1. 决策前记忆检索规范

### 1.1 强制检索场景

在执行以下操作**之前**，**必须**检索相关记忆：

| 场景类型 | 检索关键词示例 | 参考记忆类型 |
|---------|--------------|-------------|
| 安装新技能 | `skill安装`、`安全检查`、`{skill名称}` | modules/skills-installed.md, modules/safety-protocol.md |
| 修改系统配置 | `配置`、`架构`、`决策` | modules/decisions.md, modules/memory-system-arch.md |
| 处理安全相关 | `安全`、`审计`、`风险` | tags/security-audits.md, modules/safety-protocol.md |
| 启动新项目 | `项目`、`状态`、`进行中` | modules/recent-milestones.md |
| 编写代码/脚本 | `错误`、`教训`、`最佳实践` | modules/error-lessons.md, modules/auto-healing.md |
| 与用户交互 | `用户画像`、`偏好`、`指令` | modules/user-profile.md, tags/user-instructions.md |

### 1.2 检索流程

```
决策前检索流程:
┌─────────────────────────────────────────────────────────┐
│ 1. 关键词提取                                           │
│    - 从用户请求中提取 2-3 个核心关键词                   │
│                                                         │
│ 2. 向量搜索                                             │
│    $ node memory/.index/memory-indexer.js search <关键词>│
│                                                         │
│ 3. 相关性评估                                           │
│    - 检查搜索结果 score > 5.0 的文档                     │
│    - 阅读摘要，判断相关性                                │
│                                                         │
│ 4. 交叉引用                                             │
│    - 查看文档的关联文档                                  │
│    - 确认是否有矛盾信息                                  │
│                                                         │
│ 5. 决策执行                                             │
│    - 基于记忆信息做出决策                                │
│    - 记录决策到 modules/decisions.md                     │
└─────────────────────────────────────────────────────────┘
```

### 1.3 搜索命令参考

```bash
# 基础搜索
cd /root/.openclaw/workspace/memory/.index
node memory-indexer.js search "关键词"

# 搜索结果分析
# - score > 10: 高度相关，必须阅读
# - score 5-10: 中度相关，建议阅读
# - score < 5: 参考即可
```

---

## 2. 档案标准化规范

### 2.1 文件命名规范

```
daily/                    → YYYY-MM-DD.md
                         → YYYY-MM-DD-event.md (特殊事件)
                         → YYYY-MM-DD-evolution-HHMM.md (进化报告)

summary/weekly/           → YYYY-MM-DD.md (周日日期)
summary/monthly/          → YYYY-MM.md

tags/                     → {tag-name}.md (小写，连字符分隔)

modules/                  → {kebab-case-name}.md
                         → 主要分类：
                           - user-* (用户相关)
                           - skill-* (技能相关)
                           - memory-* (记忆系统)
                           - llms-* (LLMs相关)
                           - safety-* (安全相关)

intel/                    → {source}-learning-YYYYMMDD.md
                         → {topic}-tracking.md

evolution/YYYY-MM/        → EV-YYYYMMDD-NNN.md (序号)
```

### 2.2 文档结构标准

**所有 .md 文件必须包含：**

```markdown
# 标题

## 元数据 (可选但推荐)
- 创建: YYYY-MM-DD
- 类型: daily|module|intel|evolution
- 标签: #标签1 #标签2

## 正文内容
...

## 关联文档 (可选)
- [[相关文档1]]
- [[相关文档2]]
```

### 2.3 标签使用规范

**强制标签 (根据内容至少一个):**
- `#指令` - 用户明确指令
- `#发现` - 新发现的信息
- `#决策` - 做出的决策
- `#技能` - 技能安装/更新
- `#安全` - 安全相关
- `#错误` - 错误和教训
- `#进化` - 自主进化相关

**标签格式:**
- 使用中文标签
- 标签前必须有空格：`内容 #标签` ✓ `内容#标签` ✗

---

## 3. 定期整理和归档流程

### 3.1 每日维护 (自动)

**执行时间**: 每日 23:50

```bash
# 1. 增量索引
node memory/.index/memory-indexer.js index

# 2. 检查重复内容
node memory/.index/memory-indexer.js stats

# 3. 归档检查
# - 超过 3 个月的 daily/ 移动到 archive/
```

### 3.2 每周维护 (周日)

**执行时间**: 每周日 23:50

```
周维护清单:
□ 汇总本周 daily/ 到 summary/weekly/
□ 检查并合并重复/冗余内容
□ 更新 modules/recent-milestones.md
□ 验证索引完整性
□ 清理已删除文件的索引残留
```

### 3.3 每月维护

**执行时间**: 每月最后一天 23:50

```
月维护清单:
□ 汇总本月 weekly/ 到 summary/monthly/
□ 压缩归档超过 3 个月的 daily/ 文件
□ 更新 MEMORY.md 核心摘要
□ 重新生成完整索引
□ 清理 search_history 超过 30 天的记录
```

### 3.4 归档标准

**需要归档的内容:**
- 3个月前的 daily/ 文件
- 已废弃的模块文档
- 旧的进化报告（保留核心里程碑）

**归档格式:**
```
archive/
├── YYYY-MM.tar.gz          # 按月压缩
└── archive-index.json      # 归档索引
```

---

## 4. 索引健康监控

### 4.1 健康检查命令

```bash
cd /root/.openclaw/workspace/memory/.index

# 查看统计
node memory-indexer.js stats

# 检查重复内容
node -e "
const fs = require('fs');
const data = JSON.parse(fs.readFileSync('memory-index.db', 'utf8'));

// 重复标题检测
const titleMap = {};
for (const doc of data.documents) {
    const key = doc.title.toLowerCase().trim();
    if (!titleMap[key]) titleMap[key] = [];
    titleMap[key].push(doc.path);
}

for (const [title, paths] of Object.entries(titleMap)) {
    if (paths.length > 1) {
        console.log('⚠️ 重复标题:', title);
        paths.forEach(p => console.log('   -', p));
    }
}
"
```

### 4.2 性能指标

| 指标 | 目标值 | 告警阈值 |
|-----|-------|---------|
| 搜索响应时间 | < 50ms | > 100ms |
| 索引文档数 | - | 超过 1000 |
| 重复内容比例 | < 5% | > 10% |
| 孤立链接数 | 0 | > 5 |

### 4.3 自动修复

当检测到以下问题时，执行自动修复:

```javascript
// 索引修复脚本示例
async function repairIndex() {
    // 1. 删除孤立文档
    // 2. 合并重复标签
    // 3. 重建 FTS 索引
    // 4. 更新统计信息
}
```

---

## 5. 使用示例

### 示例 1: 安装新技能前检索

```bash
# 步骤 1: 搜索技能相关信息
$ node memory/.index/memory-indexer.js search "skill安装"
# → 发现 modules/skills-installed.md

# 步骤 2: 搜索安全检查流程
$ node memory/.index/memory-indexer.js search "安全检查"
# → 发现 modules/safety-protocol.md

# 步骤 3: 阅读相关文档后，执行安装
# 步骤 4: 记录到 tags/skills-installed.md
```

### 示例 2: 处理错误时检索

```bash
# 步骤 1: 搜索类似错误
$ node memory/.index/memory-indexer.js search "database locked"

# 步骤 2: 搜索解决方案
$ node memory/.index/memory-indexer.js search "错误 教训"
# → 发现 modules/error-lessons.md

# 步骤 3: 基于历史经验解决问题
# 步骤 4: 记录新的错误和解决方案
```

---

## 6. 附录

### A. 索引数据结构

```json
{
  "version": "2.0",
  "documents": [
    {
      "id": "md5-hash",
      "path": "relative/path.md",
      "type": "daily|module|intel|evolution|tag",
      "title": "文档标题",
      "summary": "摘要...",
      "tags": ["标签1", "标签2"],
      "wordCount": 123
    }
  ],
  "links": [
    {
      "from": "doc-id-1",
      "to": "doc-id-2",
      "type": "shared-tag|semantic-similarity|reference",
      "similarity": 0.85
    }
  ]
}
```

### B. 快速参考卡片

```
┌─────────────────────────────────────────────────┐
│ 记忆系统快速参考                                 │
├─────────────────────────────────────────────────┤
│                                                 │
│  索引重建    node memory-indexer.js index       │
│  搜索        node memory-indexer.js search <q>  │
│  统计        node memory-indexer.js stats       │
│                                                 │
│  文档类型:                                      │
│    daily    - 每日记录                          │
│    module   - 模块文档                          │
│    intel    - 情报学习                          │
│    evolution- 进化报告                          │
│    tag      - 标签索引                          │
│                                                 │
│  标签: #指令 #发现 #决策 #技能                  │
│        #安全 #错误 #进化                        │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

*文档版本: 2.0*  
*最后更新: 2026-02-09*  
*索引状态: 45文档, 317关联, 搜索响应 <50ms*
