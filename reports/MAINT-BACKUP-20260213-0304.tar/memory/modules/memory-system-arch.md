# 记忆系统架构 v1.0

## 目录结构

```
memory/
├── daily/                    # 每日原始记录（简明扼要）
│   └── YYYY-MM-DD.md
├── summary/                  # 定期总结
│   ├── weekly/              # 每周总结（周日生成）
│   │   └── YYYY-MM-DD.md
│   └── monthly/             # 每月总结（月末生成）
│       └── YYYY-MM.md
├── tags/                     # 按标签索引
│   ├── user-instructions.md  # 用户指令历史
│   ├── skills-installed.md   # 已安装技能
│   ├── security-audits.md    # 安全审计记录
│   ├── evolution-reports.md  # 进化报告
│   └── decisions.md          # 重要决策记录
├── modules/                  # 模块化记忆
│   ├── user-profile.md       # 用户画像
│   ├── tool-usage.md         # 工具使用模式
│   ├── project-status.md     # 项目状态
│   └── error-lessons.md      # 错误与教训
└── archive/                  # 归档（>3个月的旧记忆）
    └── YYYY-MM.tar.gz
```

## 记录原则

### 1. 精简原则
- 每日记录 ≤ 500 字
- 只记录：决策、指令、发现、问题
- 不记录：闲聊、重复信息、临时状态

### 2. 标签化
每段记录必须带标签：
- `#指令` - 用户明确指令
- `#发现` - 新发现的信息
- `#决策` - 做出的决策
- `#技能` - 技能安装/更新
- `#安全` - 安全相关
- `#错误` - 错误和教训
- `#进化` - 自主进化相关

### 3. 模块化
- 通用知识 → modules/
- 临时事件 → daily/
- 聚合洞察 → summary/

## Token 优化策略

1. **分层访问**：优先读取 summary，必要时深入 daily
2. **过期机制**：3个月以上的 daily 自动归档
3. **索引机制**：tags/ 提供快速查找
4. **去重合并**：相似内容合并，避免重复

## 自动化流程

### 每日 23:50
1. 读取当天 daily/YYYY-MM-DD.md
2. 提取关键信息，更新 tags/
3. 如有重要内容，更新 modules/
4. 生成精简摘要

### 每周日 23:50
1. 汇总本周 daily/
2. 生成 weekly 总结
3. 识别模式，更新 modules/
4. 清理过期临时文件

### 每月最后一天 23:50
1. 汇总本月 weekly/
2. 生成 monthly 洞察
3. 归档 3个月前的 daily
4. 更新 MEMORY.md 核心摘要
