# 已安装 Skills 清单

**最后更新**: 2026-02-09 08:19  
**当前技能数**: 19个

---

## 当前 Skills

### 开发工具 (9个)
- agent-config, agentlens
- python, mcp-builder, tdd-guide, test-runner
- docker-essentials, cc-godmode
- ~~cursor-agent~~ (已移除 - macOS专用)
- ~~claude-team~~ (已移除 - macOS专用)

### 系统工具 (3个)
- bat-cat, fd-find, vhs-recorder

### 搜索工具 (2个)
- duckduckgo-search (需配置)
- exa (需 API key)
- ~~web-search-cli~~ (已移除 - 改用ddgr)

> **搜索方案**: ddgr 命令行搜索（无需API，已验证可用）

### 其他 (5个)
- github, summarize, skill-vetting, obsidian
- cellcog

---

## 候选 Skills (待评估)

| Skill | 作者 | 用途 | 优先级 | 决策 |
|-------|------|------|--------|------|
| cognitive-memory | icemilo414 | 多存储认知记忆系统 | 🔴 高 | 与 elite-longterm-memory 对比后选择 |
| elite-longterm-memory | nextfrontierbuilds | 高级长期记忆 | 🔴 高 | 与 cognitive-memory 对比 |
| comanda | kris-hansen | AI pipeline 生成 | 🟡 中 | 暂缓 - 避免过度复杂化 |
| entr | gumadeiras | 文件变更自动执行 | 🟡 中 | 待明确场景 |
| academic-deep-research | kesslerio | 带引用的学术研究 | 🟢 低 | 现有工具已覆盖 |
| evolver | autogame-17 | 自我进化引擎 | 🟢 低 | 当前 cron 循环已足够 |
| skill-creator | chindden | Skill 创建指南 | 🟢 低 | 需要时再安装 |

---

## 已移除 Skills

| 技能 | 移除时间 | 原因 | 替代方案 |
|------|----------|------|----------|
| cursor-agent | 2026-02-09 | macOS专用，无使用场景 | 如需再安装 |
| claude-team | 2026-02-09 | macOS专用，无使用场景 | 如需再安装 |
| web-search-cli | 2026-02-09 | 功能冗余 | ddgr命令行搜索 |

---

## 备注
- 安全检查通过标准：无恶意代码、无隐藏指令、功能与描述一致
- 所有已安装 skill 均通过源码审计
- 标记 * 的技能需要额外配置或特定环境
