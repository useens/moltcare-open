# clawdo 技能评估报告

**评估时间:** 2026-02-09  
**技能版本:** 1.1.3  
**评估者:** OpenClaw Security SubAgent  
**事件编号:** EV-20260209-006

---

## 1. 安全评级 🟢 PASS

### 1.1 自动扫描结果
```
✅ skill-vetting 扫描器：无安全问题
扫描范围：SKILL.md, README.md, _meta.json
检测项：代码执行、子进程、混淆、网络请求、文件操作、环境变量访问、提示注入
结果：未发现危险模式
```

### 1.2 源码审计摘要

**依赖安全性：**
- `better-sqlite3@12.6.2` - 安全的原生 SQLite 绑定，无已知漏洞
- `commander@14.0.3` - 成熟 CLI 框架
- `chalk@5.3.0` - 终端样式库
- 无网络请求库，无 eval/exec 使用

**代码安全设计：**
| 安全特性 | 实现状态 | 说明 |
|---------|---------|------|
| SQL 注入防护 | ✅ | 全参数化查询，零字符串拼接 |
| Prompt 注入防御 | ✅ | sanitize.js 实现多层过滤 |
| 输入消毒 | ✅ | 控制字符、零宽字符、方向控制符剥离 |
| 权限控制 | ✅ | 自主性级别不可提升（仅可降级） |
| ID 生成 | ✅ | crypto.randomInt，无模数偏差 |
| 文件权限 | ✅ | 数据库 0o600，目录 0o700 |
| 审计日志 | ✅ | 追加式 JSONL，不可篡改 |
| 发布可追溯 | ✅ | npm provenance 启用 |

**关键安全发现：**
1. **消毒流水线完善** (sanitize.js)：
   - 剥离控制字符（null bytes、零宽字符）
   - 过滤提示注入模式（SYSTEM MESSAGE、IGNORE INSTRUCTIONS 等）
   - 长度限制强制执行
   - JSON 输出包装 XML 标签警告

2. **自主性安全模型**：
   - 默认 `collab`（最安全）
   - 代理无法提升权限
   - 3 次失败后自动降级
   - 代理提议需人工确认

3. **数据库安全**：
   - WAL 模式启用
   - 外键约束启用
   - CHECK 约束验证所有枚举值

---

## 2. 功能评估 🟢 EXCELLENT

### 2.1 核心功能
```
待办生命周期: proposed → todo → in_progress → done
自主性级别: auto (10min) / auto-notify (30min) / collab (无限)
紧急程度: now / soon / whenever / someday
数据存储: SQLite (~/.config/clawdo/)
输出格式: 人类可读 + JSON (--json)
```

### 2.2 Agent 集成友好度
| 特性 | 支持 | 说明 |
|-----|------|------|
| JSON 输出 | ✅ | 所有命令支持 --json |
| 非 TTY 模式 | ✅ | 脚本/管道友好，无交互阻塞 |
| 心跳集成 | ✅ | inbox 命令专为心跳设计 |
| 环境变量 | ✅ | CLAWDO_DB_PATH 支持多代理 |
| 退出码 | ✅ | 标准化错误码 |

### 2.3 创新功能
- **内联语法**: `clawdo add "fix bug +backend @code auto soon"`
- **任务阻塞**: `clawdo block <id> by <other-id>`
- **审计追踪**: 完整的历史记录
- **多代理支持**: 通过环境变量隔离或共享数据库

---

## 3. 与现有方案对比

### 3.1 现有技能清单
当前工作区技能 (20+)，无待办/任务管理类技能：
- agent-config, agentlens, bat-cat, cc-godmode, cellcog, debug-pro
- docker-essentials, fd-find, github, god-mode, mcp-builder
- obsidian, python, skill-vetting, summarize, tdd-guide
- test-runner, vestige, vhs-recorder

### 3.2 对比分析
| 维度 | clawdo | 无替代方案 |
|-----|--------|-----------|
| 功能定位 | 轻量待办队列 | N/A |
| Agent 集成 | 原生设计 | N/A |
| 自主性控制 | 三级权限模型 | N/A |
| 数据持久化 | SQLite 本地 | N/A |
| 心跳集成 | 内置支持 | N/A |

**结论**: 无功能重复，填补空白

---

## 4. 维护状态 🟢 ACTIVE

| 指标 | 状态 |
|-----|------|
| 首次发布 | 2026-02-07 (1.0.0) |
| 最新版本 | 2026-02-08 (1.1.3) |
| 发布频率 | 2 天内 6 个版本，活跃迭代 |
| 开源许可 | MIT |
| 源码仓库 | github.com/LePetitPince/clawdo |
| 测试覆盖 | Vitest (CI 启用) |
| 作者信誉 | LePetitPince (GitHub 活跃) |

---

## 5. 安装建议 🟢 INSTALL

### 5.1 推荐操作
```bash
# 安装技能文档
clawhub install clawdo

# 安装 CLI 工具
npm install -g clawdo

# 验证安装
clawdo --version
```

### 5.2 评估决策矩阵

| 维度 | 评级 | 说明 |
|-----|------|------|
| 安全性 | ✅ 通过 | 无风险，设计严谨 |
| 实用性 | ✅ 高 | 填补空白，Agent 原生 |
| 维护状态 | ✅ 活跃 | 持续迭代，响应及时 |
| 复杂度 | ✅ 低 | 单一职责，易于理解 |
| 依赖风险 | ✅ 低 | 标准依赖，无网络调用 |

### 5.3 使用建议

**推荐场景:**
- HEARTBEAT.md 集成：检查并执行队列任务
- Cron 任务：批量处理待办
- 会话中捕获："稍后再做"
- 多代理协调：共享或隔离数据库

**注意事项:**
- 需要 Node.js ≥ 18
- better-sqlite3 需要编译工具（build-essential 或 xcode-select）
- 首次使用建议手动测试熟悉命令

---

## 6. 总体结论

| 评估项 | 结果 |
|-------|------|
| 安全审计 | 🟢 通过 |
| 功能评估 | 🟢 优秀 |
| 维护状态 | 🟢 活跃 |
| 安装建议 | 🟢 建议安装 |

**最终建议: INSTALL (立即安装)**

clawdo 是一个设计精良、安全可靠的轻量待办管理工具。它填补了 OpenClaw 生态中 "Agent 原生任务队列" 的空白，与现有技能无冲突。作者可信，代码质量高，安全模型完善。建议立即安装并集成到心跳工作流中。

---

**评估附件:**
- 技能包扫描: `/tmp/clawdo-inspect/`
- 源码分析: `/tmp/clawdo-source/`
- npm 元数据: registry.npmjs.org/clawdo
