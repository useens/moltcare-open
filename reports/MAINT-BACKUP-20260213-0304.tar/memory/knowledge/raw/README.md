# 统一知识归档系统

## 概述
统一知识内化系统的原始数据归档目录，自动收集来自多个情报源的数据。

## 目录结构
```
memory/knowledge/raw/
├── {source}/           # 按来源分类
│   └── {YYYY-MM-DD}/  # 按日期分类
│       └── {filename}_{timestamp}.{ext}
├── .hashes/           # 文件哈希去重索引
├── collection_index.json      # 完整归档索引
├── source_distribution.json   # 来源分布统计
└── collection_report.txt      # 收集报告
```

## 数据来源
- **moltbook**: Moltbook 网页提取数据
- **hackernews**: Hacker News 热门文章
- **github_trending**: GitHub 趋势项目
- **devto**: Dev.to 技术文章
- **indiehackers**: Indie Hackers 社区
- **lobsters**: Lobsters 技术讨论
- **producthunt**: Product Hunt 新产品
- **intel**: 情报文件 (JSON/Markdown/XML)
- **evolution**: 进化档案和元数据

## 使用
运行收集器：
```bash
python3 memory/modules/unified_collector.py
```

## 特性
- 自动去重（基于MD5哈希）
- 递归目录扫描
- 元数据提取（项目计数、时间戳）
- 完整索引和报告生成
