# 技术研究员代理任务指令

**角色**: 技术研究员代理 (researcher)  
**任务ID**: test-task-001  
**指令时间**: 2026-02-09T02:51:00+08:00

## 任务目标
调研任务管理系统技术选型，为开发提供技术决策支持。

## 调研范围
1. **后端框架**: 
   - FastAPI (Python)
   - Flask (Python)
   - 对比维度：性能、生态、学习曲线

2. **数据库**:
   - SQLite (开发/轻量)
   - PostgreSQL (生产)
   - 对比维度：适用场景、扩展性

3. **认证方案**:
   - JWT Token
   - Session Cookie
   - 对比维度：安全性、实现复杂度

## 输出要求
1. **技术调研报告**: `/root/.openclaw/workspace/memory/multi-agent/test-task-001/artifacts/researcher/tech-research.md`
   - 各方案详细分析
   - 对比矩阵

2. **选型建议**: `/root/.openclaw/workspace/memory/multi-agent/test-task-001/artifacts/researcher/recommendation.md`
   - 推荐方案
   - 选型理由

## 协作要求
- **并行执行**: 与架构师同时开始
- **完成后通知**: developer
- **状态更新**: 更新状态文件

## 时间限制
- **预估用时**: 25分钟
- **截止时间**: 2026-02-09T03:30:00+08:00

**状态文件**: `/root/.openclaw/workspace/memory/multi-agent/sync/task-test-task-001-status.yaml`
