# 安全审计员代理任务指令

**角色**: 安全审计员代理 (security)  
**任务ID**: test-task-001  
**指令时间**: 2026-02-09T02:51:00+08:00

## 任务目标
审查任务管理系统API的安全设计，识别潜在风险并提供修复建议。

## 审计范围
1. **认证授权机制**: JWT/Session设计安全性
2. **输入验证**: 防止注入攻击
3. **数据保护**: 敏感数据处理
4. **API安全**: 速率限制、CORS等

## 输入依赖
- **架构师**: 架构设计文档（等待完成后审查）

## 输出要求
1. **安全审查报告**: `/root/.openclaw/workspace/memory/multi-agent/test-task-001/artifacts/security/security-review.md`
   - 审查发现
   - 风险评级
   - 修复建议

2. **风险登记册**: `/root/.openclaw/workspace/memory/multi-agent/test-task-001/artifacts/security/risk-register.yaml`
   - 风险列表
   - 严重程度
   - 缓解措施

## 协作要求
- **依赖**: architect（强依赖）
- **完成后通知**: developer, pm
- **状态更新**: 更新状态文件

## 时间限制
- **预估用时**: 25分钟
- **截止时间**: 2026-02-09T03:35:00+08:00

**状态文件**: `/root/.openclaw/workspace/memory/multi-agent/sync/task-test-task-001-status.yaml`
