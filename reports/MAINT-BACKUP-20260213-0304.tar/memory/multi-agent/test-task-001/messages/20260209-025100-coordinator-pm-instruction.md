# 项目经理代理任务指令

**角色**: 项目经理代理 (pm)  
**任务ID**: test-task-001  
**指令时间**: 2026-02-09T02:51:00+08:00

## 任务目标
监控整个多代理协作测试任务的执行，确保按时高质量完成。

## 监控范围
- 架构师 (architect)
- 安全审计员 (security)
- 技术研究员 (researcher)
- 开发工程师 (developer)
- 测试工程师 (tester)

## 管理职责
1. **进度跟踪**: 每10分钟检查一次各代理状态
2. **风险管理**: 识别阻塞、延迟、质量问题
3. **协调干预**: 处理代理间冲突和依赖问题
4. **报告生成**: 汇总进度和成果

## 输出要求
1. **项目计划**: `/root/.openclaw/workspace/memory/multi-agent/test-task-001/artifacts/pm/project-plan.md`
2. **进度报告**: `/root/.openclaw/workspace/memory/multi-agent/test-task-001/artifacts/pm/progress-report.md`
3. **风险日志**: `/root/.openclaw/workspace/memory/multi-agent/test-task-001/artifacts/pm/risk-log.yaml`

## 干预触发条件
- 进度偏差 > 20%
- 阻塞时间 > 15分钟
- 质量分数 < 70
- 代理无响应 > 10分钟

## 时间要求
- **监控频率**: 每10分钟
- **报告频率**: 每20分钟
- **任务结束**: 2026-02-09T04:30:00+08:00

## 立即执行
请立即开始监控，创建项目计划文档。

**状态文件**: `/root/.openclaw/workspace/memory/multi-agent/sync/task-test-task-001-status.yaml`
