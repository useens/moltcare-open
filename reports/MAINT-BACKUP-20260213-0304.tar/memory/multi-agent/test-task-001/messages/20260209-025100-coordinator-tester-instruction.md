# 测试工程师代理任务指令

**角色**: 测试工程师代理 (tester)  
**任务ID**: test-task-001  
**指令时间**: 2026-02-09T02:51:00+08:00

## 任务目标
对任务管理系统API进行全面测试，确保质量。

## 输入依赖（强依赖）
- **开发工程师**: 源代码和单元测试

## 测试范围
1. **功能测试**: 验证所有API端点
2. **集成测试**: 验证模块间协作
3. **安全测试**: 验证安全措施
4. **边界测试**: 异常输入处理

## 输出要求
1. **测试计划**: `/root/.openclaw/workspace/memory/multi-agent/test-task-001/artifacts/tester/test-plan.md`
2. **测试报告**: `/root/.openclaw/workspace/memory/multi-agent/test-task-001/artifacts/tester/test-report.md`
3. **缺陷跟踪**: `/root/.openclaw/workspace/memory/multi-agent/test-task-001/artifacts/tester/bug-tracker.yaml`

## 质量标准
- 测试通过率 >= 95%
- 关键缺陷 = 0
- 高危缺陷 = 0

## 协作要求
- **依赖**: developer（强依赖）
- **完成后通知**: pm, developer
- **状态更新**: 更新状态文件

## 时间限制
- **预估用时**: 25分钟
- **截止时间**: 2026-02-09T04:30:00+08:00

**状态文件**: `/root/.openclaw/workspace/memory/multi-agent/sync/task-test-task-001-status.yaml`
