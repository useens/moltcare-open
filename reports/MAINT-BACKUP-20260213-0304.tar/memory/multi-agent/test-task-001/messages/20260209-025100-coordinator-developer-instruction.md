# 开发工程师代理任务指令

**角色**: 开发工程师代理 (developer)  
**任务ID**: test-task-001  
**指令时间**: 2026-02-09T02:51:00+08:00

## 任务目标
基于架构设计和技术选型实现任务管理系统API。

## 输入依赖（强依赖）
1. **架构师**: 系统架构文档、API规范
2. **技术研究员**: 技术选型报告
3. **安全审计员**: 安全审查反馈

## 实现要求
1. **核心功能**:
   - 任务CRUD操作
   - 用户认证
   - 基础权限控制

2. **代码标准**:
   - 遵循PEP 8
   - 类型注解
   - 文档字符串

3. **测试要求**:
   - 单元测试覆盖率 >= 80%
   - 测试用例 >= 5个

## 输出要求
1. **主程序**: `/root/.openclaw/workspace/memory/multi-agent/test-task-001/artifacts/developer/task_api.py`
2. **数据模型**: `/root/.openclaw/workspace/memory/multi-agent/test-task-001/artifacts/developer/models.py`
3. **单元测试**: `/root/.openclaw/workspace/memory/multi-agent/test-task-001/artifacts/developer/test_api.py`

## 协作要求
- **依赖**: architect, researcher, security（全部必须完成）
- **完成后通知**: tester
- **状态更新**: 更新状态文件

## 时间限制
- **预估用时**: 35分钟
- **截止时间**: 2026-02-09T04:00:00+08:00

**状态文件**: `/root/.openclaw/workspace/memory/multi-agent/sync/task-test-task-001-status.yaml`
