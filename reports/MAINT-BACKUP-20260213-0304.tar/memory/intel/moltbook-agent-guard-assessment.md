# moltbook-agent-guard 评估报告

**评估时间**: 2026-02-09 11:56  
**评估者**: 林林（数字分身）  
**状态**: 🟡 暂缓部署  
**决策**: 待需要 Moltbook 平台交互时再安装

---

## 项目信息

| 属性 | 详情 |
|------|------|
| **名称** | moltbook-agent-guard |
| **作者** | NirDiamant |
| **GitHub** | https://github.com/NirDiamant/moltbook-agent-guard |
| **许可证** | Apache 2.0 |
| **类型** | 独立 Python 工具（非 ClawHub skill）|

---

## 评估摘要

| 维度 | 评级 | 说明 |
|------|------|------|
| **安全评级** | 🟢 **通过** | 6层防护，24个安全模块，知名作者 |
| **功能价值** | **高** | Agent 社交平台实时安全防护 |
| **安装建议** | **暂缓** | 当前无 Moltbook 平台交互需求 |

---

## 安全审计亮点

✅ **分层安全架构**: 6层防护，24个安全模块  
✅ **自扫描机制**: 内置 `skill_verifier.py` 检测危险代码模式  
✅ **配置安全**: 凭证文件自动设置600权限，支持加密存储  
✅ **Docker加固**: 默认配置 `cap_drop: ALL`, `read-only fs`  
✅ **分层安全级别**: basic/enhanced/paranoid 三级可选  

⚠️ **注意事项**:
- 需要连接外部API (moltbook.com)
- 需要 Anthropic/OpenAI API key
- `init.py` 使用 `webbrowser.open()` 打开验证页面（标准做法）

---

## 功能评估

**解决的问题**: AI Agent 在 Moltbook 社交平台上的实时安全防护

**核心功能**:
- 提示注入攻击检测与拦截
- 凭证窃取防护
- 数据泄露预防
- 越狱攻击防护
- 出站流量控制
- 预算限制与成本追踪

---

## 与现有方案对比

| 功能 | 现有 skill-vetting | moltbook-agent-guard |
|------|-------------------|---------------------|
| 代码静态分析 | ✅ | ✅ (skill_verifier) |
| 运行时注入防护 | ❌ | ✅ |
| 社交平台特定威胁 | ❌ | ✅ |
| 成本预算控制 | ❌ | ✅ |
| Moltbook 集成 | ❌ | ✅ |

**结论**: 功能互补，不重复。这是针对特定平台(Moltbook)的专业安全方案。

---

## 部署决策

### 暂缓原因

1. **非 ClawHub skill**: 独立 Python 工具，需要单独部署
2. **当前无需求**: 你的 Agent 仅在本地运行，无 Moltbook 平台交互
3. **API key 依赖**: 需要 Anthropic/OpenAI API key，增加配置复杂度
4. **skill-vetting 已覆盖**: 当前技能安全审计已由 skill-vetting 处理

### 何时部署

建议以下情况时部署：
- 计划让 Agent 上 Moltbook 平台发布/交互
- 需要实时监控社交平台威胁
- 有明确的 Moltbook 使用场景

### 部署命令（待执行）

```bash
cd /tmp
git clone https://github.com/NirDiamant/moltbook-agent-guard.git
cd moltbook-agent-guard
pip install -r requirements.txt
./moltbook init  # 需要配置 API key
```

---

## 关联评估

**同时评估项目**: MoltBrain
- 状态: 🔴 拒绝（安全风险过高）
- 原因: 安装脚本自动执行系统命令、预编译 bundle 不可审计、关联 $BRAIN token

---

## 更新日志

| 时间 | 事件 |
|------|------|
| 2026-02-09 11:56 | 完成安全审计和功能评估 |
| 2026-02-09 11:58 | 决策：暂缓部署，待需要时再安装 |

---

*评估档案位置*: `memory/intel/moltbook-agent-guard-assessment.md`  
*关联档案*: `memory/intel/moltbrain-assessment.md`（拒绝）
