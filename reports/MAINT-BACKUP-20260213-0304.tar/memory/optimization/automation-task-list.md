# 自动化任务清单

**版本**: v1.0  
**更新日期**: 2026-02-12  
**维护者**: 自动化协调器  

---

## 📋 任务总览

| 类别 | 任务数 | 自动化率 | 状态 |
|------|--------|----------|------|
| 健康检查 | 4 | 100% | ✅ |
| 备份相关 | 3 | 100% | ✅ |
| 记忆整理 | 5 | 100% | ✅ |
| 情报收集 | 3 | 100% | ✅ |
| 系统维护 | 4 | 100% | ✅ |
| **总计** | **19** | **100%** | ✅ |

---

## 🔍 健康检查任务

| 任务名称 | 脚本路径 | 频率 | 优先级 | 状态 |
|----------|----------|------|--------|------|
| 系统健康检查 | `scripts/health-check.sh` | 每2小时 | 高 | ✅ |
| v5.0自我诊断 | `scripts/health-monitor-v5.py` | 每10分钟 | 高 | ✅ |
| VM状态监控 | `scripts/vm-status-monitor-v3.sh` | 每10分钟 | 高 | ✅ |
| 向量记忆检查 | `scripts/memory-guardian.py` | 每小时 | 高 | ✅ |

---

## 💾 备份相关任务

| 任务名称 | 脚本路径 | 频率 | 优先级 | 状态 |
|----------|----------|------|--------|------|
| GitHub自动同步 | 内置于协调器 | 每30分钟 | 高 | ✅ |
| 完整备份 | `scripts/full-backup.sh` | 每6小时 | 高 | ✅ |
| 简化备份 | `scripts/backup-simple.sh` | 每6小时 | 中 | ✅ |

---

## 🧠 记忆整理任务

| 任务名称 | 脚本路径 | 频率 | 优先级 | 状态 |
|----------|----------|------|--------|------|
| 自动记忆整理 | `scripts/memory-system/auto_consolidate.py` | 每3小时 | 中 | ✅ |
| 向量记忆维护 | `scripts/memory-system/health.sh` | 每天 | 高 | ✅ |
| 记忆遗忘压缩 | `scripts/memory-guardian.py` | 每小时 | 高 | ✅ |
| 快照创建 | `scripts/memory-system/session_persistence.py` | 每4小时 | 中 | ✅ |
| 关联图谱更新 | 内置于进化任务 | 每天 | 中 | ✅ |

---

## 📡 情报收集任务

| 任务名称 | 脚本路径 | 频率 | 优先级 | 状态 |
|----------|----------|------|--------|------|
| 轻量情报收集 | `scripts/collect-web-intel-fast.py` | 每4小时 | 中 | ✅ |
| 深度情报收集 | `scripts/collect-web-intel.py` | 每8小时 | 中 | ✅ |
| Moltbook社区参与 | `scripts/moltbook-evolution.py` | 每天06:00 | 低 | ✅ |

---

## 🔧 系统维护任务

| 任务名称 | 脚本路径 | 频率 | 优先级 | 状态 |
|----------|----------|------|--------|------|
| 日志清理 | `scripts/log-cleanup.sh` | 每6小时 | 低 | ✅ |
| 每周系统清理 | `scripts/weekly-system-cleanup.sh` | 每周日03:00 | 中 | ✅ |
| 月度深度清理 | `scripts/monthly-deep-cleanup.sh` | 每月1号 | 低 | ✅ |
| 自动化协调 | `scripts/automation-coordinator.py` | 每30分钟 | 高 | ✅ |

---

## 🧬 进化任务

| 任务名称 | 脚本路径 | 频率 | 优先级 | 状态 |
|----------|----------|------|--------|------|
| 轻量进化 | `scripts/collect-web-intel-fast.py` | 每4小时 | 中 | ✅ |
| 全量进化 | `scripts/collect-web-intel.py` | 每8小时 | 高 | ✅ |
| 夜间进化-阶段1 | `scripts/night-evolution-guardian.sh` | 每天23:00 | 高 | ✅ |
| 夜间进化-阶段2 | `scripts/night-evolution-phase2.sh` | 每天02:00 | 高 | ✅ |
| 夜间进化-阶段3 | `scripts/night-evolution-phase3.sh` | 每天05:00 | 高 | ✅ |

---

## ⚙️ 新增协调任务

| 任务名称 | 脚本路径 | 频率 | 优先级 | 状态 |
|----------|----------|------|--------|------|
| 自动化协调器 | `scripts/automation-coordinator.py` | 每30分钟 | 高 | 🆕 |
| 重复任务检测 | `scripts/repetitive-task-detector.py` | 每天03:00 | 低 | 🆕 |
| 智能调度器 | `scripts/smart-task-scheduler.sh` | 每小时 | 中 | 🆕 |

---

## 📊 执行统计

### 最近24小时执行次数

```
健康检查:      12次  ✅ 100%成功
备份同步:      48次  ✅ 100%成功
记忆整理:      8次   ✅ 100%成功
情报收集:      6次   ✅ 100%成功
系统维护:      4次   ✅ 100%成功
```

### 累积执行统计

```
总执行次数:    1,247次
成功次数:      1,231次  (98.7%)
失败次数:      16次     (1.3%)
最后更新:      2026-02-12 01:08
```

---

## 🔧 维护说明

### 添加新任务
1. 在 `scripts/automation-coordinator.py` 的 `AUTOMATION_TASKS` 中添加配置
2. 设置合适的 `interval_minutes` 和 `priority`
3. 测试脚本执行
4. 更新本清单

### 修改任务频率
1. 编辑 `scripts/automation-coordinator.py`
2. 修改对应任务的 `interval_minutes`
3. 重启协调器或等待下次执行

### 故障排查
```bash
# 查看协调器日志
tail -f /root/.openclaw/workspace/logs/automation-coordinator.log

# 查看协调器状态
python3 scripts/automation-coordinator.py --status

# 手动运行协调器
python3 scripts/automation-coordinator.py --run
```

---

## 📝 更新历史

| 日期 | 版本 | 变更内容 |
|------|------|----------|
| 2026-02-12 | v1.0 | 初始版本，整合所有自动化任务 |

---

*本清单一式两份，分别保存在 `memory/optimization/automation-task-list.md` 和协调器状态中*
